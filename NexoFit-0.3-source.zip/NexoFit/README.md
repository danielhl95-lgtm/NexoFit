# NexoFit 0.3

Aplicación Android de entrenamiento personal, diseñada para funcionar en Huawei sin Google Play Services. Mantiene dos sabores desde un único código fuente:

- **Standard**: entrenamiento, rutinas, progreso y biblioteca de ejercicios.
- **Plus/Pelvic**: todo lo anterior + módulo de suelo pélvico/Kegel.

## Novedades principales de 0.3

- Onboarding guiado y visual. La primera decisión de entrenamiento es **cuántos días por semana** entrenará la persona.
- Elección de **Gimnasio / Aire libre / Mixto**.
- Selección de objetivo, duración, equipamiento y nivel antes de generar el plan.
- Vista previa final de la semana antes de entrar a la aplicación.
- Mapas musculares locales y offline en la rutina y en cada ejercicio.
- Referencias visuales de máquinas/equipamiento y alternativas de gimnasio.
- Biblioteca ampliada con ejercicios de máquinas, pesos libres, poleas y peso corporal.
- Filtros por músculo y equipamiento.
- Rutina generada según tiempo y equipamiento disponible.
- Modo mixto que alterna sesiones de gimnasio y exterior.
- Guías de ejercicio con músculos primarios/secundarios, técnica, errores y alternativas.
- Animaciones locales diferenciadas por patrón de movimiento.
- Feedback post-sesión (fácil / bien / muy duro), usado para modular la sugerencia de carga siguiente.
- Mantiene registro de peso, reps, RIR, e1RM, volumen, historial y progresión de 0.2.

## Privacidad y compatibilidad

- No Firebase.
- No Google Sign-In.
- No Google Play Services.
- Datos locales en el dispositivo.
- Los enlaces de video son externos y opcionales.

## Compilar

```bash
gradle :app:assembleStandardDebug :app:assemblePelvicDebug
```

APKs esperados:

- `app/build/outputs/apk/standard/debug/app-standard-debug.apk`
- `app/build/outputs/apk/pelvic/debug/app-pelvic-debug.apk`
