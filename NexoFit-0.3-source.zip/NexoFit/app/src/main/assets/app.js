(() => {
  'use strict';

  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const screen = $('#screen');
  const modalRoot = $('#modalRoot');
  const toastEl = $('#toast');

  const EDITION = new URLSearchParams(location.search).get('edition') || 'standard';
  const KEGEL_ENABLED = EDITION === 'pelvic';
  const APP_VERSION = '0.3.0';
  const KEYS = { profile:'nexofit.profile.v3', plan:'nexofit.plan.v3', logs:'nexofit.logs.v3', kegel:'nexofit.kegel.v3' };
  const LEGACY = { profile:'nexofit.profile.v2', plan:'nexofit.plan.v2', logs:'nexofit.logs.v2', kegel:'nexofit.kegel.v2' };
  const state = {
    tab:'home', environment:'gym', day:0, profile:null, plan:null,
    logs:[], kegel:null, workout:null, kegelTimer:null
  };

  const goals = {
    muscle:{label:'Ganar músculo', icon:'💪', note:'Más masa y fuerza'},
    recomposition:{label:'Recomposición', icon:'⚡', note:'Músculo + control de grasa'},
    fat:{label:'Bajar grasa', icon:'🔥', note:'Más gasto y condición'},
    strength:{label:'Fuerza', icon:'🏋', note:'Progresar cargas'},
    fitness:{label:'Rendimiento', icon:'🏃', note:'Resistencia y capacidad física'}
  };

  const ex = {
    squat:{name:'Sentadilla',muscles:'Cuádriceps · glúteos · core',sets:4,reps:'8–12',rest:90,anim:'squat',video:'https://www.youtube.com/results?search_query=sentadilla+tecnica+correcta',cues:['Pecho abierto y abdomen firme.','Rodillas siguiendo la dirección de los pies.','Desciende con control hasta un rango cómodo.','Empuja el suelo al subir.'],bad:['Colapsar las rodillas hacia dentro.','Redondear la espalda por buscar más profundidad.','Rebotar sin control en la parte baja.']},
    rdl:{name:'Peso muerto rumano',muscles:'Isquiotibiales · glúteos · espalda',sets:4,reps:'8–10',rest:100,anim:'hinge',video:'https://www.youtube.com/results?search_query=peso+muerto+rumano+tecnica',cues:['Cadera viaja hacia atrás.','Barra o mancuernas cerca de las piernas.','Columna neutra y cuello relajado.','Sube contrayendo glúteos, sin hiperextender.'],bad:['Convertirlo en una sentadilla.','Alejar la carga del cuerpo.','Bajar más allá de tu movilidad.']},
    legpress:{name:'Prensa de piernas',muscles:'Cuádriceps · glúteos',sets:4,reps:'10–15',rest:90,anim:'squat',video:'https://www.youtube.com/results?search_query=prensa+de+piernas+tecnica',cues:['Apoya toda la planta del pie.','Controla el descenso.','Mantén pelvis estable contra el respaldo.'],bad:['Bloquear las rodillas agresivamente.','Despegar la cadera del respaldo.']},
    lunge:{name:'Zancadas',muscles:'Glúteos · cuádriceps · core',sets:3,reps:'10–12 c/pierna',rest:70,anim:'lunge',video:'https://www.youtube.com/results?search_query=zancadas+tecnica+correcta',cues:['Paso suficientemente largo para mantener equilibrio.','Tronco estable.','Empuja con el pie delantero.'],bad:['Golpear la rodilla contra el suelo.','Perder alineación de rodilla y pie.']},
    legext:{name:'Extensión de cuádriceps',muscles:'Cuádriceps',sets:3,reps:'12–15',rest:60,anim:'squat',video:'https://www.youtube.com/results?search_query=extension+de+cuadriceps+maquina+tecnica',cues:['Alinea la rodilla con el eje de la máquina.','Sube sin impulso y baja lento.'],bad:['Usar una carga que obligue a rebotar.']},
    legcurl:{name:'Curl femoral',muscles:'Isquiotibiales',sets:3,reps:'10–15',rest:60,anim:'hinge',video:'https://www.youtube.com/results?search_query=curl+femoral+maquina+tecnica',cues:['Mantén la pelvis estable.','Aprieta atrás y controla la vuelta.'],bad:['Arquear la espalda para mover la carga.']},
    calves:{name:'Elevación de gemelos',muscles:'Gemelos · sóleo',sets:4,reps:'12–20',rest:45,anim:'calf',video:'https://www.youtube.com/results?search_query=elevacion+de+gemelos+tecnica',cues:['Recorre un rango cómodo completo.','Pausa arriba un instante.'],bad:['Rebotar rápidamente.']},
    bench:{name:'Press de banca',muscles:'Pectoral · tríceps · deltoide anterior',sets:4,reps:'6–10',rest:110,anim:'push',video:'https://www.youtube.com/results?search_query=press+banca+tecnica+correcta',cues:['Escápulas estables contra el banco.','Pies firmes en el suelo.','Baja con control.'],bad:['Abrir excesivamente los codos.','Rebotar la barra en el pecho.']},
    incline:{name:'Press inclinado con mancuernas',muscles:'Pectoral superior · hombros · tríceps',sets:3,reps:'8–12',rest:80,anim:'push',video:'https://www.youtube.com/results?search_query=press+inclinado+mancuernas+tecnica',cues:['Controla el recorrido.','Mantén hombros lejos de las orejas.'],bad:['Chocar las mancuernas arriba.']},
    row:{name:'Remo sentado',muscles:'Dorsal · romboides · bíceps',sets:4,reps:'8–12',rest:85,anim:'row',video:'https://www.youtube.com/results?search_query=remo+sentado+polea+tecnica',cues:['Inicia llevando hombros atrás y abajo.','Codos viajan hacia atrás.','Evita balancear el torso.'],bad:['Tirar solo con los brazos.','Redondear la espalda.']},
    pulldown:{name:'Jalón al pecho',muscles:'Dorsal · bíceps',sets:4,reps:'8–12',rest:80,anim:'row',video:'https://www.youtube.com/results?search_query=jalon+al+pecho+tecnica',cues:['Pecho alto, hombros abajo.','Lleva la barra hacia la parte alta del pecho.'],bad:['Llevar la barra detrás de la cabeza.','Balancearte para ganar impulso.']},
    shoulder:{name:'Press de hombros',muscles:'Deltoides · tríceps',sets:3,reps:'8–12',rest:80,anim:'push',video:'https://www.youtube.com/results?search_query=press+militar+mancuernas+tecnica',cues:['Abdomen firme.','Sube la carga sin arquear la espalda.'],bad:['Extender demasiado la zona lumbar.']},
    lateral:{name:'Elevaciones laterales',muscles:'Deltoide medio',sets:3,reps:'12–18',rest:55,anim:'raise',video:'https://www.youtube.com/results?search_query=elevaciones+laterales+tecnica',cues:['Codos ligeramente flexionados.','Sube con control hasta una altura cómoda.'],bad:['Impulsar el torso.']},
    curl:{name:'Curl de bíceps',muscles:'Bíceps · braquial',sets:3,reps:'10–15',rest:55,anim:'curl',video:'https://www.youtube.com/results?search_query=curl+biceps+tecnica',cues:['Codos cerca del cuerpo.','Baja controlando.'],bad:['Balancear el tronco.']},
    triceps:{name:'Extensión de tríceps en polea',muscles:'Tríceps',sets:3,reps:'10–15',rest:55,anim:'push',video:'https://www.youtube.com/results?search_query=triceps+polea+tecnica',cues:['Codos quietos.','Extiende y aprieta sin encoger hombros.'],bad:['Mover todo el brazo para generar impulso.']},
    hip:{name:'Hip thrust',muscles:'Glúteos · isquiotibiales',sets:4,reps:'8–12',rest:90,anim:'hinge',video:'https://www.youtube.com/results?search_query=hip+thrust+tecnica',cues:['Mentón ligeramente recogido.','Sube hasta alinear tronco y muslos.','Pausa arriba contrayendo glúteos.'],bad:['Hiperextender la espalda.']},
    plank:{name:'Plancha',muscles:'Core · glúteos · hombros',sets:3,reps:'30–60 s',rest:45,anim:'push',video:'https://www.youtube.com/results?search_query=plancha+abdominal+tecnica',cues:['Cuerpo en línea.','Aprieta abdomen y glúteos.','Respira sin perder postura.'],bad:['Dejar caer la cadera.','Elevar demasiado la cadera.']},
    pushup:{name:'Flexiones',muscles:'Pectoral · tríceps · core',sets:4,reps:'8–20',rest:60,anim:'push',video:'https://www.youtube.com/results?search_query=flexiones+tecnica+correcta',cues:['Cuerpo rígido.','Manos bajo o ligeramente fuera de hombros.','Baja con control.'],bad:['Sacar la cabeza hacia delante.','Perder tensión abdominal.']},
    airSquat:{name:'Sentadilla con peso corporal',muscles:'Piernas · glúteos · core',sets:4,reps:'15–25',rest:45,anim:'squat',video:'https://www.youtube.com/results?search_query=sentadilla+peso+corporal+tecnica',cues:['Mantén el pie completo apoyado.','Controla la bajada y sube con intención.'],bad:['Juntar las rodillas hacia dentro.']},
    split:{name:'Sentadilla búlgara',muscles:'Glúteos · cuádriceps',sets:3,reps:'8–15 c/pierna',rest:65,anim:'lunge',video:'https://www.youtube.com/results?search_query=sentadilla+bulgara+tecnica',cues:['Busca un apoyo estable.','Baja verticalmente con control.'],bad:['Poner el pie delantero demasiado cerca.']},
    mountain:{name:'Mountain climbers',muscles:'Core · hombros · cardio',sets:4,reps:'30–45 s',rest:35,anim:'push',video:'https://www.youtube.com/results?search_query=mountain+climbers+tecnica',cues:['Manos firmes bajo hombros.','Mueve las piernas sin perder la cadera.'],bad:['Rebotar la pelvis excesivamente.']},
    burpee:{name:'Burpees',muscles:'Full body · cardio',sets:4,reps:'8–15',rest:60,anim:'squat',video:'https://www.youtube.com/results?search_query=burpees+tecnica',cues:['Prioriza técnica antes que velocidad.','Aterriza suave.'],bad:['Colapsar la espalda al bajar al suelo.']},
    stepup:{name:'Step-ups',muscles:'Glúteos · cuádriceps',sets:3,reps:'10–15 c/pierna',rest:55,anim:'lunge',video:'https://www.youtube.com/results?search_query=step+ups+tecnica',cues:['Apoya el pie completo en una superficie estable.','Sube usando la pierna de arriba.'],bad:['Impulsarte demasiado con la pierna de abajo.']},
    chestpress:{name:'Press de pecho en máquina',muscles:'Pectoral · tríceps · deltoide anterior',sets:4,reps:'8–12',rest:85,anim:'push',video:'https://www.youtube.com/results?search_query=chest+press+maquina+tecnica',cues:['Ajusta el asiento para que las empuñaduras queden a la altura del pecho.','Escápulas estables y pies apoyados.','Empuja sin bloquear agresivamente los codos.'],bad:['Elevar los hombros.','Despegar la espalda del respaldo.']},
    machinerow:{name:'Remo en máquina con apoyo',muscles:'Espalda · bíceps',sets:4,reps:'8–12',rest:80,anim:'row',video:'https://www.youtube.com/results?search_query=remo+maquina+apoyo+pecho+tecnica',cues:['Apoya el pecho si la máquina lo permite.','Lleva codos atrás sin encoger hombros.','Controla el retorno.'],bad:['Tirar con impulso.','Perder la posición del tronco.']},
    hack:{name:'Hack squat',muscles:'Cuádriceps · glúteos',sets:4,reps:'8–12',rest:100,anim:'squat',video:'https://www.youtube.com/results?search_query=hack+squat+tecnica',cues:['Espalda y pelvis apoyadas.','Rodillas siguen la línea de los pies.','Desciende hasta un rango cómodo.'],bad:['Despegar la pelvis.','Cerrar las rodillas hacia dentro.']},
    shoulderpress:{name:'Press de hombros en máquina',muscles:'Deltoides · tríceps',sets:3,reps:'8–12',rest:75,anim:'push',video:'https://www.youtube.com/results?search_query=shoulder+press+machine+tecnica',cues:['Ajusta el asiento para partir con agarres cerca del hombro.','Mantén abdomen firme.','Sube con control.'],bad:['Arquear la espalda.','Elevar los hombros hacia las orejas.']},
    cablefly:{name:'Aperturas en polea',muscles:'Pectoral · deltoide anterior',sets:3,reps:'10–15',rest:60,anim:'push',video:'https://www.youtube.com/results?search_query=cable+fly+tecnica',cues:['Codos levemente flexionados.','Abraza hacia delante sin perder tensión.','Regresa lento.'],bad:['Convertirlo en un press.','Usar demasiado impulso.']},
    assistedpull:{name:'Dominada asistida',muscles:'Dorsal · bíceps',sets:3,reps:'6–12',rest:90,anim:'row',video:'https://www.youtube.com/results?search_query=dominada+asistida+maquina+tecnica',cues:['Inicia con hombros abajo.','Lleva el pecho hacia la barra.','Controla la bajada.'],bad:['Balancearte.','Acortar demasiado el recorrido.']},
    backext:{name:'Extensión lumbar en máquina/banco',muscles:'Erectores espinales · glúteos · isquiotibiales',sets:3,reps:'10–15',rest:60,anim:'hinge',video:'https://www.youtube.com/results?search_query=extension+lumbar+banco+tecnica',cues:['Bisagra desde la cadera.','Sube hasta una línea neutra.','Mantén el cuello relajado.'],bad:['Hiperextender arriba.']},
    crunchmachine:{name:'Crunch abdominal en máquina',muscles:'Core',sets:3,reps:'10–15',rest:55,anim:'push',video:'https://www.youtube.com/results?search_query=abdominal+crunch+machine+tecnica',cues:['Flexiona el tronco con control.','Exhala al cerrar.','Mantén la pelvis estable.'],bad:['Tirar con los brazos.','Usar demasiado peso.']},
    walk:{name:'Caminata rápida / trote suave',muscles:'Cardio · piernas',sets:1,reps:'20–35 min',rest:0,anim:'lunge',video:'https://www.youtube.com/results?search_query=tecnica+trote+principiantes',cues:['Ritmo en el que puedas mantener buena postura.','Aumenta tiempo gradualmente.'],bad:['Subir volumen muy rápido.']}
  };


  // 0.3: metadata visual y de equipamiento. Se mantiene separada de la definición
  // base para que ejercicios antiguos sigan siendo compatibles con datos 0.2.
  const equipmentLabels={machine:'Máquina guiada',barbell:'Barra',dumbbell:'Mancuernas',cable:'Polea/cable',bodyweight:'Peso corporal',bands:'Bandas',bench:'Banco',pullup:'Barra de dominadas',cardio:'Cardio'};
  const muscleLabels={chest:'Pecho',back:'Espalda',shoulders:'Hombros',biceps:'Bíceps',triceps:'Tríceps',core:'Core',glutes:'Glúteos',quads:'Cuádriceps',hamstrings:'Isquiotibiales',calves:'Pantorrillas',cardio:'Cardio'};
  const exerciseMeta={
    squat:{primary:['quads','glutes'],secondary:['core'],equipment:['barbell'],machine:['Hack squat','Smith','Prensa 45°'],machineType:'rack',pattern:'Sentadilla'},
    rdl:{primary:['hamstrings','glutes'],secondary:['back','core'],equipment:['barbell','dumbbell'],machine:['Smith','Barra libre','Mancuernas'],machineType:'rack',pattern:'Bisagra de cadera'},
    legpress:{primary:['quads','glutes'],secondary:[],equipment:['machine'],machine:['Prensa 45°','Prensa horizontal'],machineType:'legpress',pattern:'Empuje de piernas'},
    lunge:{primary:['quads','glutes'],secondary:['core'],equipment:['dumbbell','bodyweight'],machine:['Smith','Mancuernas'],machineType:'lunge',pattern:'Unilateral'},
    legext:{primary:['quads'],secondary:[],equipment:['machine'],machine:['Extensión de piernas'],machineType:'legext',pattern:'Extensión de rodilla'},
    legcurl:{primary:['hamstrings'],secondary:[],equipment:['machine'],machine:['Curl femoral sentado','Curl femoral acostado'],machineType:'legcurl',pattern:'Flexión de rodilla'},
    calves:{primary:['calves'],secondary:[],equipment:['machine','bodyweight'],machine:['Gemelo de pie','Gemelo sentado','Prensa'],machineType:'calf',pattern:'Flexión plantar'},
    bench:{primary:['chest'],secondary:['triceps','shoulders'],equipment:['barbell','bench'],machine:['Press pecho convergente','Smith','Hammer Strength'],machineType:'press',pattern:'Empuje horizontal'},
    incline:{primary:['chest'],secondary:['shoulders','triceps'],equipment:['dumbbell','bench'],machine:['Press inclinado máquina','Smith inclinado'],machineType:'press',pattern:'Empuje inclinado'},
    row:{primary:['back'],secondary:['biceps'],equipment:['cable','machine'],machine:['Remo sentado en polea','Remo convergente'],machineType:'row',pattern:'Tracción horizontal'},
    pulldown:{primary:['back'],secondary:['biceps'],equipment:['cable'],machine:['Jalón polea alta','Dominada asistida'],machineType:'pulldown',pattern:'Tracción vertical'},
    shoulder:{primary:['shoulders'],secondary:['triceps'],equipment:['dumbbell','barbell'],machine:['Press hombro máquina','Smith'],machineType:'press',pattern:'Empuje vertical'},
    lateral:{primary:['shoulders'],secondary:[],equipment:['dumbbell'],machine:['Elevación lateral máquina','Polea baja'],machineType:'lateral',pattern:'Abducción de hombro'},
    curl:{primary:['biceps'],secondary:[],equipment:['dumbbell','barbell'],machine:['Curl predicador máquina','Polea baja'],machineType:'curl',pattern:'Flexión de codo'},
    triceps:{primary:['triceps'],secondary:[],equipment:['cable'],machine:['Polea alta','Máquina de fondos asistidos'],machineType:'cable',pattern:'Extensión de codo'},
    hip:{primary:['glutes'],secondary:['hamstrings','core'],equipment:['barbell','bench'],machine:['Hip thrust machine','Smith'],machineType:'hip',pattern:'Extensión de cadera'},
    plank:{primary:['core'],secondary:['shoulders','glutes'],equipment:['bodyweight'],machine:['Colchoneta'],machineType:'body',pattern:'Antiextensión'},
    pushup:{primary:['chest'],secondary:['triceps','core'],equipment:['bodyweight'],machine:['Banco para regresión'],machineType:'body',pattern:'Empuje horizontal'},
    airSquat:{primary:['quads','glutes'],secondary:['core'],equipment:['bodyweight'],machine:['Banco como referencia'],machineType:'body',pattern:'Sentadilla'},
    split:{primary:['glutes','quads'],secondary:['core'],equipment:['bodyweight','dumbbell'],machine:['Banco','Smith'],machineType:'lunge',pattern:'Unilateral'},
    mountain:{primary:['core'],secondary:['shoulders'],equipment:['bodyweight'],machine:['Colchoneta'],machineType:'body',pattern:'Core dinámico'},
    burpee:{primary:['quads','chest'],secondary:['core','shoulders'],equipment:['bodyweight'],machine:['Sin máquina'],machineType:'body',pattern:'Full body'},
    stepup:{primary:['glutes','quads'],secondary:['core'],equipment:['bodyweight','dumbbell'],machine:['Cajón/Banco estable'],machineType:'lunge',pattern:'Unilateral'},
    chestpress:{primary:['chest'],secondary:['triceps','shoulders'],equipment:['Máquina'],machines:['Chest press','Press convergente'],motion:'push'},
    machinerow:{primary:['back'],secondary:['biceps'],equipment:['Máquina'],machines:['Remo Hammer','Remo convergente'],motion:'row'},
    hack:{primary:['quads','glutes'],secondary:['core'],equipment:['Máquina'],machines:['Hack squat'],motion:'squat'},
    shoulderpress:{primary:['shoulders'],secondary:['triceps'],equipment:['Máquina'],machines:['Shoulder press'],motion:'push'},
    cablefly:{primary:['chest'],secondary:['shoulders'],equipment:['Polea doble'],machines:['Crossover','Functional trainer'],motion:'push'},
    assistedpull:{primary:['back'],secondary:['biceps'],equipment:['Máquina'],machines:['Dominada asistida'],motion:'pull'},
    backext:{primary:['back','glutes'],secondary:['hamstrings'],equipment:['Banco / máquina'],machines:['Back extension'],motion:'hinge'},
    crunchmachine:{primary:['core'],secondary:[],equipment:['Máquina'],machines:['Abdominal crunch'],motion:'core'},
    walk:{primary:['cardio'],secondary:['quads','calves'],equipment:['cardio'],machine:['Cinta de correr','Elíptica opcional'],machineType:'cardio',pattern:'Cardio'},
    hack:{primary:['quads','glutes'],secondary:['core'],equipment:['machine'],machine:['Hack squat'],machineType:'legpress',pattern:'Sentadilla guiada'},
    chestpress:{primary:['chest'],secondary:['triceps','shoulders'],equipment:['machine'],machine:['Press pecho convergente'],machineType:'press',pattern:'Empuje horizontal'},
    pecdeck:{primary:['chest'],secondary:[],equipment:['machine'],machine:['Pec deck / contractor'],machineType:'pecdeck',pattern:'Aducción horizontal'},
    machinerow:{primary:['back'],secondary:['biceps'],equipment:['machine'],machine:['Remo convergente','Remo pecho apoyado'],machineType:'row',pattern:'Tracción horizontal'},
    assistedpull:{primary:['back'],secondary:['biceps'],equipment:['machine'],machine:['Dominada asistida'],machineType:'pulldown',pattern:'Tracción vertical'},
    shouldermachine:{primary:['shoulders'],secondary:['triceps'],equipment:['machine'],machine:['Press de hombros guiado'],machineType:'press',pattern:'Empuje vertical'},
    lateralmachine:{primary:['shoulders'],secondary:[],equipment:['machine'],machine:['Elevación lateral máquina'],machineType:'lateral',pattern:'Abducción de hombro'},
    adductor:{primary:['glutes'],secondary:['quads'],equipment:['machine'],machine:['Aductor de cadera'],machineType:'adductor',pattern:'Aducción de cadera'},
    abductor:{primary:['glutes'],secondary:[],equipment:['machine'],machine:['Abductor de cadera'],machineType:'abductor',pattern:'Abducción de cadera'},
    backext:{primary:['back','glutes'],secondary:['hamstrings'],equipment:['machine','bodyweight'],machine:['Banco romano','Extensión lumbar máquina'],machineType:'backext',pattern:'Extensión de cadera/columna'},
    crunchmachine:{primary:['core'],secondary:[],equipment:['machine'],machine:['Crunch abdominal máquina'],machineType:'crunch',pattern:'Flexión de tronco'},
    kickback:{primary:['glutes'],secondary:['hamstrings'],equipment:['cable','machine'],machine:['Patada glúteo polea','Glute machine'],machineType:'cable',pattern:'Extensión de cadera'},
    cablecurl:{primary:['biceps'],secondary:[],equipment:['cable'],machine:['Polea baja'],machineType:'cable',pattern:'Flexión de codo'},
    dipmachine:{primary:['triceps','chest'],secondary:['shoulders'],equipment:['machine'],machine:['Fondos asistidos / dips machine'],machineType:'press',pattern:'Empuje'}
  };

  Object.assign(ex,{
    hack:{name:'Hack squat',muscles:'Cuádriceps · glúteos',sets:4,reps:'8–12',rest:90,anim:'squat',video:'https://www.youtube.com/results?search_query=hack+squat+tecnica',cues:['Espalda completamente apoyada.','Pies firmes y rodillas siguiendo la línea de los pies.','Desciende hasta un rango cómodo sin despegar la pelvis.'],bad:['Bloquear las rodillas con violencia.','Despegar talones o pelvis.']},
    chestpress:{name:'Press de pecho en máquina',muscles:'Pectoral · tríceps · hombro anterior',sets:4,reps:'8–12',rest:85,anim:'push',video:'https://www.youtube.com/results?search_query=press+pecho+maquina+tecnica',cues:['Ajusta el asiento para que las empuñaduras queden a la altura media del pecho.','Mantén escápulas estables.','Empuja sin despegar la espalda.'],bad:['Hombros encogidos.','Asiento demasiado alto o bajo.']},
    pecdeck:{name:'Aperturas en pec deck',muscles:'Pectoral',sets:3,reps:'10–15',rest:60,anim:'push',video:'https://www.youtube.com/results?search_query=pec+deck+tecnica',cues:['Pecho apoyado y hombros abajo.','Cierra con control sin golpear las placas.'],bad:['Exceso de rango detrás del tronco.']},
    machinerow:{name:'Remo en máquina',muscles:'Espalda · bíceps',sets:4,reps:'8–12',rest:80,anim:'row',video:'https://www.youtube.com/results?search_query=remo+maquina+tecnica',cues:['Apoya el pecho si la máquina lo permite.','Lleva codos atrás sin elevar hombros.'],bad:['Tirar con impulso del torso.']},
    assistedpull:{name:'Dominada asistida',muscles:'Dorsales · bíceps',sets:3,reps:'6–12',rest:90,anim:'row',video:'https://www.youtube.com/results?search_query=dominada+asistida+maquina+tecnica',cues:['Inicia con hombros abajo.','Lleva el pecho hacia la barra.','Controla la bajada.'],bad:['Encoger hombros.','Usar impulso.']},
    shouldermachine:{name:'Press de hombros en máquina',muscles:'Deltoides · tríceps',sets:3,reps:'8–12',rest:75,anim:'push',video:'https://www.youtube.com/results?search_query=press+hombros+maquina+tecnica',cues:['Ajusta el asiento para comenzar con codos cómodos.','Mantén espalda apoyada.'],bad:['Arquear excesivamente la zona lumbar.']},
    lateralmachine:{name:'Elevación lateral en máquina',muscles:'Deltoide medio',sets:3,reps:'12–18',rest:55,anim:'raise',video:'https://www.youtube.com/results?search_query=elevacion+lateral+maquina+tecnica',cues:['Alinea el hombro con el eje de la máquina.','Sube sin encoger trapecios.'],bad:['Usar impulso.']},
    adductor:{name:'Aductor en máquina',muscles:'Aductores · cadera',sets:3,reps:'12–18',rest:55,anim:'squat',video:'https://www.youtube.com/results?search_query=aductor+maquina+tecnica',cues:['Ajusta un rango cómodo.','Cierra con control y pausa breve.'],bad:['Rebotar al abrir.']},
    abductor:{name:'Abductor en máquina',muscles:'Glúteo medio · cadera',sets:3,reps:'12–20',rest:55,anim:'squat',video:'https://www.youtube.com/results?search_query=abductor+maquina+tecnica',cues:['Pelvis estable contra el respaldo.','Abre de forma controlada.'],bad:['Balancear el torso.']},
    backext:{name:'Extensión lumbar / banco romano',muscles:'Erectores · glúteos · isquiotibiales',sets:3,reps:'10–15',rest:60,anim:'hinge',video:'https://www.youtube.com/results?search_query=extension+lumbar+banco+romano+tecnica',cues:['Mueve desde la cadera.','Termina en línea neutra, no hiperextiendas.'],bad:['Subir más allá de la posición neutra.']},
    crunchmachine:{name:'Crunch abdominal en máquina',muscles:'Abdominales',sets:3,reps:'10–15',rest:55,anim:'curl',video:'https://www.youtube.com/results?search_query=crunch+abdominal+maquina+tecnica',cues:['Flexiona el tronco con control.','Exhala al cerrar.'],bad:['Tirar solo con brazos.']},
    kickback:{name:'Patada de glúteo en polea',muscles:'Glúteos · isquiotibiales',sets:3,reps:'12–15 c/pierna',rest:55,anim:'hinge',video:'https://www.youtube.com/results?search_query=patada+gluteo+polea+tecnica',cues:['Pelvis estable.','Extiende la cadera sin arquear la espalda.'],bad:['Convertirlo en un balanceo.']},
    cablecurl:{name:'Curl de bíceps en polea',muscles:'Bíceps · braquial',sets:3,reps:'10–15',rest:55,anim:'curl',video:'https://www.youtube.com/results?search_query=curl+biceps+polea+tecnica',cues:['Codos fijos.','Mantén tensión durante todo el recorrido.'],bad:['Balancear tronco.']},
    dipmachine:{name:'Fondos asistidos / máquina',muscles:'Tríceps · pectoral',sets:3,reps:'8–12',rest:75,anim:'push',video:'https://www.youtube.com/results?search_query=fondos+asistidos+maquina+tecnica',cues:['Hombros lejos de orejas.','Controla la profundidad.'],bad:['Hundir hombros al fondo.']}
  });


  // NexoFit 0.3 — biblioteca ampliada y metadatos visuales.
  Object.assign(ex, {
    hack:{name:'Hack squat',muscles:'Cuádriceps · glúteos',sets:4,reps:'8–12',rest:90,anim:'squat',video:'https://www.youtube.com/results?search_query=hack+squat+tecnica+correcta',cues:['Espalda apoyada durante todo el recorrido.','Rodillas siguen la línea de los pies.','Empuja con el pie completo.'],bad:['Despegar la pelvis del respaldo.','Cerrar las rodillas hacia dentro.']},
    smithSquat:{name:'Sentadilla en Smith',muscles:'Cuádriceps · glúteos',sets:4,reps:'8–12',rest:90,anim:'squat',video:'https://www.youtube.com/results?search_query=sentadilla+smith+tecnica',cues:['Ajusta los pies para un recorrido cómodo.','Controla la bajada.','Mantén el tronco estable.'],bad:['Forzar una profundidad que pierda control.']},
    goblet:{name:'Sentadilla goblet',muscles:'Cuádriceps · glúteos · core',sets:3,reps:'10–15',rest:70,anim:'squat',video:'https://www.youtube.com/results?search_query=sentadilla+goblet+tecnica',cues:['Carga cerca del pecho.','Pecho alto y abdomen activo.'],bad:['Dejar caer el torso hacia delante.']},
    chestpress:{name:'Press de pecho en máquina',muscles:'Pectoral · tríceps · deltoide anterior',sets:4,reps:'8–12',rest:80,anim:'push',video:'https://www.youtube.com/results?search_query=chest+press+maquina+tecnica',cues:['Ajusta el asiento para alinear empuñaduras y pecho.','Escápulas estables.','Controla el regreso.'],bad:['Elevar hombros hacia las orejas.']},
    pecdeck:{name:'Pec deck / contractor',muscles:'Pectoral',sets:3,reps:'10–15',rest:60,anim:'push',video:'https://www.youtube.com/results?search_query=pec+deck+tecnica',cues:['Codos en una posición cómoda.','Junta los brazos sin perder control.'],bad:['Golpear los topes o usar impulso.']},
    cablefly:{name:'Cruce de poleas',muscles:'Pectoral · deltoide anterior',sets:3,reps:'10–15',rest:60,anim:'push',video:'https://www.youtube.com/results?search_query=cruce+de+poleas+pecho+tecnica',cues:['Mantén una leve flexión de codos.','Abraza hacia delante con control.'],bad:['Convertirlo en un press por exceso de carga.']},
    machinerow:{name:'Remo en máquina',muscles:'Espalda · romboides · bíceps',sets:4,reps:'8–12',rest:80,anim:'row',video:'https://www.youtube.com/results?search_query=remo+maquina+tecnica',cues:['Pecho estable contra el apoyo si existe.','Lleva codos hacia atrás.'],bad:['Encoger hombros o tirar con impulso.']},
    neutralPulldown:{name:'Jalón neutro',muscles:'Dorsal · bíceps',sets:4,reps:'8–12',rest:80,anim:'row',video:'https://www.youtube.com/results?search_query=jalon+neutro+tecnica',cues:['Pecho alto.','Inicia bajando hombros.','Lleva agarre hacia la parte alta del pecho.'],bad:['Balancear el torso.']},
    pullup:{name:'Dominadas',muscles:'Dorsal · bíceps · core',sets:4,reps:'5–10',rest:100,anim:'row',video:'https://www.youtube.com/results?search_query=dominadas+tecnica+correcta',cues:['Parte desde hombros activos.','Sube sin patada.','Controla la bajada.'],bad:['Balancearte para completar repeticiones.']},
    assistedPullup:{name:'Dominada asistida',muscles:'Dorsal · bíceps',sets:4,reps:'8–12',rest:85,anim:'row',video:'https://www.youtube.com/results?search_query=dominada+asistida+maquina+tecnica',cues:['Usa la asistencia justa.','Mantén el torso estable.'],bad:['Dejar que la máquina controle el descenso.']},
    rearDelt:{name:'Pájaros / reverse pec deck',muscles:'Deltoide posterior · espalda alta',sets:3,reps:'12–18',rest:55,anim:'raise',video:'https://www.youtube.com/results?search_query=reverse+pec+deck+tecnica',cues:['Hombros abajo.','Abre desde el hombro, no desde la mano.'],bad:['Usar demasiado peso y encoger hombros.']},
    hammer:{name:'Curl martillo',muscles:'Bíceps · braquial · antebrazo',sets:3,reps:'10–15',rest:55,anim:'curl',video:'https://www.youtube.com/results?search_query=curl+martillo+tecnica',cues:['Muñeca neutra.','Codos quietos.'],bad:['Balancear el torso.']},
    preacher:{name:'Curl predicador',muscles:'Bíceps',sets:3,reps:'8–12',rest:60,anim:'curl',video:'https://www.youtube.com/results?search_query=curl+predicador+maquina+tecnica',cues:['Brazo apoyado.','Extiende sin bloquear agresivamente.'],bad:['Levantar el hombro del apoyo.']},
    ropeTriceps:{name:'Tríceps con cuerda',muscles:'Tríceps',sets:3,reps:'10–15',rest:55,anim:'push',video:'https://www.youtube.com/results?search_query=triceps+cuerda+polea+tecnica',cues:['Codos pegados al cuerpo.','Separa la cuerda al final sin mover hombros.'],bad:['Inclinar todo el cuerpo para mover la carga.']},
    dip:{name:'Fondos asistidos',muscles:'Tríceps · pectoral · hombros',sets:3,reps:'8–12',rest:80,anim:'push',video:'https://www.youtube.com/results?search_query=fondos+asistidos+maquina+tecnica',cues:['Hombros lejos de las orejas.','Baja solo hasta un rango cómodo.'],bad:['Hundir excesivamente los hombros.']},
    abductor:{name:'Abductores en máquina',muscles:'Glúteo medio · glúteos',sets:3,reps:'12–20',rest:50,anim:'lunge',video:'https://www.youtube.com/results?search_query=abductores+maquina+tecnica',cues:['Pelvis estable.','Abre con control.'],bad:['Rebotar contra los topes.']},
    adductor:{name:'Aductores en máquina',muscles:'Aductores',sets:3,reps:'12–20',rest:50,anim:'lunge',video:'https://www.youtube.com/results?search_query=aductores+maquina+tecnica',cues:['Ajusta un rango cómodo.','Cierra con control.'],bad:['Forzar una apertura molesta.']},
    gluteKick:{name:'Patada de glúteo en polea',muscles:'Glúteos · isquiotibiales',sets:3,reps:'12–15 c/pierna',rest:50,anim:'hinge',video:'https://www.youtube.com/results?search_query=patada+gluteo+polea+tecnica',cues:['Pelvis mirando al frente.','Extiende la cadera sin arquear la espalda.'],bad:['Girar la pelvis para ganar recorrido.']},
    backext:{name:'Extensión lumbar / banco 45°',muscles:'Erectores espinales · glúteos · isquiotibiales',sets:3,reps:'10–15',rest:60,anim:'hinge',video:'https://www.youtube.com/results?search_query=extension+lumbar+banco+45+tecnica',cues:['Movimiento desde la cadera.','Columna neutra.'],bad:['Hiperextender la zona lumbar arriba.']},
    crunchMachine:{name:'Crunch en máquina',muscles:'Core · recto abdominal',sets:3,reps:'10–15',rest:50,anim:'push',video:'https://www.youtube.com/results?search_query=crunch+maquina+tecnica',cues:['Flexiona el tronco con el abdomen.','Vuelve lentamente.'],bad:['Tirar con los brazos.']},
    cableCrunch:{name:'Crunch en polea',muscles:'Core · recto abdominal',sets:3,reps:'10–15',rest:50,anim:'push',video:'https://www.youtube.com/results?search_query=crunch+polea+tecnica',cues:['Cadera relativamente estable.','Acerca costillas a pelvis.'],bad:['Convertirlo en una bisagra de cadera.']},
    bike:{name:'Bicicleta estática',muscles:'Cardio · cuádriceps · glúteos',sets:1,reps:'15–35 min',rest:0,anim:'lunge',video:'https://www.youtube.com/results?search_query=bicicleta+estatica+ajuste+tecnica',cues:['Ajusta altura del sillín.','Mantén cadencia sostenible.'],bad:['Sillín demasiado bajo.']},
    elliptical:{name:'Elíptica',muscles:'Cardio · piernas',sets:1,reps:'15–35 min',rest:0,anim:'lunge',video:'https://www.youtube.com/results?search_query=eliptica+tecnica+correcta',cues:['Postura alta.','Empuja y tira suavemente con brazos.'],bad:['Colgarse de los apoyos.']},
    bandRow:{name:'Remo con banda',muscles:'Espalda · bíceps',sets:4,reps:'12–20',rest:45,anim:'row',video:'https://www.youtube.com/results?search_query=remo+banda+elastica+tecnica',cues:['Ancla la banda de forma segura.','Codos hacia atrás.'],bad:['Usar un anclaje inestable.']},
    bandPress:{name:'Press de pecho con banda',muscles:'Pectoral · tríceps',sets:4,reps:'12–20',rest:45,anim:'push',video:'https://www.youtube.com/results?search_query=press+pecho+banda+elastica+tecnica',cues:['Anclaje seguro.','Empuja al frente manteniendo tronco estable.'],bad:['Permitir que la banda roce o se deslice del anclaje.']}
  });

  const exerciseInfo = {
    squat:{primary:['Cuádriceps','Glúteos'],secondary:['Core'],equipment:['barbell','rack'],machines:['Barra libre + rack','Smith','Hack squat'],alts:['smithSquat','hack','legpress','goblet']},
    rdl:{primary:['Isquiotibiales','Glúteos'],secondary:['Espalda'],equipment:['barbell'],machines:['Barra','Mancuernas','Smith'],alts:['backext','hip']},
    legpress:{primary:['Cuádriceps','Glúteos'],secondary:[],equipment:['legpress'],machines:['Prensa 45°','Prensa horizontal'],alts:['hack','smithSquat','squat']},
    lunge:{primary:['Glúteos','Cuádriceps'],secondary:['Core'],equipment:['dumbbell'],machines:['Mancuernas','Smith','Peso corporal'],alts:['split','stepup','legpress']},
    legext:{primary:['Cuádriceps'],secondary:[],equipment:['legext'],machines:['Extensión de cuádriceps'],alts:['hack','legpress','goblet']},
    legcurl:{primary:['Isquiotibiales'],secondary:[],equipment:['legcurl'],machines:['Curl sentado','Curl acostado','Curl de pie'],alts:['rdl','backext']},
    calves:{primary:['Gemelos'],secondary:['Sóleo'],equipment:['calf'],machines:['Máquina de gemelos','Prensa','Smith'],alts:[]},
    bench:{primary:['Pectoral'],secondary:['Tríceps','Hombros'],equipment:['barbell','bench'],machines:['Barra + banco','Smith','Chest press'],alts:['chestpress','incline','pushup','cablefly']},
    incline:{primary:['Pectoral'],secondary:['Hombros','Tríceps'],equipment:['dumbbell','bench'],machines:['Mancuernas','Smith inclinado','Chest press inclinado'],alts:['chestpress','bench','cablefly']},
    row:{primary:['Espalda'],secondary:['Bíceps'],equipment:['cable'],machines:['Polea baja','Remo sentado','Remo en máquina'],alts:['machinerow','bandRow']},
    pulldown:{primary:['Dorsal','Espalda'],secondary:['Bíceps'],equipment:['pulldown'],machines:['Jalón al pecho','Polea alta','Dominada asistida'],alts:['neutralPulldown','assistedPullup','pullup']},
    shoulder:{primary:['Hombros'],secondary:['Tríceps'],equipment:['dumbbell'],machines:['Mancuernas','Máquina shoulder press','Smith'],alts:['lateral']},
    lateral:{primary:['Hombros'],secondary:[],equipment:['dumbbell'],machines:['Mancuernas','Polea','Máquina lateral'],alts:['rearDelt']},
    curl:{primary:['Bíceps'],secondary:['Antebrazo'],equipment:['dumbbell'],machines:['Mancuernas','Polea','Predicador'],alts:['hammer','preacher']},
    triceps:{primary:['Tríceps'],secondary:[],equipment:['cable'],machines:['Polea','Cuerda','Máquina fondos'],alts:['ropeTriceps','dip']},
    hip:{primary:['Glúteos'],secondary:['Isquiotibiales'],equipment:['barbell','bench'],machines:['Barra + banco','Máquina hip thrust','Smith'],alts:['gluteKick','backext']},
    plank:{primary:['Core'],secondary:['Glúteos','Hombros'],equipment:['bodyweight'],machines:['Colchoneta / suelo'],alts:['crunchMachine','cableCrunch']},
    pushup:{primary:['Pectoral'],secondary:['Tríceps','Core'],equipment:['bodyweight'],machines:['Suelo','Banco'],alts:['bandPress','bench']},
    airSquat:{primary:['Cuádriceps','Glúteos'],secondary:['Core'],equipment:['bodyweight'],machines:['Peso corporal','Banco'],alts:['goblet','squat']},
    split:{primary:['Glúteos','Cuádriceps'],secondary:['Core'],equipment:['bodyweight'],machines:['Banco','Mancuernas','Smith'],alts:['lunge','stepup']},
    mountain:{primary:['Core'],secondary:['Hombros','Cardio'],equipment:['bodyweight'],machines:['Suelo'],alts:['burpee']},
    burpee:{primary:['Full body','Cardio'],secondary:['Core'],equipment:['bodyweight'],machines:['Suelo'],alts:['mountain']},
    stepup:{primary:['Glúteos','Cuádriceps'],secondary:['Core'],equipment:['bodyweight'],machines:['Banco / cajón','Mancuernas'],alts:['split','lunge']},
    walk:{primary:['Cardio','Piernas'],secondary:[],equipment:['bodyweight'],machines:['Exterior','Cinta'],alts:['bike','elliptical']},
    hack:{primary:['Cuádriceps'],secondary:['Glúteos'],equipment:['hack'],machines:['Hack squat'],alts:['legpress','smithSquat','squat']},
    smithSquat:{primary:['Cuádriceps'],secondary:['Glúteos'],equipment:['smith'],machines:['Smith / multipower'],alts:['hack','legpress','goblet']},
    goblet:{primary:['Cuádriceps','Glúteos'],secondary:['Core'],equipment:['dumbbell'],machines:['Mancuerna','Kettlebell'],alts:['airSquat','legpress']},
    chestpress:{primary:['Pectoral'],secondary:['Tríceps','Hombros'],equipment:['chestpress'],machines:['Chest press','Press convergente'],alts:['bench','incline','cablefly']},
    pecdeck:{primary:['Pectoral'],secondary:[],equipment:['pecdeck'],machines:['Pec deck / contractor'],alts:['cablefly','chestpress']},
    cablefly:{primary:['Pectoral'],secondary:['Hombros'],equipment:['cable'],machines:['Poleas cruzadas'],alts:['pecdeck','chestpress']},
    machinerow:{primary:['Espalda'],secondary:['Bíceps'],equipment:['rowmachine'],machines:['Remo sentado','Remo convergente'],alts:['row','bandRow']},
    neutralPulldown:{primary:['Dorsal','Espalda'],secondary:['Bíceps'],equipment:['pulldown'],machines:['Polea alta + agarre neutro'],alts:['pulldown','assistedPullup']},
    pullup:{primary:['Dorsal','Espalda'],secondary:['Bíceps','Core'],equipment:['pullup'],machines:['Barra de dominadas'],alts:['assistedPullup','pulldown']},
    assistedPullup:{primary:['Dorsal','Espalda'],secondary:['Bíceps'],equipment:['assisted'],machines:['Dominada asistida'],alts:['pulldown','pullup']},
    rearDelt:{primary:['Hombros','Espalda'],secondary:[],equipment:['pecdeck'],machines:['Reverse pec deck','Polea'],alts:['lateral']},
    hammer:{primary:['Bíceps','Antebrazo'],secondary:[],equipment:['dumbbell'],machines:['Mancuernas','Cuerda en polea'],alts:['curl','preacher']},
    preacher:{primary:['Bíceps'],secondary:[],equipment:['preacher'],machines:['Predicador','Máquina de bíceps'],alts:['curl','hammer']},
    ropeTriceps:{primary:['Tríceps'],secondary:[],equipment:['cable'],machines:['Polea + cuerda'],alts:['triceps','dip']},
    dip:{primary:['Tríceps'],secondary:['Pectoral','Hombros'],equipment:['assisted'],machines:['Fondos asistidos'],alts:['ropeTriceps','triceps']},
    abductor:{primary:['Glúteos'],secondary:[],equipment:['abductor'],machines:['Abductores'],alts:['gluteKick']},
    adductor:{primary:['Aductores'],secondary:[],equipment:['adductor'],machines:['Aductores'],alts:['lunge']},
    gluteKick:{primary:['Glúteos'],secondary:['Isquiotibiales'],equipment:['cable'],machines:['Polea baja + tobillera'],alts:['hip','abductor']},
    backext:{primary:['Espalda','Glúteos'],secondary:['Isquiotibiales'],equipment:['backext'],machines:['Banco 45°','Máquina lumbar'],alts:['rdl','hip']},
    crunchMachine:{primary:['Core'],secondary:[],equipment:['crunch'],machines:['Máquina abdominal'],alts:['cableCrunch','plank']},
    cableCrunch:{primary:['Core'],secondary:[],equipment:['cable'],machines:['Polea alta + cuerda'],alts:['crunchMachine','plank']},
    bike:{primary:['Cardio','Cuádriceps'],secondary:['Glúteos'],equipment:['cardio'],machines:['Bicicleta estática'],alts:['elliptical','walk']},
    elliptical:{primary:['Cardio','Piernas'],secondary:[],equipment:['cardio'],machines:['Elíptica'],alts:['bike','walk']},
    bandRow:{primary:['Espalda'],secondary:['Bíceps'],equipment:['bands'],machines:['Banda elástica'],alts:['row']},
    bandPress:{primary:['Pectoral'],secondary:['Tríceps'],equipment:['bands'],machines:['Banda elástica'],alts:['pushup']}
  };
  Object.entries(exerciseInfo).forEach(([id,info])=>Object.assign(ex[id]||{},info));
  Object.entries(ex).forEach(([id,e])=>{
    if(!e.primary) e.primary=String(e.muscles||'').split('·').slice(0,1).map(x=>x.trim());
    if(!e.secondary) e.secondary=String(e.muscles||'').split('·').slice(1).map(x=>x.trim());
    if(!e.equipment) e.equipment=['bodyweight'];
    if(!e.machines) e.machines=e.equipment.map(x=>x);
    if(!e.alts) e.alts=[];
  });

  const equipmentCatalog = [
    ['barbell','Barra'],['dumbbell','Mancuernas'],['rack','Rack'],['bench','Banco'],['cable','Poleas'],['smith','Smith'],['legpress','Prensa'],['hack','Hack squat'],['legext','Extensión de piernas'],['legcurl','Curl femoral'],['chestpress','Chest press'],['rowmachine','Remo máquina'],['pulldown','Jalón'],['pecdeck','Pec deck'],['assisted','Dominadas/fondos asistidos'],['preacher','Predicador'],['abductor','Abductores'],['adductor','Aductores'],['backext','Banco lumbar'],['crunch','Abdominales máquina'],['calf','Gemelos'],['cardio','Cardio'],['pullup','Barra dominadas'],['bands','Bandas'],['bodyweight','Peso corporal']
  ];
  const fullGymEquipment = equipmentCatalog.map(x=>x[0]).filter(x=>x!=='bands');
  const basicGymEquipment = ['dumbbell','bench','cable','smith','legpress','pulldown','rowmachine','cardio','bodyweight'];

  const gymTemplates = [
    {name:'Tren inferior A',subtitle:'Cuádriceps, glúteos e isquios',ids:['squat','rdl','legpress','legcurl','legext','calves']},
    {name:'Tren superior A',subtitle:'Pecho, espalda y hombros',ids:['bench','row','pulldown','incline','lateral','triceps']},
    {name:'Full body A',subtitle:'Base completa y eficiente',ids:['squat','bench','row','rdl','pulldown','plank']},
    {name:'Full body B',subtitle:'Máquinas + libres',ids:['hack','chestpress','machinerow','hip','shouldermachine','cablecurl','crunchmachine']},
    {name:'Tren inferior B',subtitle:'Glúteos, piernas y estabilidad',ids:['hip','hack','legcurl','legext','abductor','calves','backext']},
    {name:'Tren superior B',subtitle:'Espalda, pecho y brazos',ids:['incline','assistedpull','machinerow','shouldermachine','lateralmachine','cablecurl','dipmachine']}
  ];
  const outdoorTemplates = [
    {name:'Full body parque',subtitle:'Fuerza con peso corporal',ids:['airSquat','pushup','lunge','mountain','plank','burpee']},
    {name:'Piernas al aire libre',subtitle:'Fuerza unilateral y control',ids:['airSquat','split','stepup','lunge','calves','plank']},
    {name:'Acondicionamiento',subtitle:'Cardio + fuerza',ids:['walk','airSquat','pushup','mountain','burpee','plank']},
    {name:'Full body control',subtitle:'Técnica y volumen',ids:['split','pushup','airSquat','stepup','plank','mountain']}
  ];


  const load = (k,fallback) => { try { const v=localStorage.getItem(k); return v?JSON.parse(v):fallback; } catch(e){ return fallback; } };
  const save = (k,v) => localStorage.setItem(k,JSON.stringify(v));
  const dateKey = d => { const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0'); return `${y}-${m}-${day}`; };
  const today = () => dateKey(new Date());
  const fmtDate = iso => new Date(iso+'T12:00:00').toLocaleDateString('es-CL',{day:'2-digit',month:'short'});
  const vibrate = ms => { try { if(window.NexoNative) NexoNative.vibrate(ms); else if(navigator.vibrate) navigator.vibrate(ms); } catch(e){} };
  const openExternal = url => { try { if(window.NexoNative) NexoNative.openExternal(url); else window.open(url,'_blank'); } catch(e){ window.location.href=url; } };
  const keepAwake = on => { try { if(window.NexoNative?.setKeepScreenOn) NexoNative.setKeepScreenOn(!!on); } catch(e){} };
  const toast = msg => { toastEl.textContent=msg; toastEl.classList.add('show'); clearTimeout(toast._t); toast._t=setTimeout(()=>toastEl.classList.remove('show'),1800); };
  const escapeHtml = s => String(s).replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m]));

  function init(){
    if(!localStorage.getItem(KEYS.profile)){
      const legacyProfile=localStorage.getItem(LEGACY.profile)?load(LEGACY.profile,null):(localStorage.getItem(LEGACY_V1.profile)?load(LEGACY_V1.profile,null):null);
      if(legacyProfile){
        const migrated={...defaultProfile(),...legacyProfile};
        migrated.environment=migrated.environment||'gym'; migrated.equipmentPreset=migrated.equipmentPreset||'full'; migrated.equipment=migrated.equipment?.length?migrated.equipment:fullGymEquipment;
        migrated.priority=migrated.priority||'balanced'; migrated.avoid=migrated.avoid||[]; migrated.mixedGymDays=migrated.mixedGymDays||Math.ceil((migrated.days||4)/2); migrated.includeKegel=KEGEL_ENABLED?true:false;
        save(KEYS.profile,migrated);
        const lp=localStorage.getItem(LEGACY.plan)?load(LEGACY.plan,null):load(LEGACY_V1.plan,null); if(lp) save(KEYS.plan,lp);
        save(KEYS.logs,localStorage.getItem(LEGACY.logs)?load(LEGACY.logs,[]):load(LEGACY_V1.logs,[]));
        if(KEGEL_ENABLED) save(KEYS.kegel,localStorage.getItem(LEGACY.kegel)?load(LEGACY.kegel,defaultKegel()):load(LEGACY_V1.kegel,defaultKegel()));
      }
    }
    state.profile = load(KEYS.profile,null);
    state.logs = load(KEYS.logs,[]);
    state.kegel = KEGEL_ENABLED ? load(KEYS.kegel,defaultKegel()) : null;
    state.plan = load(KEYS.plan,null);
    const kNav=$('.nav-item[data-tab="kegel"]'); if(kNav && (!KEGEL_ENABLED || state.profile?.includeKegel===false)) kNav.remove();
    const nav=$('.bottom-nav'); if(nav) nav.style.gridTemplateColumns=`repeat(${KEGEL_ENABLED && state.profile?.includeKegel!==false?5:4},1fr)`;
    document.title=KEGEL_ENABLED?'NexoFit Plus':'NexoFit';
    if(!state.profile){ state.profile = defaultProfile(); showOnboarding(true); }
    else { state.environment=state.profile.environment==='outdoor'?'outdoor':'gym'; if(!state.plan || state.plan.version<3) regeneratePlan(false); render(); }
    bindNav();
    $('#settingsBtn').addEventListener('click',()=>{ state.tab='profile'; render(); syncNav(); });
  }
  function defaultKegel(){ return {level:'Intermedio',mode:'control',contract:5,hold:2,relax:6,reps:8,sets:3,completed:0,last:null}; }
  function defaultProfile(){ return {name:'Daniel',age:31,weight:70,height:164,goal:'muscle',level:'Intermedio',days:4,environment:'gym',sessionMinutes:55,equipmentPreset:'full',equipment:[...fullGymEquipment],priority:'balanced',avoid:[],limitations:'',mixedGymDays:2,includeKegel:KEGEL_ENABLED}; }
  function defaultEquipment(env){
    if(env==='outdoor') return ['bodyweight','bands','pullup'];
    if(env==='mixed') return ['machine','dumbbell','cable','bodyweight','bands','pullup','bench'];
    return ['machine','barbell','dumbbell','cable','bench','bodyweight'];
  }
  function envLabel(env){ return env==='gym'?'Gimnasio':env==='outdoor'?'Aire libre':'Mixto'; }
  function actualEnvLabel(env){ return env==='gym'?'🏋 Gimnasio':'🌳 Aire libre'; }
  function metaFor(id){ return exerciseMeta[id]||{primary:[],secondary:[],equipment:['bodyweight'],machine:['Sin equipamiento especial'],machineType:'body',pattern:'Movimiento'}; }
  function hasEquipment(id,profile,env){
    const m=metaFor(id); const available=new Set(profile.equipment||defaultEquipment(profile.environment)); if(env==='outdoor') return m.equipment.some(x=>x==='bodyweight'||x==='cardio'||available.has(x));
    return m.equipment.some(x=>available.has(x)) || m.equipment.includes('bodyweight');
  }
  function muscleSummary(day){
    const counts={}; (day?.exercises||[]).forEach(e=>metaFor(e.id).primary.forEach(m=>counts[m]=(counts[m]||0)+1));
    return Object.entries(counts).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([m,n])=>({key:m,label:muscleLabels[m]||m,n}));
  }
  function muscleNames(id){const m=metaFor(id);return [...m.primary,...m.secondary].map(x=>muscleLabels[x]||x);}
  function muscleMapSvg(input,compact=false){
    const keys=Array.isArray(input)?input:input?.exercises?muscleSummary(input).map(x=>x.key):[...metaFor(input).primary,...metaFor(input).secondary];
    const on=k=>keys.includes(k), a='#5eead4', b='#a3e635', off='#29424f', outline='#7894a2';
    const z=(k,shape,secondary=false)=>shape.replace('FILL',on(k)?(secondary?b:a):off);
    return `<svg class="muscle-map ${compact?'compact':''}" viewBox="0 0 180 155" role="img" aria-label="Mapa muscular de referencia"><g opacity=".95"><circle cx="48" cy="18" r="10" fill="${outline}"/><path d="M37 32 Q48 25 59 32 L64 72 Q57 82 53 91 L43 91 Q39 82 32 72Z" fill="#17313e" stroke="${outline}" stroke-width="2"/>${z('shoulders','<circle cx="34" cy="39" r="7" fill="FILL"/>')}${z('shoulders','<circle cx="62" cy="39" r="7" fill="FILL"/>')}${z('chest','<path d="M38 39 Q48 33 58 39 L56 53 Q48 58 40 53Z" fill="FILL"/>')}${z('biceps','<rect x="27" y="47" width="7" height="24" rx="3.5" fill="FILL"/>')}${z('triceps','<rect x="62" y="47" width="7" height="24" rx="3.5" fill="FILL"/>')}${z('core','<rect x="41" y="56" width="14" height="28" rx="6" fill="FILL"/>')}${z('quads','<rect x="39" y="91" width="10" height="35" rx="5" fill="FILL"/>')}${z('quads','<rect x="51" y="91" width="10" height="35" rx="5" fill="FILL"/>')}${z('calves','<rect x="39" y="127" width="9" height="20" rx="4" fill="FILL"/>')}${z('calves','<rect x="52" y="127" width="9" height="20" rx="4" fill="FILL"/>')}<circle cx="132" cy="18" r="10" fill="${outline}"/><path d="M121 32 Q132 25 143 32 L148 72 Q141 82 137 91 L127 91 Q123 82 116 72Z" fill="#17313e" stroke="${outline}" stroke-width="2"/>${z('back','<path d="M122 39 Q132 33 142 39 L140 66 Q132 73 124 66Z" fill="FILL"/>')}${z('triceps','<rect x="111" y="47" width="7" height="24" rx="3.5" fill="FILL"/>')}${z('triceps','<rect x="146" y="47" width="7" height="24" rx="3.5" fill="FILL"/>')}${z('glutes','<path d="M124 78 Q132 73 140 78 L139 94 Q132 100 125 94Z" fill="FILL"/>')}${z('hamstrings','<rect x="123" y="94" width="10" height="32" rx="5" fill="FILL"/>')}${z('hamstrings','<rect x="135" y="94" width="10" height="32" rx="5" fill="FILL"/>')}${z('calves','<rect x="123" y="127" width="9" height="20" rx="4" fill="FILL"/>')}${z('calves','<rect x="136" y="127" width="9" height="20" rx="4" fill="FILL"/>')}</g><text x="48" y="153" text-anchor="middle" fill="#7894a2" font-size="7">FRONTAL</text><text x="132" y="153" text-anchor="middle" fill="#7894a2" font-size="7">POSTERIOR</text></svg>`;
  }
  function machineSvg(id){
    const t=metaFor(id).machineType||'body'; const c='#5eead4',s='#7894a2';
    const drawings={
      legpress:`<path d="M25 84h70M34 78l24-42h36M58 36v42M93 30v48M40 68l18-20M63 51l22 13"/>`,
      legext:`<path d="M30 35h48v34H30zM78 56h24M102 56v28M81 84h29M44 69v19"/>`,
      legcurl:`<path d="M26 48h62v20H26zM80 68v19M89 54h18v8H89M40 68v20"/>`,
      press:`<path d="M30 82V34h18M48 40h38v34M50 55h28M78 55l20-11M78 55l20 11"/>`,
      row:`<path d="M24 80h82M38 80V49h28M66 55h24M90 55l14-12M90 55l14 12"/>`,
      pulldown:`<path d="M30 86V26h70v60M46 38h38M65 38v22M48 66h34M54 66v16M76 66v16"/>`,
      cable:`<path d="M32 86V27h18v59M39 34h5M44 34l34 28M78 62h20M98 58v8"/>`,
      rack:`<path d="M28 88V24M90 88V24M28 34h62M20 55h78M32 81h54"/>`,
      hip:`<path d="M22 79h84M40 79V58h45M48 58l18-18M66 40h30M88 40v39"/>`,
      body:`<path d="M24 84h82M42 72l16-25 22 16 16-18M58 47l-8-16"/>`,
      cardio:`<path d="M24 82h84M38 73h52l-7-26H47zM88 47l9-14M94 33h10"/>`,
      lateral:`<path d="M32 85V35h46v50M55 45v30M55 55L28 47M55 55l27-8"/>`,
      curl:`<path d="M28 84h72M42 84V54h35M57 54v-18M57 36h24M81 36v48"/>`,
      pecdeck:`<path d="M32 86V34h46v52M55 50v24M55 54L30 40M55 54l25-14"/>`,
      adductor:`<path d="M30 82h70M45 82V48h38M52 52l10 18M76 52L66 70"/>`,
      abductor:`<path d="M30 82h70M45 82V48h38M52 58l-12 13M76 58l12 13"/>`,
      backext:`<path d="M24 82h80M40 72l18-22 34 18M58 50l12-18M70 32h24"/>`,
      crunch:`<path d="M30 84h72M45 84V50h42M55 52l12 22M67 74h22"/>`,
      lunge:`<path d="M24 84h82M46 36v30M46 48l-16 14M46 48l17 11M46 66l-18 17M46 66l26 17"/>`,
      calf:`<path d="M25 84h78M44 84V55h42M54 55v20M75 55v20M48 75h34"/>`
    };
    return `<svg class="machine-map" viewBox="0 0 120 105" role="img" aria-label="Referencia de equipamiento"><g fill="none" stroke="${s}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round">${drawings[t]||drawings.body}</g><circle cx="60" cy="18" r="8" fill="${c}" opacity=".9"/><path d="M60 27v25" stroke="${c}" stroke-width="5" stroke-linecap="round"/></svg>`;
  }

  function bindNav(){
    $$('.nav-item').forEach(b=>b.addEventListener('click',()=>{
      state.tab=b.dataset.tab; render(); syncNav();
    }));
  }
  function syncNav(){ $$('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.tab===state.tab)); }

  function render(){
    if(state.tab==='kegel' && (!KEGEL_ENABLED || state.profile?.includeKegel===false)) state.tab='home';
    const names={home:[KEGEL_ENABLED?'NEXOFIT PLUS':'NEXOFIT','Inicio'],routine:['PLAN VISUAL','Mi plan'],progress:['TU EVOLUCIÓN','Progreso'],kegel:['SUELO PÉLVICO','Kegel'],profile:['CONFIGURACIÓN','Más']};
    $('#pageEyebrow').textContent=names[state.tab][0]; $('#pageTitle').textContent=names[state.tab][1];
    if(state.tab==='home') renderHome();
    if(state.tab==='routine') renderRoutine();
    if(state.tab==='progress') renderProgress();
    if(state.tab==='kegel' && KEGEL_ENABLED && state.profile?.includeKegel!==false) renderKegel();
    if(state.tab==='profile') renderProfile();
  }
  function generatePlan(profile){
    const n=Math.max(2,Math.min(6,Number(profile.days)||4));
    const gym=[]; const outdoor=[];
    const gymOrder=n<=2?[2,3]:n===3?[2,0,1]:n===4?[0,1,4,5]:[0,1,4,5,2,3];
    const outOrder=[0,1,2,3,0,2];
    for(let i=0;i<n;i++){
      const g=gymTemplates[gymOrder[i%gymOrder.length]], o=outdoorTemplates[outOrder[i%outOrder.length]];
      gym.push(makeDay(g,i,'gym',profile)); outdoor.push(makeDay(o,i,'outdoor',profile));
    }
    const schedule=[];
    if(profile.environment==='mixed'){
      const gymDays=Math.max(1,Math.min(n-1,Number(profile.mixedGymDays)||Math.ceil(n/2))); let gi=0,oi=0;
      for(let i=0;i<n;i++){
        const gymSlots=Math.round(((i+1)*gymDays)/n)-Math.round((i*gymDays)/n); const env=gymSlots>0?'gym':'outdoor';
        schedule.push({environment:env,index:env==='gym'?gi++:oi++,number:i+1});
      }
    } else {
      const env=profile.environment==='outdoor'?'outdoor':'gym'; for(let i=0;i<n;i++) schedule.push({environment:env,index:i,number:i+1});
    }
    return {created:Date.now(),version:3,customized:false,gym,outdoor,schedule};
  }
  function makeDay(t,i,env,profile){
    const minutes=Math.max(25,Math.min(120,Number(profile.sessionMinutes)||55));
    const perExercise=env==='gym'?7.5:5.5;
    const maxExercises=Math.max(3,Math.min(t.ids.length,Math.round(minutes/perExercise)));
    let ids=t.ids.map(id=>resolveAvailableExercise(id,profile,env)).filter(Boolean);
    ids=[...new Set(ids)];
    if(profile.priority && profile.priority!=='balanced') ids=prioritizeIds(ids,profile.priority);
    ids=ids.filter(id=>!(profile.avoid||[]).includes(id)).slice(0,maxExercises);
    if(ids.length<3){ const pool=env==='gym'?Object.keys(ex).filter(id=>isExerciseAvailable(id,profile,'gym')):['airSquat','pushup','lunge','plank','walk']; for(const id of pool){if(ids.length>=3)break;if(!ids.includes(id))ids.push(id);} }
    const arr=ids.map(id=>{
      const base=ex[id]; let sets=base.sets, rest=base.rest, reps=base.reps;
      if(profile.goal==='fat'){ rest=Math.max(35,Math.round(rest*.70)); if(!/min|s$/.test(reps)) reps='12–18'; }
      if(profile.goal==='strength' && ['squat','bench','rdl','row','pulldown','hip','hack','chestpress','machinerow'].includes(id)){ sets=Math.max(4,sets); rest=Math.max(120,rest); reps='4–7'; }
      if(profile.goal==='recomposition'){ rest=Math.max(50,Math.round(rest*.9)); if(!/min|s$/.test(reps)) reps='8–12'; }
      if(profile.goal==='fitness' && env==='outdoor'){ rest=Math.max(25,Math.round(rest*.65)); sets=Math.max(3,sets); }
      if(profile.goal==='muscle' && !/min|s$/.test(reps)){ reps=['calves','lateral','rearDelt','abductor'].includes(id)?'12–20':'8–12'; }
      if(profile.level==='Principiante') sets=Math.max(2,sets-1);
      if(profile.level==='Avanzado' && profile.goal==='muscle' && sets<4) sets++;
      return {id,name:base.name,muscles:base.muscles,sets,reps,rest,done:false};
    });
    const estimated=Math.min(minutes,Math.max(20,Math.round(arr.length*perExercise)));
    return {name:t.name,subtitle:t.subtitle,day:i+1,environment:env,minutes:estimated,exercises:arr};
  }
  function isExerciseAvailable(id,profile,env){
    if(env==='outdoor') return (ex[id]?.equipment||[]).some(x=>['bodyweight','bands'].includes(x)) || ['walk','stepup'].includes(id);
    if(profile.equipmentPreset==='full' || !profile.equipment?.length) return true;
    const available=new Set([...(profile.equipment||[]),'bodyweight']); return (ex[id]?.equipment||[]).some(x=>available.has(x));
  }
  function resolveAvailableExercise(id,profile,env){
    if(isExerciseAvailable(id,profile,env)) return id;
    for(const alt of ex[id]?.alts||[]) if(isExerciseAvailable(alt,profile,env)) return alt;
    return env==='gym'?'goblet':'airSquat';
  }
  function prioritizeIds(ids,priority){
    const map={chest:['Pectoral'],back:['Espalda','Dorsal'],arms:['Bíceps','Tríceps'],legs:['Cuádriceps','Isquiotibiales'],glutes:['Glúteos'],core:['Core']}; const targets=map[priority]||[];
    return [...ids].sort((a,b)=>musclePriorityScore(b,targets)-musclePriorityScore(a,targets));
  }
  function musclePriorityScore(id,targets){ const e=ex[id]||{}; return [...(e.primary||[]),...(e.secondary||[])].reduce((s,m)=>s+(targets.some(t=>normalizeMuscle(m)===normalizeMuscle(t))?1:0),0); }
  function regeneratePlan(show=true){state.plan=generatePlan(state.profile);save(KEYS.plan,state.plan);state.day=0;state.environment=state.profile.environment==='outdoor'?'outdoor':'gym';if(show)toast('Plan actualizado');}
  function markPlanCustomized(){if(state.plan){state.plan.customized=true;save(KEYS.plan,state.plan);}}

  function streak(){
    if(!state.logs.length) return 0;
    const unique=[...new Set(state.logs.filter(l=>l.type==='workout').map(l=>l.date))].sort().reverse();
    let s=0,d=new Date();
    for(let i=0;i<15;i++){ const k=dateKey(d); if(unique.includes(k)) s++; else if(i>0) break; d.setDate(d.getDate()-1); }
    return s;
  }
  function currentDay(){ const arr=state.plan?.[state.environment]||[]; return arr[Math.min(state.day,Math.max(0,arr.length-1))]; }
  function scheduledWorkoutAt(scheduleIndex){ const s=state.plan?.schedule?.[scheduleIndex]; if(!s)return null; const day=state.plan?.[s.environment]?.[s.index]; return day?{day,environment:s.environment,dayIndex:s.index,scheduleIndex}:null; }
  function nextWorkoutInfo(){
    const schedule=state.plan?.schedule||[]; if(!schedule.length){const env=state.profile.environment==='outdoor'?'outdoor':'gym';const arr=state.plan?.[env]||[];return arr[0]?{day:arr[0],environment:env,dayIndex:0,scheduleIndex:0}:null;}
    const logs=workoutLogs(); const last=logs.find(l=>Number.isInteger(l.scheduleIndex)); const idx=last?((last.scheduleIndex+1)%schedule.length):(logs.length%schedule.length); return scheduledWorkoutAt(idx);
  }
  function workoutLogs(){ return state.logs.filter(l=>l.type==='workout'); }
  function nextWorkoutIndex(env=state.profile.environment){ const info=nextWorkoutInfo(); return info?.dayIndex||0; }
  function nextWorkout(env=state.profile.environment){ return nextWorkoutInfo()?.day||null; }
  function lastExerciseSets(id){
    for(const l of workoutLogs()){ const sets=(l.sets||[]).filter(x=>x.exerciseId===id); if(sets.length) return sets; }
    return [];
  }
  function repBounds(text){ const nums=String(text||'').match(/\d+/g)?.map(Number)||[]; return {low:nums[0]||8,high:nums[1]||nums[0]||12}; }
  function suggestedLoad(e){
    const prev=lastExerciseSets(e.id); if(!prev.length) return '';
    const weighted=prev.filter(x=>Number(x.weight)>0); if(!weighted.length) return '';
    const w=Number(weighted[0].weight); const b=repBounds(e.reps);
    const lastSession=workoutLogs().find(l=>(l.sets||[]).some(x=>x.exerciseId===e.id));
    const allTop=weighted.length>=Math.min(e.sets,2) && weighted.every(x=>Number(x.reps)>=b.high && Number(x.rir)<=2);
    let delta=0;
    if(lastSession?.effort==='easy') delta=2.5;
    else if(lastSession?.effort==='hard') delta=0;
    else if(allTop) delta=2.5;
    return Math.max(0,Math.round((w+delta)*2)/2);
  }

  function normalizeMuscle(m){
    const s=String(m||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
    if(/pectoral|pecho/.test(s))return'chest'; if(/dorsal|espalda|romboid|erector/.test(s))return'back'; if(/hombro|deltoid/.test(s))return'shoulders'; if(/bicep/.test(s))return'biceps'; if(/tricep/.test(s))return'triceps'; if(/cuadriceps/.test(s))return'quads'; if(/glute/.test(s))return'glutes'; if(/isquio|femoral/.test(s))return'hamstrings'; if(/gemelo|soleo/.test(s))return'calves'; if(/core|abdom/.test(s))return'core'; if(/aductor/.test(s))return'adductors'; if(/cardio/.test(s))return'cardio'; return s;
  }
  function muscleScoresForExercises(exercises){ const s={}; (exercises||[]).forEach(item=>{const e=ex[item.id]||{};(e.primary||[]).forEach(m=>{const k=normalizeMuscle(m);s[k]=(s[k]||0)+3;});(e.secondary||[]).forEach(m=>{const k=normalizeMuscle(m);s[k]=(s[k]||0)+1;});});return s; }
  function muscleLabel(k){return {chest:'Pecho',back:'Espalda',shoulders:'Hombros',biceps:'Bíceps',triceps:'Tríceps',quads:'Cuádriceps',glutes:'Glúteos',hamstrings:'Isquiotibiales',calves:'Gemelos',core:'Core',adductors:'Aductores',cardio:'Cardio'}[k]||k;}
  function muscleColor(score,max){ if(!score)return'#17303d'; const r=score/Math.max(1,max); return r>.65?'#a3e635':r>.32?'#5eead4':'#22d3ee'; }
  function bodyMapSvg(exercises,compact=false){
    const s=muscleScoresForExercises(exercises),max=Math.max(1,...Object.values(s)); const c=k=>muscleColor(s[k]||0,max); const h=compact?170:205;
    return `<div class="body-map ${compact?'compact':''}"><svg viewBox="0 0 260 210" role="img" aria-label="Mapa de músculos trabajados"><text x="58" y="16">Frente</text><text x="178" y="16">Espalda</text>
      <g class="sil"><circle cx="70" cy="36" r="15"/><path d="M54 56 Q70 47 86 56 L91 112 Q80 125 70 126 Q60 125 49 112Z"/><path d="M55 121 L67 121 L63 185 L48 185Z"/><path d="M73 121 L85 121 L92 185 L77 185Z"/><path d="M50 61 L37 72 L30 116 L42 119 L55 81Z"/><path d="M90 61 L103 72 L110 116 L98 119 L85 81Z"/></g>
      <ellipse cx="62" cy="68" rx="9" ry="11" fill="${c('chest')}"/><ellipse cx="78" cy="68" rx="9" ry="11" fill="${c('chest')}"/><ellipse cx="48" cy="65" rx="7" ry="8" fill="${c('shoulders')}"/><ellipse cx="92" cy="65" rx="7" ry="8" fill="${c('shoulders')}"/><ellipse cx="41" cy="88" rx="6" ry="13" fill="${c('biceps')}"/><ellipse cx="99" cy="88" rx="6" ry="13" fill="${c('biceps')}"/><rect x="62" y="82" width="16" height="27" rx="7" fill="${c('core')}"/><ellipse cx="57" cy="141" rx="9" ry="21" fill="${c('quads')}"/><ellipse cx="83" cy="141" rx="9" ry="21" fill="${c('quads')}"/><ellipse cx="55" cy="174" rx="6" ry="12" fill="${c('calves')}"/><ellipse cx="85" cy="174" rx="6" ry="12" fill="${c('calves')}"/>
      <g class="sil"><circle cx="190" cy="36" r="15"/><path d="M174 56 Q190 47 206 56 L211 112 Q200 125 190 126 Q180 125 169 112Z"/><path d="M175 121 L187 121 L183 185 L168 185Z"/><path d="M193 121 L205 121 L212 185 L197 185Z"/><path d="M170 61 L157 72 L150 116 L162 119 L175 81Z"/><path d="M210 61 L223 72 L230 116 L218 119 L205 81Z"/></g>
      <path d="M177 61 Q190 54 203 61 L202 92 Q190 101 178 92Z" fill="${c('back')}"/><ellipse cx="168" cy="66" rx="7" ry="8" fill="${c('shoulders')}"/><ellipse cx="212" cy="66" rx="7" ry="8" fill="${c('shoulders')}"/><ellipse cx="160" cy="90" rx="6" ry="13" fill="${c('triceps')}"/><ellipse cx="220" cy="90" rx="6" ry="13" fill="${c('triceps')}"/><ellipse cx="181" cy="117" rx="10" ry="10" fill="${c('glutes')}"/><ellipse cx="199" cy="117" rx="10" ry="10" fill="${c('glutes')}"/><ellipse cx="177" cy="143" rx="9" ry="21" fill="${c('hamstrings')}"/><ellipse cx="203" cy="143" rx="9" ry="21" fill="${c('hamstrings')}"/><ellipse cx="175" cy="174" rx="6" ry="12" fill="${c('calves')}"/><ellipse cx="205" cy="174" rx="6" ry="12" fill="${c('calves')}"/>
    </svg><div class="muscle-legend">${Object.entries(s).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([k,v])=>`<span><i style="background:${muscleColor(v,max)}"></i>${muscleLabel(k)}</span>`).join('')}</div></div>`;
  }
  function movementThumb(id){ const e=ex[id]||{}; return `<div class="movement-thumb">${demoSvg(e.anim||'squat').replace('demo-stage playing','demo-stage playing mini')}</div>`; }
  function dayTopMuscles(day){ const s=muscleScoresForExercises(day?.exercises||[]);return Object.entries(s).sort((a,b)=>b[1]-a[1]).slice(0,4).map(([k])=>muscleLabel(k)); }
  function envLabel(env){return env==='gym'?'🏋 Gimnasio':env==='outdoor'?'🌳 Aire libre':'🔄 Mixto';}
  function priorityLabel(p){return {balanced:'Equilibrado',chest:'Pecho',back:'Espalda',arms:'Brazos',legs:'Piernas',glutes:'Glúteos',core:'Core'}[p]||'Equilibrado';}
  function renderHome(){
    const p=state.profile, info=nextWorkoutInfo(), day=info?.day, sessions=workoutLogs().length, kg=latestWeight(), last=workoutLogs()[0];
    const kegelBlock=KEGEL_ENABLED && p.includeKegel!==false?`<div class="section-title"><h3>Suelo pélvico</h3><span>${escapeHtml(state.kegel.mode==='relax'?'Relajación':state.kegel.mode==='endurance'?'Resistencia':'Control')}</span></div>
      <div class="card kegel-mini"><div class="row between center"><div><span class="badge violet">SESIÓN GUIADA</span><h3 style="margin:8px 0 4px">Suelo pélvico</h3><p class="muted" style="margin:0">${state.kegel.sets} series · ${state.kegel.reps} repeticiones · ${state.kegel.contract}s de contracción</p></div><div style="font-size:34px">◉</div></div><div class="space12"></div><button class="btn full" id="homeKegel">Comenzar sesión</button></div>`:'';
    screen.innerHTML=`
      <section class="hero"><span class="pill good">${goals[p.goal].icon} ${goals[p.goal].label}</span><h2>Tu próxima sesión está lista.</h2><p>${p.days} días/semana · ${p.level} · ${envLabel(p.environment)} · ${p.sessionMinutes} min · Prioridad ${priorityLabel(p.priority)}</p></section>
      <div class="space12"></div><div class="grid3"><div class="stat"><b>${kg.toFixed(1)} kg</b><small>Peso</small></div><div class="stat"><b>${streak()} días</b><small>Racha</small></div><div class="stat"><b>${sessions}</b><small>Sesiones</small></div></div>
      <div class="section-title"><h3>Tu próxima sesión</h3><span>${last?`Última: ${fmtDate(last.date)}`:'Comienza hoy'}</span></div>
      ${day?workoutHero(day,info.scheduleIndex):'<div class="card">Crea tu plan desde Más.</div>'}
      ${day?`<div class="section-title"><h3>Qué trabajarás</h3><span>${dayTopMuscles(day).join(' · ')}</span></div><div class="card visual-overview">${bodyMapSvg(day.exercises,true)}</div>`:''}
      ${kegelBlock}
      <div class="section-title"><h3>NexoFit Coach</h3></div><div class="card coach-card"><span class="badge lime">0.3 · ADAPTATIVO</span><p style="margin:9px 0 0;color:#c8d6dc;line-height:1.5;font-size:13px">Antes de entrenar puedes indicar cuánto tiempo tienes y cómo te sientes. NexoFit conserva lo prioritario y ajusta accesorios sin romper tu progresión.</p></div>`;
    const start=$('#startToday'); if(start) start.onclick=()=>prepareWorkout(day,info);
    const change=$('#changeToday'); if(change) change.onclick=()=>{state.environment=info.environment;state.day=(info.dayIndex+1)%Math.max(1,(state.plan?.[info.environment]||[]).length);state.tab='routine';render();syncNav();};
    if(KEGEL_ENABLED && p.includeKegel!==false && $('#homeKegel')) $('#homeKegel').onclick=()=>{state.tab='kegel';render();syncNav();setTimeout(startKegel,80)};
  }
  function workoutHero(day,scheduleIndex){
    const previous=lastExerciseSets(day.exercises[0]?.id); const prevTxt=previous.length?`Anterior: ${previous[0].weight?previous[0].weight+' kg · ':''}${previous[0].reps} reps`:'Primera vez con esta sesión';
    return `<div class="card workout-card"><div class="workout-cover"><span class="badge">DÍA ${Number.isInteger(scheduleIndex)?scheduleIndex+1:day.day}</span><h3>${escapeHtml(day.name)}</h3><p>${escapeHtml(day.subtitle)}</p></div><div class="workout-body"><div class="row between center"><span class="muted">${day.exercises.length} ejercicios · ${day.minutes} min</span><span class="pill">${envLabel(day.environment)}</span></div><div class="space8"></div><div class="muted">${prevTxt}</div><div class="space12"></div><button class="btn full" id="startToday">Comenzar entrenamiento →</button><div class="space8"></div><button class="btn ghost full" id="changeToday">Ver / cambiar sesión</button></div></div>`;
  }
  function renderRoutine(){
    const arr=state.plan?.[state.environment]||[]; if(state.day>=arr.length) state.day=0; const day=arr[state.day],p=state.profile;
    const schedule=state.plan?.schedule||[];
    const mixed=`${p.environment==='mixed'?`<div class="section-title"><h3>Tu semana mixta</h3><span>${schedule.length} sesiones</span></div><div class="week-strip">${schedule.map((s,i)=>{const d=state.plan?.[s.environment]?.[s.index];return `<button class="week-day" data-senv="${s.environment}" data-si="${s.index}"><b>D${i+1}</b><span>${s.environment==='gym'?'🏋':'🌳'}</span><small>${escapeHtml(d?.name||'Sesión')}</small></button>`}).join('')}</div>`:''}`;
    screen.innerHTML=`${mixed}<div class="segment"><button id="gymSeg" class="${state.environment==='gym'?'active':''}">🏋 Gimnasio</button><button id="outSeg" class="${state.environment==='outdoor'?'active':''}">🌳 Aire libre</button></div><div class="space12"></div>
      <div class="daychips">${arr.map((d,i)=>`<button class="daychip ${i===state.day?'active':''}" data-day="${i}">Día ${i+1}<br><span style="font-weight:500">${escapeHtml(d.name)}</span></button>`).join('')}</div>
      ${day?`<div class="card accent"><div class="row between center"><div><span class="badge">DÍA ${day.day}</span><h2 style="margin:7px 0 4px;font-size:23px">${escapeHtml(day.name)}</h2><p class="muted" style="margin:0">${escapeHtml(day.subtitle)} · ${day.minutes} min</p></div><button class="icon-btn" id="editDay">✎</button></div></div>
      <div class="section-title"><h3>Radiografía de la sesión</h3><span>${dayTopMuscles(day).join(' · ')}</span></div><div class="card visual-overview">${bodyMapSvg(day.exercises)}<div class="how-grid">${day.exercises.slice(0,3).map(e=>{const d=ex[e.id];return `<button class="how-card" data-ex="${e.id}">${movementThumb(e.id)}<b>${escapeHtml(e.name)}</b><small>${escapeHtml((d?.machines||[]).slice(0,2).join(' · '))}</small></button>`}).join('')}</div></div>
      <div class="section-title"><h3>Ejercicios</h3><span>Toca para técnica</span></div><div class="exercise-list">${day.exercises.map((e,i)=>exerciseRow(e,i)).join('')}</div><div class="space12"></div><div class="grid2"><button class="btn secondary" id="exploreExercises">Explorar biblioteca</button><button class="btn secondary" id="addExercise">＋ Añadir</button></div><div class="space8"></div><button class="btn full" id="startRoutine">▶ Comenzar esta rutina</button>`:''}`;
    $('#gymSeg').onclick=()=>switchEnv('gym'); $('#outSeg').onclick=()=>switchEnv('outdoor');
    $$('.daychip').forEach(b=>b.onclick=()=>{state.day=Number(b.dataset.day);renderRoutine();});
    $$('.week-day').forEach(b=>b.onclick=()=>{state.environment=b.dataset.senv;state.day=Number(b.dataset.si);renderRoutine();});
    $$('.exercise-row').forEach(r=>r.onclick=e=>{ if(e.target.closest('.more')) return; showExercise(r.dataset.id); });
    $$('.how-card').forEach(b=>b.onclick=()=>showExercise(b.dataset.ex));
    $$('.more').forEach(b=>b.onclick=e=>{e.stopPropagation();editExercise(Number(b.dataset.i))});
    if($('#editDay')) $('#editDay').onclick=()=>editDay(day);
    if($('#addExercise')) $('#addExercise').onclick=()=>chooseExercise(id=>{day.exercises.push(cloneExercise(id));markPlanCustomized();renderRoutine();toast('Ejercicio añadido');});
    if($('#exploreExercises')) $('#exploreExercises').onclick=()=>chooseExercise(id=>showExercise(id),'Explorar ejercicios',false);
    if($('#startRoutine')) $('#startRoutine').onclick=()=>prepareWorkout(day,{day,environment:day.environment,dayIndex:state.day,scheduleIndex:null});
  }
  function switchEnv(env){state.environment=env;state.day=0;renderRoutine();}
  function exerciseRow(e,i){ const sug=suggestedLoad(e), d=ex[e.id]||{}; const mus=(d.primary||[]).slice(0,2).join(' + '); return `<div class="exercise-row" data-id="${e.id}"><div class="exercise-index">${i+1}</div><div><h4>${escapeHtml(e.name)}</h4><p>${escapeHtml(mus||e.muscles)} · ${e.sets} × ${escapeHtml(e.reps)}${sug!==''?` · Próx. ${sug} kg`:''}</p><div class="machine-line">${escapeHtml((d.machines||[]).slice(0,2).join(' · '))}</div></div><button class="more" data-i="${i}">⋮</button></div>`; }
  function cloneExercise(id){const b=ex[id];return{id,name:b.name,muscles:b.muscles,sets:b.sets,reps:b.reps,rest:b.rest,done:false};}
  function chooseExercise(onChoose,title='Biblioteca de ejercicios',chooseMode=true){
    const renderRows=(filter='all',q='')=>Object.entries(ex).filter(([id,e])=>{const okEnv=filter==='all'||(e.primary||[]).some(m=>normalizeMuscle(m)===filter)||(e.secondary||[]).some(m=>normalizeMuscle(m)===filter);const okQ=!q||(`${e.name} ${e.muscles} ${(e.machines||[]).join(' ')}`).toLowerCase().includes(q);return okEnv&&okQ;}).map(([id,e])=>`<button class="library-row visual" data-id="${id}">${movementThumb(id)}<span class="library-copy"><b>${escapeHtml(e.name)}</b><span>${escapeHtml((e.primary||[]).join(' + '))}</span><small>${escapeHtml((e.machines||[]).slice(0,2).join(' · '))}</small></span></button>`).join('');
    modal(`<div class="modal tall"><div class="handle"></div><div class="modal-head"><div><span class="badge">BIBLIOTECA · ${Object.keys(ex).length} EJERCICIOS</span><h2>${title}</h2></div><button class="close">×</button></div><div class="field"><label>Buscar ejercicio, músculo o máquina</label><input id="exerciseSearch" placeholder="Ej. pecho, prensa, polea"></div><div class="filter-scroll" id="muscleFilters">${[['all','Todos'],['chest','Pecho'],['back','Espalda'],['shoulders','Hombros'],['arms','Brazos'],['quads','Piernas'],['glutes','Glúteos'],['core','Core']].map(([k,l])=>`<button class="filter-chip ${k==='all'?'active':''}" data-filter="${k}">${l}</button>`).join('')}</div><div id="exerciseLibrary" class="library-list">${renderRows()}</div></div>`);
    let filter='all'; const actualFilter=k=>k==='arms'?'arms':k;
    const redraw=()=>{let f=filter,q=$('#exerciseSearch').value.toLowerCase().trim();let html;if(f==='arms') html=Object.entries(ex).filter(([id,e])=>[...(e.primary||[]),...(e.secondary||[])].some(m=>['biceps','triceps'].includes(normalizeMuscle(m)))&&(!q||(`${e.name} ${e.muscles} ${(e.machines||[]).join(' ')}`).toLowerCase().includes(q))).map(([id,e])=>`<button class="library-row visual" data-id="${id}">${movementThumb(id)}<span class="library-copy"><b>${escapeHtml(e.name)}</b><span>${escapeHtml((e.primary||[]).join(' + '))}</span><small>${escapeHtml((e.machines||[]).slice(0,2).join(' · '))}</small></span></button>`).join('');else html=renderRows(f,q);$('#exerciseLibrary').innerHTML=html;$$('.library-row').forEach(b=>b.onclick=()=>{const id=b.dataset.id;if(chooseMode){closeModal();onChoose(id);}else onChoose(id);});};
    redraw(); $('#exerciseSearch').oninput=redraw; $$('.filter-chip').forEach(b=>b.onclick=()=>{$$('.filter-chip').forEach(x=>x.classList.remove('active'));b.classList.add('active');filter=actualFilter(b.dataset.filter);redraw();});
  }
  function showExercise(id,onClose=null){
    const e=ex[id]||ex.squat, faux={exercises:[{id}]};
    modal(`<div class="modal tall"><div class="handle"></div><div class="modal-head"><div><span class="badge">TÉCNICA · ${escapeHtml((e.primary||[]).join(' + '))}</span><h2>${escapeHtml(e.name)}</h2><p class="muted" style="margin:0">${escapeHtml(e.muscles)}</p></div><button class="close" id="closeTechnique">×</button></div>
      <div class="exercise-visual-grid"><div>${demoSvg(e.anim)}</div><div>${bodyMapSvg(faux.exercises,true)}</div></div><div class="space12"></div><div class="grid2"><button class="btn secondary" id="playAnim">❚❚ Pausar animación</button><button class="btn ghost" id="videoBtn">▶ Video externo</button></div>
      <div class="section-title"><h3>Cómo trabajarlo en el gym</h3><span>Opciones</span></div><div class="machine-grid">${(e.machines||[]).map((m,i)=>`<div class="machine-card"><span>${i===0?'🏋':'▦'}</span><b>${escapeHtml(m)}</b><small>${i===0?'Opción principal':'Alternativa válida'}</small></div>`).join('')}</div>
      ${(e.alts||[]).length?`<div class="section-title"><h3>Alternativas equivalentes</h3><span>Mismo foco</span></div><div class="alt-scroll">${e.alts.slice(0,4).map(a=>`<button class="alt-card" data-alt="${a}"><b>${escapeHtml(ex[a]?.name||a)}</b><small>${escapeHtml((ex[a]?.primary||[]).join(' + '))}</small></button>`).join('')}</div>`:''}
      <div class="section-title"><h3>Puntos clave</h3></div><div class="card soft">${e.cues.map(c=>`<div class="cue"><i>✓</i><div>${escapeHtml(c)}</div></div>`).join('')}</div>
      <div class="section-title"><h3>Errores comunes</h3></div><div class="card soft">${e.bad.map(c=>`<div class="cue bad"><i>×</i><div>${escapeHtml(c)}</div></div>`).join('')}</div>
      <div class="space16"></div><button class="btn full" id="closeTechniqueBottom">Entendido</button></div>`,false);
    $('#videoBtn').onclick=()=>openExternal(e.video);
    $('#playAnim').onclick=()=>{const d=$('.demo-stage');d.classList.toggle('playing');$('#playAnim').textContent=d.classList.contains('playing')?'❚❚ Pausar animación':'▶ Reproducir animación';};
    $$('.alt-card').forEach(b=>b.onclick=()=>showExercise(b.dataset.alt,onClose));
    const close=()=>{if(onClose)onClose();else closeModal();}; $('#closeTechnique').onclick=close;$('#closeTechniqueBottom').onclick=close;
  }
  function demoSvg(kind){
    const floor='<line x1="16" y1="176" x2="154" y2="176" stroke="#244858" stroke-width="3" stroke-linecap="round"/>';
    const parts={
      squat:`<g class="demo-squat"><circle cx="85" cy="32" r="13" fill="#d7e8ee"/><line class="body" x1="85" y1="48" x2="85" y2="98"/><line class="limb" x1="85" y1="63" x2="54" y2="78"/><line class="limb" x1="85" y1="63" x2="116" y2="78"/><line class="limb" x1="85" y1="98" x2="58" y2="134"/><line class="limb" x1="58" y1="134" x2="50" y2="170"/><line class="limb" x1="85" y1="98" x2="112" y2="134"/><line class="limb" x1="112" y1="134" x2="121" y2="170"/></g>`,
      hinge:`<g class="demo-hinge"><circle cx="76" cy="34" r="13" fill="#d7e8ee"/><line class="body hinge-torso" x1="76" y1="50" x2="87" y2="98"/><line class="limb" x1="87" y1="98" x2="67" y2="138"/><line class="limb" x1="67" y1="138" x2="64" y2="171"/><line class="limb" x1="87" y1="98" x2="108" y2="138"/><line class="limb" x1="108" y1="138" x2="112" y2="171"/><line class="limb hinge-arm" x1="78" y1="65" x2="62" y2="105"/><line class="limb hinge-arm" x1="81" y1="65" x2="97" y2="105"/><line x1="53" y1="109" x2="105" y2="109" stroke="#5eead4" stroke-width="5" stroke-linecap="round"/></g>`,
      lunge:`<g class="demo-lunge"><circle cx="82" cy="31" r="13" fill="#d7e8ee"/><line class="body" x1="82" y1="47" x2="82" y2="98"/><line class="limb" x1="82" y1="62" x2="54" y2="82"/><line class="limb" x1="82" y1="62" x2="111" y2="80"/><line class="limb lunge-front" x1="82" y1="98" x2="52" y2="133"/><line class="limb lunge-front" x1="52" y1="133" x2="42" y2="170"/><line class="limb lunge-back" x1="82" y1="98" x2="119" y2="121"/><line class="limb lunge-back" x1="119" y1="121" x2="136" y2="165"/></g>`,
      push:`<g class="demo-push"><rect x="29" y="108" width="112" height="12" rx="6" fill="#244858"/><circle cx="85" cy="52" r="13" fill="#d7e8ee"/><line class="body" x1="85" y1="68" x2="85" y2="105"/><line class="limb push-arm-l" x1="85" y1="77" x2="58" y2="62"/><line class="limb push-arm-r" x1="85" y1="77" x2="112" y2="62"/><line x1="50" y1="56" x2="120" y2="56" stroke="#5eead4" stroke-width="5" stroke-linecap="round"/><line class="limb" x1="85" y1="105" x2="60" y2="145"/><line class="limb" x1="85" y1="105" x2="110" y2="145"/></g>`,
      row:`<g class="demo-row"><rect x="28" y="113" width="95" height="10" rx="5" fill="#244858"/><circle cx="66" cy="46" r="13" fill="#d7e8ee"/><line class="body" x1="66" y1="62" x2="66" y2="107"/><line class="limb" x1="66" y1="107" x2="48" y2="149"/><line class="limb" x1="66" y1="107" x2="86" y2="149"/><g class="row-arms"><line class="limb" x1="66" y1="73" x2="103" y2="82"/><line class="limb" x1="66" y1="76" x2="103" y2="88"/><circle cx="108" cy="85" r="5" fill="#5eead4"/></g><line x1="130" y1="35" x2="130" y2="150" stroke="#416171" stroke-width="4"/><line x1="108" y1="85" x2="130" y2="65" stroke="#5eead4" stroke-width="3"/></g>`,
      raise:`<g class="demo-raise"><circle cx="85" cy="31" r="13" fill="#d7e8ee"/><line class="body" x1="85" y1="47" x2="85" y2="100"/><g class="raise-arms"><line class="limb" x1="85" y1="62" x2="45" y2="88"/><line class="limb" x1="85" y1="62" x2="125" y2="88"/></g><line class="limb" x1="85" y1="100" x2="67" y2="169"/><line class="limb" x1="85" y1="100" x2="103" y2="169"/></g>`,
      curl:`<g class="demo-curl"><circle cx="85" cy="31" r="13" fill="#d7e8ee"/><line class="body" x1="85" y1="47" x2="85" y2="99"/><line class="limb" x1="85" y1="62" x2="62" y2="91"/><line class="limb" x1="85" y1="62" x2="108" y2="91"/><g class="curl-forearms"><line class="limb" x1="62" y1="91" x2="53" y2="129"/><line class="limb" x1="108" y1="91" x2="117" y2="129"/></g><line class="limb" x1="85" y1="99" x2="67" y2="169"/><line class="limb" x1="85" y1="99" x2="103" y2="169"/></g>`,
      calf:`<g class="demo-calf"><circle cx="85" cy="31" r="13" fill="#d7e8ee"/><line class="body" x1="85" y1="47" x2="85" y2="100"/><line class="limb" x1="85" y1="62" x2="62" y2="93"/><line class="limb" x1="85" y1="62" x2="108" y2="93"/><g class="calf-legs"><line class="limb" x1="85" y1="100" x2="70" y2="145"/><line class="limb" x1="70" y1="145" x2="66" y2="170"/><line class="limb" x1="85" y1="100" x2="100" y2="145"/><line class="limb" x1="100" y1="145" x2="104" y2="170"/></g></g>`
    };
    const k=parts[kind]?kind:(kind==='hinge'?'hinge':kind==='row'?'row':kind==='raise'?'raise':kind==='curl'?'curl':kind==='calf'?'calf':'squat');
    return `<div class="demo-stage playing demo-${k}"><svg class="stick" viewBox="0 0 170 190" aria-label="Animación técnica simplificada">${parts[k]}${floor}</svg></div>`;
  }


  function editExercise(i){
    const day=currentDay(), e=day.exercises[i];
    modal(`<div class="modal"><div class="handle"></div><div class="modal-head"><div><span class="badge">EDITAR EJERCICIO</span><h2>${escapeHtml(e.name)}</h2></div><button class="close">×</button></div><div class="grid2"><div class="field"><label>Series</label><input id="edSets" type="number" min="1" max="10" value="${e.sets}"></div><div class="field"><label>Descanso (seg)</label><input id="edRest" type="number" min="0" max="300" value="${e.rest}"></div></div><div class="space12"></div><div class="field"><label>Repeticiones / tiempo</label><input id="edReps" value="${escapeHtml(e.reps)}"></div><div class="space16"></div><button class="btn full" id="saveExercise">Guardar cambios</button><div class="space8"></div><div class="grid2"><button class="btn secondary" id="replaceExercise">Reemplazar</button><button class="btn secondary" id="moveExercise">Mover</button></div><div class="space8"></div><button class="btn danger full" id="removeExercise">Eliminar ejercicio</button></div>`);
    $('#saveExercise').onclick=()=>{e.sets=Math.max(1,Number($('#edSets').value)||e.sets);e.rest=Math.max(0,Number($('#edRest').value)||0);e.reps=$('#edReps').value.trim()||e.reps;markPlanCustomized();closeModal();renderRoutine();toast('Ejercicio actualizado');};
    $('#replaceExercise').onclick=()=>chooseExercise(id=>{day.exercises[i]=cloneExercise(id);markPlanCustomized();renderRoutine();toast('Ejercicio reemplazado');},'Reemplazar ejercicio');
    $('#moveExercise').onclick=()=>{closeModal();moveExercise(i);};
    $('#removeExercise').onclick=()=>{if(day.exercises.length<=2)return toast('Mantén al menos 2 ejercicios'); if(confirm(`¿Eliminar ${e.name}?`)){day.exercises.splice(i,1);markPlanCustomized();closeModal();renderRoutine();}};
  }
  function moveExercise(i){
    const day=currentDay(); modal(`<div class="modal"><div class="handle"></div><div class="modal-head"><div><span class="badge">ORDEN</span><h2>Mover ${escapeHtml(day.exercises[i].name)}</h2></div><button class="close">×</button></div><div class="grid2"><button class="btn secondary" id="moveUp">↑ Subir</button><button class="btn secondary" id="moveDown">↓ Bajar</button></div></div>`);
    $('#moveUp').onclick=()=>{if(i>0){[day.exercises[i-1],day.exercises[i]]=[day.exercises[i],day.exercises[i-1]];markPlanCustomized();closeModal();renderRoutine();}};
    $('#moveDown').onclick=()=>{if(i<day.exercises.length-1){[day.exercises[i+1],day.exercises[i]]=[day.exercises[i],day.exercises[i+1]];markPlanCustomized();closeModal();renderRoutine();}};
  }
  function editDay(day){
    modal(`<div class="modal"><div class="handle"></div><div class="modal-head"><div><span class="badge">EDITAR DÍA</span><h2>${escapeHtml(day.name)}</h2></div><button class="close">×</button></div><div class="field"><label>Nombre</label><input id="dayName" value="${escapeHtml(day.name)}"></div><div class="space12"></div><div class="field"><label>Descripción</label><input id="daySub" value="${escapeHtml(day.subtitle)}"></div><div class="space16"></div><button class="btn full" id="saveDay">Guardar</button></div>`);
    $('#saveDay').onclick=()=>{day.name=$('#dayName').value.trim()||day.name;day.subtitle=$('#daySub').value.trim()||day.subtitle;markPlanCustomized();closeModal();renderRoutine();};
  }

  function prepareWorkout(day,info={}){
    if(!day)return; const p=state.profile; let minutes=p.sessionMinutes||day.minutes,energy='normal';
    modal(`<div class="modal"><div class="handle"></div><div class="modal-head"><div><span class="badge">ANTES DE ENTRENAR</span><h2>¿Cómo estás hoy?</h2><p class="muted" style="margin:0">Ajustaremos accesorios; tus ejercicios prioritarios se mantienen.</p></div><button class="close">×</button></div><div class="choice3"><button class="choice active" data-energy="normal">🙂<b>Bien</b><small>Plan normal</small></button><button class="choice" data-energy="tired">😐<b>Algo cansado</b><small>Menos volumen</small></button><button class="choice" data-energy="low">😴<b>Muy cansado</b><small>Sesión breve</small></button></div><div class="section-title"><h3>Tiempo disponible hoy</h3><span>${day.minutes} min plan</span></div><div class="time-choices">${[30,45,60,75].map(x=>`<button class="time-chip ${Math.abs(x-minutes)<8?'active':''}" data-min="${x}">${x} min</button>`).join('')}<button class="time-chip" data-min="${day.minutes}">Plan ${day.minutes}</button></div><div class="space16"></div><button class="btn full" id="beginPrepared">Comenzar</button></div>`);
    $$('.choice').forEach(b=>b.onclick=()=>{$$('.choice').forEach(x=>x.classList.remove('active'));b.classList.add('active');energy=b.dataset.energy;});
    $$('.time-chip').forEach(b=>b.onclick=()=>{$$('.time-chip').forEach(x=>x.classList.remove('active'));b.classList.add('active');minutes=Number(b.dataset.min);});
    $('#beginPrepared').onclick=()=>{const adapted=adaptDayForToday(day,minutes,energy);closeModal();startWorkout(adapted,info.dayIndex,info.scheduleIndex);};
  }
  function adaptDayForToday(day,minutes,energy){
    const copy=JSON.parse(JSON.stringify(day)); const factor=energy==='low'?.6:energy==='tired'?.8:1; const max=Math.max(3,Math.round((minutes/(day.minutes||minutes))*day.exercises.length*factor)); copy.exercises=copy.exercises.slice(0,Math.min(copy.exercises.length,max)); copy.minutes=Math.min(minutes,Math.round((day.minutes||minutes)*factor)); copy.adapted=copy.exercises.length<day.exercises.length||energy!=='normal'; return copy;
  }
  function startWorkout(day,dayIndex=null,scheduleIndex=null){
    if(!day)return; const arr=state.plan?.[day.environment]||[]; const idx=Number.isInteger(dayIndex)?dayIndex:Math.max(0,arr.indexOf(day));
    state.workout={day,dayIndex:idx,scheduleIndex:Number.isInteger(scheduleIndex)?scheduleIndex:null,exercise:0,set:1,start:Date.now(),completed:0,results:[]}; keepAwake(true); renderWorkoutLive();
  }
  function currentSetDefaults(e){
    const w=state.workout, previous=lastExerciseSets(e.id), already=w.results.filter(x=>x.exerciseId===e.id); const lastThis=already[already.length-1];
    const sug=suggestedLoad(e); const bounds=repBounds(e.reps); const old=previous[Math.min(w.set-1,Math.max(0,previous.length-1))];
    return {weight:lastThis?.weight ?? (sug!==''?sug:(old?.weight||'')), reps:old?.reps||bounds.low, rir:old?.rir??2};
  }
  function renderWorkoutLive(){
    const w=state.workout,d=w.day,e=d.exercises[w.exercise], base=ex[e.id]||{}, def=currentSetDefaults(e), prev=lastExerciseSets(e.id), sug=suggestedLoad(e);
    const prevText=prev.length?`${prev[0].weight?prev[0].weight+' kg × ':''}${prev[0].reps} · RIR ${prev[0].rir??'—'}`:'Sin registro anterior';
    modal(`<div class="modal tall workout-live"><div class="handle"></div><div class="modal-head"><div><span class="badge">ENTRENANDO</span><h2>Día ${d.day} · ${escapeHtml(d.name)}</h2></div><button class="close" id="quitWorkout">×</button></div><div class="progress"><i style="width:${Math.round(((w.exercise+(w.set-1)/Math.max(1,e.sets))/d.exercises.length)*100)}%"></i></div><div class="space16"></div>
      <span class="muted">Ejercicio ${w.exercise+1} de ${d.exercises.length} · Serie ${w.set} de ${e.sets}</span><div class="live-head"><div class="live-thumb">${muscleMapSvg(e.id,true)}</div><div><h2 class="live-exercise">${escapeHtml(e.name)}</h2><p class="muted">${escapeHtml(e.muscles||'')}</p></div></div>
      <div class="previous-set"><span>Última vez</span><b>${prevText}</b>${sug!==''?`<em>Sugerido hoy: ${sug} kg</em>`:''}</div>
      <div class="set-entry"><div class="field"><label>Peso (kg)</label><input id="setWeight" type="number" step="0.5" min="0" placeholder="0 = corporal" value="${def.weight}"></div><div class="field"><label>Reps / seg</label><input id="setReps" type="number" step="1" min="1" value="${def.reps}"></div><div class="field"><label>RIR (reps en reserva)</label><select id="setRir">${[0,1,2,3,4,5].map(x=>`<option value="${x}">${x}</option>`).join('')}</select></div></div>
      <div class="row between center"><span class="pill">Objetivo ${escapeHtml(e.reps)}</span><span class="pill">Descanso ${e.rest}s</span></div>
      <div class="section-title"><h3>Series</h3><span>${w.results.filter(x=>x.exerciseId===e.id).length}/${e.sets} registradas</span></div><div class="set-dots">${Array.from({length:e.sets},(_,i)=>`<div class="set-dot ${i+1<w.set?'done':i+1===w.set?'current':''}">${i+1}</div>`).join('')}</div>
      <button class="btn secondary full" id="techLive">Ver técnica</button><div class="space8"></div><button class="btn full" id="completeSet">✓ Guardar serie ${w.set}</button><div class="space8"></div><button class="btn ghost full" id="skipExercise">Saltar ejercicio</button></div>`,false);
    $('#setRir').value=String(def.rir); $('#techLive').onclick=()=>showExercise(e.id,renderWorkoutLive); $('#completeSet').onclick=completeSet; $('#skipExercise').onclick=nextExercise; $('#quitWorkout').onclick=confirmQuitWorkout;
  }
  function completeSet(){
    const w=state.workout,e=w.day.exercises[w.exercise]; const reps=Number($('#setReps')?.value), weight=Math.max(0,Number($('#setWeight')?.value)||0), rir=Math.max(0,Math.min(5,Number($('#setRir')?.value)||0));
    if(!Number.isFinite(reps)||reps<=0)return toast('Ingresa las repeticiones o segundos');
    w.results.push({exerciseId:e.id,exerciseName:e.name,set:w.set,weight,reps,rir,timestamp:Date.now()}); vibrate(60);
    if(w.set<e.sets){const rest=e.rest;w.set++;if(rest>0)showRest(rest,renderWorkoutLive);else renderWorkoutLive();} else {w.completed++;nextExercise();}
  }
  function nextExercise(){ const w=state.workout;if(w.exercise<w.day.exercises.length-1){w.exercise++;w.set=1;renderWorkoutLive();}else finishWorkout(); }
  function showRest(sec,onDone){
    let end=Date.now()+sec*1000,total=sec; modal(`<div class="modal"><div class="handle"></div><div style="text-align:center;padding:12px 0 10px"><span class="badge">DESCANSO</span><h2 style="margin:10px 0 0">Recupera y respira</h2><div class="timer-ring" id="restRing" style="--p:100"><div class="timer-content"><small>SIGUIENTE SERIE</small><b id="restNum">${sec}</b><span>segundos</span></div></div><div class="grid2"><button class="btn secondary" id="addRest">＋30 s</button><button class="btn full" id="skipRest">Saltar</button></div></div></div>`,false);
    const tick=setInterval(()=>{const left=Math.max(0,Math.ceil((end-Date.now())/1000));if($('#restNum'))$('#restNum').textContent=left;if($('#restRing'))$('#restRing').style.setProperty('--p',(left/total)*100);if(left<=0){clearInterval(tick);vibrate(100);onDone();}},250);
    $('#addRest').onclick=()=>{end+=30000;total+=30;}; $('#skipRest').onclick=()=>{clearInterval(tick);onDone();};
  }
  function finishWorkout(){
    const w=state.workout,mins=Math.max(1,Math.round((Date.now()-w.start)/60000)),volume=Math.round(w.results.reduce((a,x)=>a+(Number(x.weight)||0)*(Number(x.reps)||0),0));
    const log={type:'workout',date:today(),timestamp:Date.now(),name:w.day.name,minutes:mins,environment:w.day.environment,dayIndex:w.dayIndex,scheduleIndex:w.scheduleIndex,completed:w.completed,sets:w.results,volume,adapted:!!w.day.adapted};
    state.logs.unshift(log);save(KEYS.logs,state.logs);state.workout=null;keepAwake(false); const prs=sessionPRs(w.results);
    modal(`<div class="modal"><div class="handle"></div><div style="text-align:center;padding:12px 4px"><div style="font-size:54px">✓</div><h2 style="font-size:28px;margin:8px 0">Entrenamiento completado</h2><p class="muted">${mins} min · ${w.results.length} series${volume?` · ${volume.toLocaleString('es-CL')} kg de volumen`:''}</p>${prs.length?`<div class="card" style="text-align:left;margin-top:14px"><span class="badge lime">PROGRESO</span>${prs.map(x=>`<p style="margin:8px 0 0"><b>${escapeHtml(x.name)}</b>: ${x.text}</p>`).join('')}</div>`:''}<div class="section-title"><h3>¿Cómo se sintió?</h3><span>Ayuda a adaptar</span></div><div class="feedback4"><button data-feel="easy">Muy fácil</button><button data-feel="good" class="active">Bien</button><button data-feel="hard">Exigente</button><button data-feel="too-hard">Muy difícil</button></div><div class="space12"></div><button class="btn full" id="doneWorkout">Guardar y volver al inicio</button></div></div>`,false);
    let feel='good'; $$('.feedback4 button').forEach(b=>b.onclick=()=>{$$('.feedback4 button').forEach(x=>x.classList.remove('active'));b.classList.add('active');feel=b.dataset.feel;});
    $('#doneWorkout').onclick=()=>{log.feedback=feel;save(KEYS.logs,state.logs);closeModal();state.tab='home';render();syncNav();};
  }
  function sessionPRs(results){
    const out=[]; for(const id of [...new Set(results.map(x=>x.exerciseId))]){const now=results.filter(x=>x.exerciseId===id&&x.weight>0);if(!now.length)continue;const best=Math.max(...now.map(x=>x.weight*(1+x.reps/30)));const older=workoutLogs().slice(1).flatMap(l=>(l.sets||[]).filter(x=>x.exerciseId===id&&x.weight>0)).map(x=>x.weight*(1+x.reps/30));const old=older.length?Math.max(...older):0;if(old&&best>old*1.01)out.push({name:now[0].exerciseName,text:`nuevo récord estimado +${Math.round((best/old-1)*100)}%`});} return out.slice(0,3);
  }
  function confirmQuitWorkout(){if(confirm('¿Abandonar el entrenamiento? Las series de esta sesión no se guardarán.')){state.workout=null;keepAwake(false);closeModal();}}

  function renderProgress(){
    const weightLogs=state.logs.filter(l=>l.type==='weight').slice().reverse(), workouts=workoutLogs(), now=new Date();
    const thisMonth=workouts.filter(l=>{const d=new Date(l.timestamp);return d.getMonth()===now.getMonth()&&d.getFullYear()===now.getFullYear();}).length;
    const since=Date.now()-28*86400000,last28=workouts.filter(l=>l.timestamp>=since).length,target=Math.max(1,(state.profile.days||4)*4),adherence=Math.min(100,Math.round(last28/target*100)); const stats=strengthStats();
    const weeklyMuscles=muscleScoresForExercises(workouts.filter(l=>l.timestamp>=Date.now()-7*86400000).flatMap(l=>(l.sets||[]).map(x=>({id:x.exerciseId}))));
    const muscleRows=Object.entries(weeklyMuscles).sort((a,b)=>b[1]-a[1]).slice(0,8); const maxM=Math.max(1,...muscleRows.map(x=>x[1]));
    screen.innerHTML=`<div class="grid3"><div class="stat"><b>${latestWeight().toFixed(1)}</b><small>kg actual</small></div><div class="stat"><b>${thisMonth}</b><small>este mes</small></div><div class="stat"><b>${adherence}%</b><small>constancia 28d</small></div></div>
      <div class="section-title"><h3>Fuerza y récords</h3><span>e1RM estimado</span></div><div class="card strength-list">${stats.length?stats.slice(0,6).map((x,i)=>`<div class="strength-row"><div><b>${i===0?'🏆 ':''}${escapeHtml(x.name)}</b><span>${x.bestWeight} kg × ${x.bestReps} reps</span></div><div><strong>${Math.round(x.bestE1rm)} kg</strong>${x.change!==null?`<small class="${x.change>=0?'up':'down'}">${x.change>=0?'↑':'↓'} ${Math.abs(x.change)}%</small>`:'<small>nuevo</small>'}</div></div>`).join(''):'<p class="muted">Registra cargas para construir tus récords.</p>'}</div>
      <div class="section-title"><h3>Balance muscular · 7 días</h3><span>Participación relativa</span></div><div class="card">${muscleRows.length?muscleRows.map(([k,v])=>`<div class="muscle-bar"><span>${muscleLabel(k)}</span><div><i style="width:${Math.round(v/maxM*100)}%"></i></div><b>${v}</b></div>`).join(''):'<p class="muted">Completa entrenamientos para ver qué zonas han recibido más trabajo.</p>'}</div>
      <div class="section-title"><h3>Peso corporal</h3><button class="btn small" id="addWeight">＋ Registrar</button></div><div class="chart">${weightChart(weightLogs)}</div>
      <div class="section-title"><h3>Historial</h3><span>${state.logs.length} registros</span></div><div class="card">${state.logs.length?state.logs.slice(0,12).map(l=>historyItem(l)).join(''):'<p class="muted">Aún no hay registros.</p>'}</div>`;
    $('#addWeight').onclick=addWeightModal;
  }
  function latestWeight(){const l=state.logs.find(x=>x.type==='weight');return Number(l?.value||state.profile?.weight||70);}
  function historyRow(l){
    if(l.type==='workout')return `<div class="history-item"><div><b>🏋 ${escapeHtml(l.name)}</b><br><span>${fmtDate(l.date)} · ${(l.sets||[]).length} series</span></div><span>${l.minutes} min</span></div>`;
    if(l.type==='weight')return `<div class="history-item"><div><b>⚖ Registro de peso</b><br><span>${fmtDate(l.date)}</span></div><span>${Number(l.value).toFixed(1)} kg</span></div>`;
    if(l.type==='kegel')return `<div class="history-item"><div><b>◉ Suelo pélvico</b><br><span>${fmtDate(l.date)}</span></div><span>Sesión</span></div>`;
    return `<div class="history-item"><div><b>Registro</b><br><span>${fmtDate(l.date)}</span></div><span>—</span></div>`;
  }
  function strengthStats(){
    const by={}; const chronological=workoutLogs().slice().reverse();
    chronological.forEach(l=>{
      const session={}; (l.sets||[]).forEach(x=>{if(!(x.weight>0&&x.reps>0))return;const e1=x.weight*(1+x.reps/30);const k=x.exerciseId;const cur=session[k];if(!cur||e1>cur.e1)session[k]={e1,weight:x.weight,reps:x.reps,name:x.exerciseName};});
      Object.entries(session).forEach(([k,x])=>{const o=by[k]||(by[k]={name:x.name,first:x.e1,best:x.e1,bestWeight:x.weight,bestReps:x.reps});if(x.e1>o.best){o.best=x.e1;o.bestWeight=x.weight;o.bestReps=x.reps;}});
    });
    return Object.values(by).map(o=>({...o,bestE1rm:o.best,change:o.first?Math.round((o.best/o.first-1)*100):null})).sort((a,b)=>b.bestE1rm-a.bestE1rm);
  }
  function weightChart(logs){
    const data=logs.slice(-8);if(data.length<2)return `<div style="height:100%;display:grid;place-items:center;text-align:center;color:#7894a2;font-size:12px">Registra tu peso al menos dos veces<br>para ver la tendencia.</div>`;
    const vals=data.map(x=>Number(x.value)),min=Math.min(...vals)-.5,max=Math.max(...vals)+.5,w=300,h=145,p=18;const pts=vals.map((v,i)=>[p+i*(w-2*p)/(vals.length-1),h-p-(v-min)/(max-min)*(h-2*p)]);
    return `<svg viewBox="0 0 ${w} ${h}"><line class="gridline" x1="${p}" y1="${h-p}" x2="${w-p}" y2="${h-p}"/><line class="gridline" x1="${p}" y1="${p}" x2="${w-p}" y2="${p}"/><polyline class="line" points="${pts.map(a=>a.join(',')).join(' ')}"/>${pts.map((a,i)=>`<circle class="dot" cx="${a[0]}" cy="${a[1]}" r="4"/><text x="${a[0]-8}" y="${Math.max(9,a[1]-9)}">${vals[i].toFixed(1)}</text>`).join('')}</svg>`;
  }

  function renderKegel(){
    const k=state.kegel, mode=k.mode||'control'; const presets={control:{title:'Control',desc:'Contracciones moderadas y bien relajadas.',contract:4,hold:1,relax:6,reps:8,sets:3},endurance:{title:'Resistencia',desc:'Sostener sin perder respiración ni relajación posterior.',contract:6,hold:3,relax:8,reps:6,sets:3},relax:{title:'Relajación',desc:'Menos contracción y más respiración/descarga.',contract:2,hold:0,relax:10,reps:6,sets:2}};
    screen.innerHTML=`<div class="card accent"><span class="badge violet">SEMANA PERSONAL</span><h2 style="margin:8px 0 4px">Suelo pélvico: ${presets[mode].title}</h2><p class="muted" style="margin:0">${presets[mode].desc}</p><div class="space16"></div><div class="kegel-modes">${Object.entries(presets).map(([id,x])=>`<button class="kegel-mode ${id===mode?'active':''}" data-mode="${id}"><b>${x.title}</b><small>${id==='control'?'Coordinación':id==='endurance'?'Sostén':'Descarga'}</small></button>`).join('')}</div><div class="space16"></div><div class="phase-grid"><div class="phase active"><b>Contrae</b>${k.contract}s</div><div class="phase"><b>Mantén</b>${k.hold}s</div><div class="phase"><b>Relaja</b>${k.relax}s</div></div><div class="space16"></div><button class="btn full" id="startKegel">Comenzar sesión</button></div>
      <div class="section-title"><h3>Técnica y seguridad</h3><span>Calidad &gt; volumen</span></div><div class="card"><div class="cue"><i>1</i><div>Contrae como si quisieras evitar el paso de gases; no aprietes glúteos o abdomen en exceso.</div></div><div class="cue"><i>2</i><div>Respira normalmente. La relajación completa importa tanto como la contracción.</div></div><div class="cue"><i>3</i><div>No entrenes cortando el chorro de orina de forma habitual; úsalo solo como referencia ocasional para identificar la musculatura.</div></div></div><div class="space12"></div><div class="notice"><strong>Importante:</strong> entrenamiento general, no tratamiento médico ni garantía de mejorar la erección. Si hay dolor pélvico, síntomas urinarios o dolor al contraer, detén el programa y consulta a un profesional.</div>`;
    $$('.kegel-mode').forEach(b=>b.onclick=()=>{const p=presets[b.dataset.mode];Object.assign(k,{mode:b.dataset.mode,contract:p.contract,hold:p.hold,relax:p.relax,reps:p.reps,sets:p.sets});save(KEYS.kegel,k);renderKegel();}); $('#startKegel').onclick=startKegel;
  }
  function saveKegelSettings(){
    const k=state.kegel; k.level=$('#kLevel').value;k.reps=Math.max(4,Math.min(20,Number($('#kReps').value)||10));k.contract=Math.max(2,Math.min(10,Number($('#kContract').value)||5));k.hold=Math.max(0,Math.min(10,Number($('#kHold').value)||0));k.relax=Math.max(3,Math.min(15,Number($('#kRelax').value)||6));k.sets=Math.max(1,Math.min(5,Number($('#kSets').value)||3));save(KEYS.kegel,k);renderKegel();toast('Sesión Kegel actualizada');
  }
  function startKegel(){
    const k=state.kegel; keepAwake(true); const kt={phase:0,set:1,rep:1,left:k.contract,total:k.contract,running:true}; state.kegelTimer=kt; renderKegelTimer();
  }
  function renderKegelTimer(){
    const k=state.kegel,t=state.kegelTimer,phases=[['CONTRAE',k.contract],['MANTÉN',k.hold],['RELAJA',k.relax]].filter(x=>x[1]>0); const phase=phases[t.phase]; t.total=phase[1]; if(t.left>t.total||t.left<=0)t.left=t.total;
    modal(`<div class="modal tall"><div class="handle"></div><div class="modal-head"><div><span class="badge violet">SESIÓN ACTIVA</span><h2>Kegel guiado</h2><p class="muted" style="margin:0">Serie ${t.set}/${k.sets} · Repetición ${t.rep}/${k.reps}</p></div><button class="close" id="stopKegel">×</button></div><div class="timer-ring" id="kRing" style="--p:100"><div class="timer-content"><small id="kPhase">${phase[0]}</small><b id="kNum">${t.left}</b><span>segundos</span></div></div><div class="phase-grid">${phases.map((x,i)=>`<div class="phase ${i===t.phase?'active':''}"><b>${x[0][0]+x[0].slice(1).toLowerCase()}</b>${x[1]}s</div>`).join('')}</div><div class="space16"></div><div class="card"><p id="kTip" style="margin:0;text-align:center;color:#c6d6dd;line-height:1.5">${phase[0]==='RELAJA'?'Suelta completamente la musculatura y respira.':'Respira. Evita apretar glúteos, piernas o abdomen de forma excesiva.'}</p></div><div class="space16"></div><button class="btn secondary full" id="pauseKegel">❚❚ Pausar</button></div>`,false);
    $('#stopKegel').onclick=()=>{clearKegelTimer();keepAwake(false);closeModal();}; $('#pauseKegel').onclick=()=>{t.running=!t.running;$('#pauseKegel').textContent=t.running?'❚❚ Pausar':'▶ Continuar';};
    clearInterval(startKegel._interval); startKegel._interval=setInterval(()=>{if(!t.running)return;t.left--; if(t.left<=0){vibrate(80); advanceKegel(phases); return;} if($('#kNum'))$('#kNum').textContent=t.left;if($('#kRing'))$('#kRing').style.setProperty('--p',(t.left/t.total)*100);},1000);
  }
  function advanceKegel(phases){
    const t=state.kegelTimer,k=state.kegel; t.phase++; if(t.phase>=phases.length){t.phase=0;t.rep++;if(t.rep>k.reps){t.rep=1;t.set++;if(t.set>k.sets){finishKegel();return;}}}t.left=phases[t.phase][1];renderKegelTimer();
  }
  function finishKegel(){
    clearKegelTimer(); keepAwake(false); const k=state.kegel;k.completed=(k.completed||0)+1;k.last=today();save(KEYS.kegel,k);state.logs.unshift({type:'kegel',date:today(),timestamp:Date.now(),name:'Kegel guiado'});save(KEYS.logs,state.logs);modal(`<div class="modal"><div class="handle"></div><div style="text-align:center;padding:18px 4px"><div style="font-size:52px;color:var(--teal)">◉</div><h2>Sesión completada</h2><p class="muted">El trabajo incluye contracción y relajación. Evita agregar más volumen solo por sentir que “más es mejor”.</p><div class="space16"></div><button class="btn full closeAction">Finalizar</button></div></div>`);vibrate(120);
  }
  function clearKegelTimer(){clearInterval(startKegel._interval);state.kegelTimer=null;}

  function renderProfile(){
    const p=state.profile,edition=KEGEL_ENABLED?'NexoFit Plus':'NexoFit';
    screen.innerHTML=`<div class="card accent"><span class="badge">${edition.toUpperCase()} · 0.3</span><h2 style="margin:8px 0 4px">Tu plan, tus máquinas, tu semana</h2><p class="muted" style="margin:0">Puedes rehacer el asistente cuando cambien tus días, equipamiento u objetivo.</p></div>
      <div class="section-title"><h3>Perfil</h3></div><div class="card"><div class="grid2"><div class="field"><label>Nombre</label><input id="pName" value="${escapeHtml(p.name||'')}"></div><div class="field"><label>Edad</label><input id="pAge" type="number" min="16" max="90" value="${p.age}"></div><div class="field"><label>Peso (kg)</label><input id="pWeight" type="number" step="0.1" value="${p.weight}"></div><div class="field"><label>Altura (cm)</label><input id="pHeight" type="number" value="${p.height}"></div></div><div class="space12"></div><button class="btn full" id="rerunSetup">Reconfigurar mi plan paso a paso</button></div>
      <div class="section-title"><h3>Resumen actual</h3></div><div class="card"><div class="summary-grid"><div><span>Días</span><b>${p.days}</b></div><div><span>Lugar</span><b>${envLabel(p.environment)}</b></div><div><span>Objetivo</span><b>${goals[p.goal].label}</b></div><div><span>Sesión</span><b>${p.sessionMinutes} min</b></div><div><span>Nivel</span><b>${p.level}</b></div><div><span>Prioridad</span><b>${priorityLabel(p.priority)}</b></div></div></div>
      <div class="section-title"><h3>Datos</h3></div><div class="card"><button class="btn secondary full" id="shareProgress">Compartir resumen de progreso</button><div class="space8"></div><button class="btn danger full" id="resetApp">Borrar datos y empezar de nuevo</button></div><div class="space12"></div><div class="notice"><strong>Privacidad:</strong> ${edition} guarda perfil, rutinas e historial localmente. No usa Google Play Services, Firebase ni inicio de sesión de Google.</div>`;
    $('#rerunSetup').onclick=()=>{state.profile.name=$('#pName').value.trim()||state.profile.name;state.profile.age=Number($('#pAge').value)||state.profile.age;state.profile.weight=Number($('#pWeight').value)||state.profile.weight;state.profile.height=Number($('#pHeight').value)||state.profile.height;save(KEYS.profile,state.profile);showOnboarding(false);}; $('#resetApp').onclick=resetApp;$('#shareProgress').onclick=shareProgress;
  }
  function saveProfile(){
    const p=state.profile, old={...p};p.name=$('#pName').value.trim()||'Usuario';p.age=Number($('#pAge').value)||p.age;p.weight=Number($('#pWeight').value)||p.weight;p.height=Number($('#pHeight').value)||p.height;p.level=$('#pLevel').value;p.days=Math.max(2,Math.min(6,Number($('#pDays').value)||4));p.sessionMinutes=Math.max(25,Math.min(120,Number($('#pMinutes').value)||55));p.environment=$('#pEnv').value;p.goal=$('#pGoal').value;if(old.environment!==p.environment)p.equipment=defaultEquipment(p.environment);state.environment=p.environment;save(KEYS.profile,p);
    const structural=['level','days','sessionMinutes','environment','goal'].some(k=>old[k]!==p[k]);
    if(structural && state.plan?.customized){const rebuild=confirm('Tu rutina tiene cambios manuales.\n\nAceptar: crear un plan nuevo con tus datos.\nCancelar: conservar la rutina personalizada y solo actualizar tu perfil.');if(rebuild)regeneratePlan(false);}else if(structural)regeneratePlan(false);
    state.tab='home';render();syncNav();toast('Perfil actualizado');
  }
  function shareProgress(){
    const best=strengthStats()[0];const txt=`NexoFit 0.3 — Progreso\nPeso actual: ${latestWeight().toFixed(1)} kg\nSesiones: ${workoutLogs().length}\nRacha: ${streak()} días\nObjetivo: ${goals[state.profile.goal].label}${best?`\nMejor e1RM: ${best.name} ${Math.round(best.bestE1rm)} kg`:''}`;try{if(window.NexoNative)NexoNative.shareText(txt);else navigator.share?.({text:txt});}catch(e){}
  }
  function resetApp(){if(confirm('Esto eliminará perfil, rutinas y progreso guardado en este teléfono. ¿Continuar?')){Object.values(KEYS).forEach(k=>localStorage.removeItem(k));state.profile=null;state.plan=null;state.logs=[];state.kegel=KEGEL_ENABLED?defaultKegel():null;showOnboarding(true);}}

  function showOnboarding(force=false){
    const base={...defaultProfile(),...(state.profile||{})}; if(!base.equipment?.length)base.equipment=[...fullGymEquipment]; if(KEGEL_ENABLED && typeof base.includeKegel!=='boolean')base.includeKegel=true;
    let step=0; const draft=JSON.parse(JSON.stringify(base)); const edition=KEGEL_ENABLED?'NexoFit Plus':'NexoFit';
    const steps=KEGEL_ENABLED?10:9;
    const shell=(body,title,sub)=>`<div class="modal tall onboarding"><div class="handle"></div><div class="onboard-progress"><i style="width:${Math.round((step+1)/steps*100)}%"></i></div><div class="modal-head"><div><span class="badge">${edition.toUpperCase()} · CONFIGURACIÓN ${step+1}/${steps}</span><h2>${title}</h2><p class="muted" style="margin:0">${sub}</p></div>${force?'':'<button class="close">×</button>'}</div>${body}<div class="onboard-actions">${step>0?'<button class="btn secondary" id="oBack">← Atrás</button>':''}<button class="btn" id="oNext">${step===steps-1?'Crear mi plan':'Continuar →'}</button></div></div>`;
    const renderStep=()=>{
      let body='',title='',sub='';
      if(step===0){title='Tu perfil';sub='Solo lo esencial para contextualizar el plan.';body=`<div class="field"><label>¿Cómo te llamas?</label><input id="oName" value="${escapeHtml(draft.name||'')}"></div><div class="space12"></div><div class="grid3"><div class="field"><label>Edad</label><input id="oAge" type="number" value="${draft.age}"></div><div class="field"><label>Peso kg</label><input id="oWeight" type="number" step="0.1" value="${draft.weight}"></div><div class="field"><label>Altura cm</label><input id="oHeight" type="number" value="${draft.height}"></div></div>`;}
      if(step===1){title='¿Cuántos días entrenarás?';sub='Esta es la decisión que organiza todo tu plan.';body=`<div class="big-choice-grid">${[2,3,4,5,6].map(n=>`<button class="big-choice ${draft.days===n?'active':''}" data-days="${n}"><b>${n}</b><span>días / semana</span><small>${n<=3?'Simple y sostenible':n===4?'Gran equilibrio':'Alta frecuencia'}</small></button>`).join('')}</div>`;}
      if(step===2){title='¿Dónde entrenarás?';sub='Puedes combinar gimnasio y sesiones al aire libre.';body=`<div class="big-choice-grid cols3">${[['gym','🏋','Gimnasio','Máquinas y cargas'],['outdoor','🌳','Aire libre','Peso corporal / bandas'],['mixed','🔄','Mixto','Combina ambos']].map(([id,ic,t,d])=>`<button class="big-choice ${draft.environment===id?'active':''}" data-env="${id}"><b class="choice-icon">${ic}</b><span>${t}</span><small>${d}</small></button>`).join('')}</div>${draft.environment==='mixed'?`<div class="space16"></div><div class="field"><label>Días de gimnasio dentro de tus ${draft.days} días</label><input id="oMixedGym" type="range" min="1" max="${Math.max(1,draft.days-1)}" value="${Math.min(draft.days-1,draft.mixedGymDays||Math.ceil(draft.days/2))}"><div class="range-label"><span>1</span><b id="mixedLabel">${draft.mixedGymDays||Math.ceil(draft.days/2)} gimnasio · ${draft.days-(draft.mixedGymDays||Math.ceil(draft.days/2))} exterior</b><span>${draft.days-1}</span></div></div>`:''}`;}
      if(step===3){title='¿Cuál es tu objetivo principal?';sub='La selección cambia rangos, descansos y prioridades.';body=`<div class="goal-grid">${Object.entries(goals).map(([k,g])=>`<button class="goal ${k===draft.goal?'selected':''}" data-goal="${k}"><span>${g.icon}</span><b>${g.label}</b><small>${g.note}</small></button>`).join('')}</div>`;}
      if(step===4){title='¿Cuánto tiempo tienes por sesión?';sub='NexoFit ajustará la cantidad de ejercicios.';body=`<div class="time-big">${[30,45,60,75,90].map(n=>`<button class="time-card ${Math.abs((draft.sessionMinutes||55)-n)<8?'active':''}" data-time="${n}"><b>${n}</b><span>min</span></button>`).join('')}</div>`;}
      if(step===5){title='¿Qué experiencia tienes?';sub='No es un examen: solo ajusta volumen y complejidad.';body=`<div class="big-choice-grid cols3">${[['Principiante','Estoy empezando','Más guía y menos volumen'],['Intermedio','Entreno hace un tiempo','Progresión estándar'],['Avanzado','Tengo experiencia','Más volumen y autonomía']].map(([id,t,d])=>`<button class="big-choice ${draft.level===id?'active':''}" data-level="${id}"><span>${t}</span><small>${d}</small></button>`).join('')}</div>`;}
      if(step===6){title='¿Qué equipamiento tienes?';sub=draft.environment==='outdoor'?'Podemos trabajar sin máquinas.':'Esto evita recomendar máquinas que no existen en tu gimnasio.';body=draft.environment==='outdoor'?`<div class="big-choice-grid"><button class="big-choice active"><b class="choice-icon">🤸</b><span>Peso corporal</span><small>Siempre disponible</small></button><button class="big-choice ${draft.equipment.includes('bands')?'active':''}" data-band="1"><b class="choice-icon">➰</b><span>Bandas</span><small>Opcional</small></button></div>`:`<div class="preset-grid"><button class="preset ${draft.equipmentPreset==='full'?'active':''}" data-preset="full"><b>Gimnasio completo</b><small>Máquinas, poleas, barras y mancuernas</small></button><button class="preset ${draft.equipmentPreset==='basic'?'active':''}" data-preset="basic"><b>Gimnasio básico</b><small>Mancuernas, banco, polea y algunas máquinas</small></button><button class="preset ${draft.equipmentPreset==='custom'?'active':''}" data-preset="custom"><b>Personalizar</b><small>Marca exactamente lo que tienes</small></button></div><div id="equipmentCustom" class="equipment-chips ${draft.equipmentPreset==='custom'?'':'hidden'}">${equipmentCatalog.filter(x=>x[0]!=='bodyweight').map(([id,l])=>`<button class="equipment-chip ${draft.equipment.includes(id)?'active':''}" data-eq="${id}">${l}</button>`).join('')}</div>`;}
      if(step===7){title='¿Quieres priorizar alguna zona?';sub='No descuidaremos el resto; solo cambia el énfasis.';body=`<div class="priority-grid">${[['balanced','⚖','Equilibrado'],['chest','◒','Pecho'],['back','↔','Espalda'],['arms','💪','Brazos'],['legs','🦵','Piernas'],['glutes','●','Glúteos'],['core','◎','Core']].map(([id,ic,l])=>`<button class="priority ${draft.priority===id?'active':''}" data-priority="${id}"><span>${ic}</span><b>${l}</b></button>`).join('')}</div>`;}
      if(step===8){title='¿Algo que quieras evitar?';sub='Puedes omitir ejercicios concretos y agregar una nota de molestias o preferencias.';body=`<div class="avoid-chips">${['squat','rdl','bench','lunge','split','shoulder','burpee'].map(id=>`<button class="avoid ${draft.avoid.includes(id)?'active':''}" data-avoid="${id}">${draft.avoid.includes(id)?'× ':''}${escapeHtml(ex[id].name)}</button>`).join('')}</div><div class="space16"></div><div class="field"><label>Nota opcional</label><textarea id="oLimit" rows="3" placeholder="Ej. evito saltos, tengo molestia de rodilla...">${escapeHtml(draft.limitations||'')}</textarea></div>`;}
      if(KEGEL_ENABLED && step===9){title='¿Quieres incluir entrenamiento de suelo pélvico?';sub='Queda separado del entrenamiento de fuerza y puedes desactivarlo después.';body=`<div class="big-choice-grid"><button class="big-choice ${draft.includeKegel?'active':''}" data-kegel="yes"><b class="choice-icon">◉</b><span>Sí, incluirlo</span><small>Control, resistencia y relajación</small></button><button class="big-choice ${!draft.includeKegel?'active':''}" data-kegel="no"><b class="choice-icon">—</b><span>Ahora no</span><small>NexoFit seguirá funcionando sin este módulo</small></button></div>`;}
      if((!KEGEL_ENABLED&&step===8)||(KEGEL_ENABLED&&step===9)){/* normal step, preview opens after next */}
      modal(shell(body,title,sub),false); bindStep();
    };
    const bindStep=()=>{
      if($('#oName')){ const stash=()=>{draft.name=$('#oName').value.trim()||'Usuario';draft.age=Number($('#oAge').value)||31;draft.weight=Number($('#oWeight').value)||70;draft.height=Number($('#oHeight').value)||170;}; $('#oName').oninput=stash;$('#oAge').oninput=stash;$('#oWeight').oninput=stash;$('#oHeight').oninput=stash; }
      $$('[data-days]').forEach(b=>b.onclick=()=>{draft.days=Number(b.dataset.days);draft.mixedGymDays=Math.min(draft.days-1,Math.max(1,draft.mixedGymDays||Math.ceil(draft.days/2)));renderStep();});
      $$('[data-env]').forEach(b=>b.onclick=()=>{draft.environment=b.dataset.env;if(draft.environment==='outdoor'){draft.equipmentPreset='outdoor';draft.equipment=['bodyweight'];}renderStep();});
      if($('#oMixedGym')) $('#oMixedGym').oninput=e=>{draft.mixedGymDays=Number(e.target.value);$('#mixedLabel').textContent=`${draft.mixedGymDays} gimnasio · ${draft.days-draft.mixedGymDays} exterior`;};
      $$('[data-goal]').forEach(b=>b.onclick=()=>{draft.goal=b.dataset.goal;renderStep();}); $$('[data-time]').forEach(b=>b.onclick=()=>{draft.sessionMinutes=Number(b.dataset.time);renderStep();}); $$('[data-level]').forEach(b=>b.onclick=()=>{draft.level=b.dataset.level;renderStep();});
      $$('[data-preset]').forEach(b=>b.onclick=()=>{draft.equipmentPreset=b.dataset.preset;if(draft.equipmentPreset==='full')draft.equipment=[...fullGymEquipment];if(draft.equipmentPreset==='basic')draft.equipment=[...basicGymEquipment];renderStep();});
      $$('[data-eq]').forEach(b=>b.onclick=()=>{const id=b.dataset.eq;draft.equipment=draft.equipment.includes(id)?draft.equipment.filter(x=>x!==id):[...draft.equipment,id];b.classList.toggle('active');}); if($('[data-band]')) $('[data-band]').onclick=()=>{draft.equipment=draft.equipment.includes('bands')?draft.equipment.filter(x=>x!=='bands'):[...draft.equipment,'bands'];renderStep();};
      $$('[data-priority]').forEach(b=>b.onclick=()=>{draft.priority=b.dataset.priority;renderStep();}); $$('[data-avoid]').forEach(b=>b.onclick=()=>{const id=b.dataset.avoid;draft.avoid=draft.avoid.includes(id)?draft.avoid.filter(x=>x!==id):[...draft.avoid,id];renderStep();}); if($('#oLimit')) $('#oLimit').oninput=e=>draft.limitations=e.target.value;
      $$('[data-kegel]').forEach(b=>b.onclick=()=>{draft.includeKegel=b.dataset.kegel==='yes';renderStep();});
      if($('#oBack')) $('#oBack').onclick=()=>{step--;renderStep();}; $('#oNext').onclick=()=>{if(step<steps-1){step++;renderStep();}else showPlanPreview();};
    };
    const showPlanPreview=()=>{
      const plan=generatePlan(draft); const first=scheduledFrom(plan,0); modal(`<div class="modal tall plan-ready"><div class="handle"></div><div class="ready-check">✓</div><h2>Tu plan está listo</h2><p class="muted">${draft.days} días · ${envLabel(draft.environment)} · ${goals[draft.goal].label} · ${draft.sessionMinutes} min</p><div class="schedule-preview">${plan.schedule.map((s,i)=>{const d=plan[s.environment][s.index];return `<div><b>D${i+1}</b><span>${s.environment==='gym'?'🏋':'🌳'}</span><strong>${escapeHtml(d.name)}</strong><small>${d.exercises.length} ejercicios</small></div>`}).join('')}</div>${first?`<div class="section-title"><h3>Tu primera sesión</h3><span>${dayTopMuscles(first.day).join(' · ')}</span></div><div class="card visual-overview">${bodyMapSvg(first.day.exercises,true)}<div class="how-grid">${first.day.exercises.slice(0,3).map(e=>`<div class="how-card static">${movementThumb(e.id)}<b>${escapeHtml(e.name)}</b><small>${escapeHtml((ex[e.id]?.machines||[]).slice(0,2).join(' · '))}</small></div>`).join('')}</div></div>`:''}<div class="space16"></div><button class="btn full" id="acceptPlan">Ver mi plan →</button><div class="space8"></div><button class="btn secondary full" id="editPlanSetup">← Ajustar respuestas</button></div>`,false);
      $('#editPlanSetup').onclick=()=>{step=Math.max(1,steps-2);renderStep();}; $('#acceptPlan').onclick=()=>{state.profile=draft;state.environment=draft.environment==='outdoor'?'outdoor':'gym';state.plan=plan;save(KEYS.profile,draft);save(KEYS.plan,plan);if(KEGEL_ENABLED){state.kegel=state.kegel||defaultKegel();save(KEYS.kegel,state.kegel);}closeModal();render();syncNav();toast('Tu plan 0.3 está listo');};
    };
    const scheduledFrom=(plan,i)=>{const s=plan.schedule?.[i];if(!s)return null;return {day:plan[s.environment]?.[s.index],...s,scheduleIndex:i};};
    renderStep();
  }
  function modal(html,bindClose=true){ modalRoot.innerHTML=`<div class="modal-backdrop">${html}</div>`; if(bindClose) bindModalClose(); else { const c=$('.modal .close'); if(c && !c.id) c.onclick=closeModal; } }
  function bindModalClose(){ const b=$('.modal-backdrop'); if(!b)return; $$('.close,.closeAction',b).forEach(x=>x.onclick=closeModal); b.addEventListener('click',e=>{if(e.target===b)closeModal();}); }
  function closeModal(){ modalRoot.innerHTML=''; }
  window.NexoFitHandleBack=()=>{
    if(modalRoot.innerHTML){
      if(state.workout) confirmQuitWorkout();
      else { if(state.kegelTimer){clearKegelTimer();keepAwake(false);} closeModal(); }
      return true;
    }
    if(state.tab!=='home'){state.tab='home';render();syncNav();return true;}
    return false;
  };

  init();
})();
