# NexoFit MVP: sin reglas especiales.
