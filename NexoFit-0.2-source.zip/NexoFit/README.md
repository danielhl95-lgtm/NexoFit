# NexoFit 0.2

Aplicación Android fitness offline, pensada para funcionar sin Google Play Services.

## Ediciones

- **NexoFit** (`standard`): entrenamiento, progreso y programación, sin módulo de suelo pélvico.
- **NexoFit Plus** (`pelvic`): mismas funciones + módulo Kegel/suelo pélvico.

Las dos ediciones salen del mismo código y pueden evolucionar en paralelo. La variante Pelvic usa un `applicationId` distinto, por lo que puede instalarse junto a NexoFit estándar.

## Novedades 0.2

- Próximo entrenamiento automático según la última sesión completada.
- Registro por serie de **peso, repeticiones/segundos y RIR**.
- Sugerencia de carga usando la sesión anterior y el rango de repeticiones.
- Progreso de fuerza mediante e1RM estimado.
- Registro de volumen y series por entrenamiento.
- Biblioteca para añadir y reemplazar ejercicios.
- Eliminar y reordenar ejercicios.
- Duración disponible modifica el largo del plan.
- Objetivos generan diferencias más claras de series, reps y descansos.
- Descansos robustos con botón +30 s y cálculo por hora real.
- Pantalla se mantiene encendida durante sesiones activas.
- Manejo del botón Atrás más seguro.
- Fechas en hora local.
- Historial distingue correctamente entrenamientos, peso y Kegel.
- Protección de rutinas personalizadas al cambiar perfil.
- Migración de datos 0.1 → 0.2 en la edición estándar.

## Compilar

```bash
gradle :app:assembleStandardDebug :app:assemblePelvicDebug
```

Salidas:

- `app/build/outputs/apk/standard/debug/app-standard-debug.apk`
- `app/build/outputs/apk/pelvic/debug/app-pelvic-debug.apk`
