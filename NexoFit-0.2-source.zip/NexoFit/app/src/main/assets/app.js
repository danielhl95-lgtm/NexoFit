(() => {
  'use strict';

  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const screen = $('#screen');
  const modalRoot = $('#modalRoot');
  const toastEl = $('#toast');

  const EDITION = new URLSearchParams(location.search).get('edition') || 'standard';
  const KEGEL_ENABLED = EDITION === 'pelvic';
  const APP_VERSION = '0.2.0';
  const KEYS = { profile:'nexofit.profile.v2', plan:'nexofit.plan.v2', logs:'nexofit.logs.v2', kegel:'nexofit.kegel.v2' };
  const LEGACY = { profile:'nexofit.profile.v1', plan:'nexofit.plan.v1', logs:'nexofit.logs.v1', kegel:'nexofit.kegel.v1' };
  const state = {
    tab:'home', environment:'gym', day:0, profile:null, plan:null,
    logs:[], kegel:null, workout:null, kegelTimer:null
  };

  const goals = {
    muscle:{label:'Ganar músculo', icon:'💪', note:'Más masa y fuerza'},
    recomposition:{label:'Recomposición', icon:'⚡', note:'Músculo + control de grasa'},
    fat:{label:'Bajar grasa', icon:'🔥', note:'Más gasto y condición'},
    strength:{label:'Fuerza', icon:'🏋', note:'Progresar cargas'},
    fitness:{label:'Rendimiento', icon:'🏃', note:'Resistencia y capacidad física'}
  };

  const ex = {
    squat:{name:'Sentadilla',muscles:'Cuádriceps · glúteos · core',sets:4,reps:'8–12',rest:90,anim:'squat',video:'https://www.youtube.com/results?search_query=sentadilla+tecnica+correcta',cues:['Pecho abierto y abdomen firme.','Rodillas siguiendo la dirección de los pies.','Desciende con control hasta un rango cómodo.','Empuja el suelo al subir.'],bad:['Colapsar las rodillas hacia dentro.','Redondear la espalda por buscar más profundidad.','Rebotar sin control en la parte baja.']},
    rdl:{name:'Peso muerto rumano',muscles:'Isquiotibiales · glúteos · espalda',sets:4,reps:'8–10',rest:100,anim:'hinge',video:'https://www.youtube.com/results?search_query=peso+muerto+rumano+tecnica',cues:['Cadera viaja hacia atrás.','Barra o mancuernas cerca de las piernas.','Columna neutra y cuello relajado.','Sube contrayendo glúteos, sin hiperextender.'],bad:['Convertirlo en una sentadilla.','Alejar la carga del cuerpo.','Bajar más allá de tu movilidad.']},
    legpress:{name:'Prensa de piernas',muscles:'Cuádriceps · glúteos',sets:4,reps:'10–15',rest:90,anim:'squat',video:'https://www.youtube.com/results?search_query=prensa+de+piernas+tecnica',cues:['Apoya toda la planta del pie.','Controla el descenso.','Mantén pelvis estable contra el respaldo.'],bad:['Bloquear las rodillas agresivamente.','Despegar la cadera del respaldo.']},
    lunge:{name:'Zancadas',muscles:'Glúteos · cuádriceps · core',sets:3,reps:'10–12 c/pierna',rest:70,anim:'lunge',video:'https://www.youtube.com/results?search_query=zancadas+tecnica+correcta',cues:['Paso suficientemente largo para mantener equilibrio.','Tronco estable.','Empuja con el pie delantero.'],bad:['Golpear la rodilla contra el suelo.','Perder alineación de rodilla y pie.']},
    legext:{name:'Extensión de cuádriceps',muscles:'Cuádriceps',sets:3,reps:'12–15',rest:60,anim:'squat',video:'https://www.youtube.com/results?search_query=extension+de+cuadriceps+maquina+tecnica',cues:['Alinea la rodilla con el eje de la máquina.','Sube sin impulso y baja lento.'],bad:['Usar una carga que obligue a rebotar.']},
    legcurl:{name:'Curl femoral',muscles:'Isquiotibiales',sets:3,reps:'10–15',rest:60,anim:'hinge',video:'https://www.youtube.com/results?search_query=curl+femoral+maquina+tecnica',cues:['Mantén la pelvis estable.','Aprieta atrás y controla la vuelta.'],bad:['Arquear la espalda para mover la carga.']},
    calves:{name:'Elevación de gemelos',muscles:'Gemelos · sóleo',sets:4,reps:'12–20',rest:45,anim:'calf',video:'https://www.youtube.com/results?search_query=elevacion+de+gemelos+tecnica',cues:['Recorre un rango cómodo completo.','Pausa arriba un instante.'],bad:['Rebotar rápidamente.']},
    bench:{name:'Press de banca',muscles:'Pectoral · tríceps · deltoide anterior',sets:4,reps:'6–10',rest:110,anim:'push',video:'https://www.youtube.com/results?search_query=press+banca+tecnica+correcta',cues:['Escápulas estables contra el banco.','Pies firmes en el suelo.','Baja con control.'],bad:['Abrir excesivamente los codos.','Rebotar la barra en el pecho.']},
    incline:{name:'Press inclinado con mancuernas',muscles:'Pectoral superior · hombros · tríceps',sets:3,reps:'8–12',rest:80,anim:'push',video:'https://www.youtube.com/results?search_query=press+inclinado+mancuernas+tecnica',cues:['Controla el recorrido.','Mantén hombros lejos de las orejas.'],bad:['Chocar las mancuernas arriba.']},
    row:{name:'Remo sentado',muscles:'Dorsal · romboides · bíceps',sets:4,reps:'8–12',rest:85,anim:'row',video:'https://www.youtube.com/results?search_query=remo+sentado+polea+tecnica',cues:['Inicia llevando hombros atrás y abajo.','Codos viajan hacia atrás.','Evita balancear el torso.'],bad:['Tirar solo con los brazos.','Redondear la espalda.']},
    pulldown:{name:'Jalón al pecho',muscles:'Dorsal · bíceps',sets:4,reps:'8–12',rest:80,anim:'row',video:'https://www.youtube.com/results?search_query=jalon+al+pecho+tecnica',cues:['Pecho alto, hombros abajo.','Lleva la barra hacia la parte alta del pecho.'],bad:['Llevar la barra detrás de la cabeza.','Balancearte para ganar impulso.']},
    shoulder:{name:'Press de hombros',muscles:'Deltoides · tríceps',sets:3,reps:'8–12',rest:80,anim:'push',video:'https://www.youtube.com/results?search_query=press+militar+mancuernas+tecnica',cues:['Abdomen firme.','Sube la carga sin arquear la espalda.'],bad:['Extender demasiado la zona lumbar.']},
    lateral:{name:'Elevaciones laterales',muscles:'Deltoide medio',sets:3,reps:'12–18',rest:55,anim:'raise',video:'https://www.youtube.com/results?search_query=elevaciones+laterales+tecnica',cues:['Codos ligeramente flexionados.','Sube con control hasta una altura cómoda.'],bad:['Impulsar el torso.']},
    curl:{name:'Curl de bíceps',muscles:'Bíceps · braquial',sets:3,reps:'10–15',rest:55,anim:'curl',video:'https://www.youtube.com/results?search_query=curl+biceps+tecnica',cues:['Codos cerca del cuerpo.','Baja controlando.'],bad:['Balancear el tronco.']},
    triceps:{name:'Extensión de tríceps en polea',muscles:'Tríceps',sets:3,reps:'10–15',rest:55,anim:'push',video:'https://www.youtube.com/results?search_query=triceps+polea+tecnica',cues:['Codos quietos.','Extiende y aprieta sin encoger hombros.'],bad:['Mover todo el brazo para generar impulso.']},
    hip:{name:'Hip thrust',muscles:'Glúteos · isquiotibiales',sets:4,reps:'8–12',rest:90,anim:'hinge',video:'https://www.youtube.com/results?search_query=hip+thrust+tecnica',cues:['Mentón ligeramente recogido.','Sube hasta alinear tronco y muslos.','Pausa arriba contrayendo glúteos.'],bad:['Hiperextender la espalda.']},
    plank:{name:'Plancha',muscles:'Core · glúteos · hombros',sets:3,reps:'30–60 s',rest:45,anim:'push',video:'https://www.youtube.com/results?search_query=plancha+abdominal+tecnica',cues:['Cuerpo en línea.','Aprieta abdomen y glúteos.','Respira sin perder postura.'],bad:['Dejar caer la cadera.','Elevar demasiado la cadera.']},
    pushup:{name:'Flexiones',muscles:'Pectoral · tríceps · core',sets:4,reps:'8–20',rest:60,anim:'push',video:'https://www.youtube.com/results?search_query=flexiones+tecnica+correcta',cues:['Cuerpo rígido.','Manos bajo o ligeramente fuera de hombros.','Baja con control.'],bad:['Sacar la cabeza hacia delante.','Perder tensión abdominal.']},
    airSquat:{name:'Sentadilla con peso corporal',muscles:'Piernas · glúteos · core',sets:4,reps:'15–25',rest:45,anim:'squat',video:'https://www.youtube.com/results?search_query=sentadilla+peso+corporal+tecnica',cues:['Mantén el pie completo apoyado.','Controla la bajada y sube con intención.'],bad:['Juntar las rodillas hacia dentro.']},
    split:{name:'Sentadilla búlgara',muscles:'Glúteos · cuádriceps',sets:3,reps:'8–15 c/pierna',rest:65,anim:'lunge',video:'https://www.youtube.com/results?search_query=sentadilla+bulgara+tecnica',cues:['Busca un apoyo estable.','Baja verticalmente con control.'],bad:['Poner el pie delantero demasiado cerca.']},
    mountain:{name:'Mountain climbers',muscles:'Core · hombros · cardio',sets:4,reps:'30–45 s',rest:35,anim:'push',video:'https://www.youtube.com/results?search_query=mountain+climbers+tecnica',cues:['Manos firmes bajo hombros.','Mueve las piernas sin perder la cadera.'],bad:['Rebotar la pelvis excesivamente.']},
    burpee:{name:'Burpees',muscles:'Full body · cardio',sets:4,reps:'8–15',rest:60,anim:'squat',video:'https://www.youtube.com/results?search_query=burpees+tecnica',cues:['Prioriza técnica antes que velocidad.','Aterriza suave.'],bad:['Colapsar la espalda al bajar al suelo.']},
    stepup:{name:'Step-ups',muscles:'Glúteos · cuádriceps',sets:3,reps:'10–15 c/pierna',rest:55,anim:'lunge',video:'https://www.youtube.com/results?search_query=step+ups+tecnica',cues:['Apoya el pie completo en una superficie estable.','Sube usando la pierna de arriba.'],bad:['Impulsarte demasiado con la pierna de abajo.']},
    walk:{name:'Caminata rápida / trote suave',muscles:'Cardio · piernas',sets:1,reps:'20–35 min',rest:0,anim:'lunge',video:'https://www.youtube.com/results?search_query=tecnica+trote+principiantes',cues:['Ritmo en el que puedas mantener buena postura.','Aumenta tiempo gradualmente.'],bad:['Subir volumen muy rápido.']}
  };

  const gymTemplates = [
    {name:'Tren inferior',subtitle:'Fuerza y estabilidad',ids:['squat','rdl','legpress','lunge','legext','legcurl','calves']},
    {name:'Tren superior',subtitle:'Empuje + tracción',ids:['bench','row','pulldown','incline','shoulder','lateral','curl','triceps']},
    {name:'Full body A',subtitle:'Base completa',ids:['squat','bench','row','rdl','shoulder','plank']},
    {name:'Full body B',subtitle:'Volumen equilibrado',ids:['hip','pulldown','incline','lunge','lateral','curl','triceps']},
    {name:'Piernas + core',subtitle:'Glúteos, piernas y control',ids:['hip','squat','legcurl','legext','calves','plank']},
    {name:'Torso + brazos',subtitle:'Espalda, pecho y brazos',ids:['bench','pulldown','row','shoulder','lateral','curl','triceps']}
  ];
  const outdoorTemplates = [
    {name:'Full body parque',subtitle:'Sin equipamiento',ids:['airSquat','pushup','lunge','mountain','plank','burpee']},
    {name:'Piernas al aire libre',subtitle:'Fuerza unilateral',ids:['airSquat','split','stepup','lunge','calves','plank']},
    {name:'Acondicionamiento',subtitle:'Cardio + fuerza',ids:['walk','airSquat','pushup','mountain','burpee','plank']},
    {name:'Full body control',subtitle:'Técnica y volumen',ids:['split','pushup','airSquat','stepup','plank','mountain']}
  ];

  const load = (k,fallback) => { try { const v=localStorage.getItem(k); return v?JSON.parse(v):fallback; } catch(e){ return fallback; } };
  const save = (k,v) => localStorage.setItem(k,JSON.stringify(v));
  const dateKey = d => { const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0'); return `${y}-${m}-${day}`; };
  const today = () => dateKey(new Date());
  const fmtDate = iso => new Date(iso+'T12:00:00').toLocaleDateString('es-CL',{day:'2-digit',month:'short'});
  const vibrate = ms => { try { if(window.NexoNative) NexoNative.vibrate(ms); else if(navigator.vibrate) navigator.vibrate(ms); } catch(e){} };
  const openExternal = url => { try { if(window.NexoNative) NexoNative.openExternal(url); else window.open(url,'_blank'); } catch(e){ window.location.href=url; } };
  const keepAwake = on => { try { if(window.NexoNative?.setKeepScreenOn) NexoNative.setKeepScreenOn(!!on); } catch(e){} };
  const toast = msg => { toastEl.textContent=msg; toastEl.classList.add('show'); clearTimeout(toast._t); toast._t=setTimeout(()=>toastEl.classList.remove('show'),1800); };
  const escapeHtml = s => String(s).replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m]));

  function init(){
    if(!localStorage.getItem(KEYS.profile) && localStorage.getItem(LEGACY.profile)){
      save(KEYS.profile,load(LEGACY.profile,null)); save(KEYS.plan,load(LEGACY.plan,null)); save(KEYS.logs,load(LEGACY.logs,[])); if(KEGEL_ENABLED) save(KEYS.kegel,load(LEGACY.kegel,{level:'Intermedio',contract:5,hold:3,relax:6,reps:10,sets:3,completed:0,last:null}));
    }
    state.profile = load(KEYS.profile,null);
    state.logs = load(KEYS.logs,[]);
    state.kegel = KEGEL_ENABLED ? load(KEYS.kegel,{level:'Intermedio',contract:5,hold:3,relax:6,reps:10,sets:3,completed:0,last:null}) : null;
    state.plan = load(KEYS.plan,null);
    const kNav=$('.nav-item[data-tab="kegel"]'); if(kNav && !KEGEL_ENABLED) kNav.remove();
    const nav=$('.bottom-nav'); if(nav) nav.style.gridTemplateColumns=`repeat(${KEGEL_ENABLED?5:4},1fr)`;
    document.title=KEGEL_ENABLED?'NexoFit Plus':'NexoFit';
    if(!state.profile){ state.profile = defaultProfile(); showOnboarding(true); }
    else { if(!state.plan) regeneratePlan(false); render(); }
    bindNav();
    $('#settingsBtn').addEventListener('click',()=>{ state.tab='profile'; render(); syncNav(); });
  }

  function defaultProfile(){ return {name:'Daniel',age:31,weight:70,height:164,goal:'muscle',level:'Intermedio',days:4,environment:'gym',sessionMinutes:55}; }

  function bindNav(){
    $$('.nav-item').forEach(b=>b.addEventListener('click',()=>{
      state.tab=b.dataset.tab; render(); syncNav();
    }));
  }
  function syncNav(){ $$('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.tab===state.tab)); }

  function render(){
    if(state.tab==='kegel' && !KEGEL_ENABLED) state.tab='home';
    const names={home:[KEGEL_ENABLED?'NEXOFIT PELVIC':'NEXOFIT','Inicio'],routine:['PLAN EDITABLE','Rutina'],progress:['TU EVOLUCIÓN','Progreso'],kegel:['SUELO PÉLVICO','Kegel'],profile:['CONFIGURACIÓN','Más']};
    $('#pageEyebrow').textContent=names[state.tab][0]; $('#pageTitle').textContent=names[state.tab][1];
    if(state.tab==='home') renderHome();
    if(state.tab==='routine') renderRoutine();
    if(state.tab==='progress') renderProgress();
    if(state.tab==='kegel' && KEGEL_ENABLED) renderKegel();
    if(state.tab==='profile') renderProfile();
  }

  function generatePlan(profile){
    const n=Math.max(2,Math.min(6,Number(profile.days)||4));
    const gym=[]; const outdoor=[];
    const gymOrder=n<=2?[2,3]:n===3?[2,0,1]:n===4?[0,1,4,5]:[0,1,4,5,2,3];
    const outOrder=[0,1,2,3,0,2];
    for(let i=0;i<n;i++){
      const g=gymTemplates[gymOrder[i%gymOrder.length]], o=outdoorTemplates[outOrder[i%outOrder.length]];
      gym.push(makeDay(g,i,'gym',profile)); outdoor.push(makeDay(o,i,'outdoor',profile));
    }
    return {created:Date.now(),version:2,customized:false,gym,outdoor};
  }
  function makeDay(t,i,env,profile){
    const minutes=Math.max(25,Math.min(120,Number(profile.sessionMinutes)||55));
    const perExercise=env==='gym'?7.5:5.5;
    const maxExercises=Math.max(3,Math.min(t.ids.length,Math.round(minutes/perExercise)));
    const ids=t.ids.slice(0,maxExercises);
    const arr=ids.map(id=>{
      const base=ex[id]; let sets=base.sets, rest=base.rest, reps=base.reps;
      if(profile.goal==='fat'){ rest=Math.max(35,Math.round(rest*.70)); if(!/min|s$/.test(reps)) reps='12–18'; }
      if(profile.goal==='strength' && ['squat','bench','rdl','row','pulldown','hip'].includes(id)){ sets=Math.max(4,sets); rest=Math.max(120,rest); reps='4–7'; }
      if(profile.goal==='recomposition'){ rest=Math.max(50,Math.round(rest*.9)); if(!/min|s$/.test(reps)) reps='8–12'; }
      if(profile.goal==='fitness' && env==='outdoor'){ rest=Math.max(25,Math.round(rest*.65)); sets=Math.max(3,sets); }
      if(profile.goal==='muscle' && !/min|s$/.test(reps)){ reps=id==='calves'||id==='lateral'?'12–20':'8–12'; }
      if(profile.level==='Principiante') sets=Math.max(2,sets-1);
      if(profile.level==='Avanzado' && profile.goal==='muscle' && sets<4) sets++;
      return {id,name:base.name,muscles:base.muscles,sets,reps,rest,done:false};
    });
    const estimated=Math.min(minutes,Math.max(20,Math.round(arr.length*perExercise)));
    return {name:t.name,subtitle:t.subtitle,day:i+1,environment:env,minutes:estimated,exercises:arr};
  }
  function regeneratePlan(show=true){ state.plan=generatePlan(state.profile); save(KEYS.plan,state.plan); state.day=0; if(show) toast('Plan actualizado'); }
  function markPlanCustomized(){ if(state.plan){state.plan.customized=true;save(KEYS.plan,state.plan);} }

  function streak(){
    if(!state.logs.length) return 0;
    const unique=[...new Set(state.logs.filter(l=>l.type==='workout').map(l=>l.date))].sort().reverse();
    let s=0,d=new Date();
    for(let i=0;i<15;i++){ const k=dateKey(d); if(unique.includes(k)) s++; else if(i>0) break; d.setDate(d.getDate()-1); }
    return s;
  }
  function currentDay(){ const arr=state.plan?.[state.environment]||[]; return arr[Math.min(state.day,Math.max(0,arr.length-1))]; }
  function workoutLogs(){ return state.logs.filter(l=>l.type==='workout'); }
  function nextWorkoutIndex(env=state.profile.environment){
    const arr=state.plan?.[env]||[]; if(!arr.length) return 0;
    const last=workoutLogs().find(l=>l.environment===env && Number.isInteger(l.dayIndex));
    return last ? (last.dayIndex+1)%arr.length : 0;
  }
  function nextWorkout(env=state.profile.environment){ const arr=state.plan?.[env]||[]; return arr[nextWorkoutIndex(env)]||null; }
  function lastExerciseSets(id){
    for(const l of workoutLogs()){ const sets=(l.sets||[]).filter(x=>x.exerciseId===id); if(sets.length) return sets; }
    return [];
  }
  function repBounds(text){ const nums=String(text||'').match(/\d+/g)?.map(Number)||[]; return {low:nums[0]||8,high:nums[1]||nums[0]||12}; }
  function suggestedLoad(e){
    const prev=lastExerciseSets(e.id); if(!prev.length) return '';
    const weighted=prev.filter(x=>Number(x.weight)>0); if(!weighted.length) return '';
    const w=Number(weighted[0].weight); const b=repBounds(e.reps);
    const allTop=weighted.length>=Math.min(e.sets,2) && weighted.every(x=>Number(x.reps)>=b.high && Number(x.rir)<=2);
    return Math.max(0,Math.round((w+(allTop?2.5:0))*2)/2);
  }

  function renderHome(){
    const p=state.profile, idx=nextWorkoutIndex(p.environment), day=nextWorkout(p.environment);
    const sessions=workoutLogs().length, kg=latestWeight(), last=workoutLogs()[0];
    const kegelBlock=KEGEL_ENABLED?`<div class="section-title"><h3>Suelo pélvico</h3><span>Nivel ${escapeHtml(state.kegel.level)}</span></div>
      <div class="card kegel-mini"><div class="row between center"><div><span class="badge violet">SESIÓN GUIADA</span><h3 style="margin:8px 0 4px">Kegel / control pélvico</h3><p class="muted" style="margin:0">${state.kegel.sets} series · ${state.kegel.reps} repeticiones · contrae ${state.kegel.contract}s</p></div><div style="font-size:34px">◉</div></div><div class="space12"></div><button class="btn full" id="homeKegel">Comenzar sesión</button></div>`:'';
    screen.innerHTML=`
      <section class="hero"><span class="pill good">${goals[p.goal].icon} ${goals[p.goal].label}</span><h2>Tu próxima sesión está lista.</h2><p>${p.days} días por semana · ${p.level} · ${p.environment==='gym'?'Gimnasio':'Aire libre'} · ${p.sessionMinutes} min objetivo</p></section>
      <div class="space12"></div><div class="grid3"><div class="stat"><b>${kg.toFixed(1)} kg</b><small>Peso</small></div><div class="stat"><b>${streak()} días</b><small>Racha</small></div><div class="stat"><b>${sessions}</b><small>Sesiones</small></div></div>
      <div class="section-title"><h3>Tu próxima sesión</h3><span>${last?`Última: ${fmtDate(last.date)}`:'Comienza hoy'}</span></div>
      ${day?workoutHero(day,idx):'<div class="card">Crea tu plan desde Más.</div>'}
      ${kegelBlock}
      <div class="section-title"><h3>Progresión inteligente</h3></div>
      <div class="card"><span class="badge lime">NEXOFIT 0.2</span><p style="margin:9px 0 0;color:#c8d6dc;line-height:1.5;font-size:13px">Ahora cada serie puede registrar carga, repeticiones y RIR. Cuando alcanzas el rango alto con margen técnico, NexoFit te propone una pequeña subida para la próxima sesión.</p></div>`;
    const start=$('#startToday'); if(start) start.onclick=()=>startWorkout(day,idx);
    const change=$('#changeToday'); if(change) change.onclick=()=>{state.environment=p.environment;state.day=(idx+1)%Math.max(1,(state.plan?.[p.environment]||[]).length);state.tab='routine';render();syncNav();};
    if(KEGEL_ENABLED && $('#homeKegel')) $('#homeKegel').onclick=()=>{state.tab='kegel';render();syncNav();setTimeout(startKegel,80)};
  }
  function workoutHero(day,idx){
    const previous=lastExerciseSets(day.exercises[0]?.id); const prevTxt=previous.length?`Anterior: ${previous[0].weight?previous[0].weight+' kg · ':''}${previous[0].reps} reps`:'Aún sin registros de esta sesión';
    return `<div class="card workout-card"><div class="workout-cover"><span class="badge">DÍA ${day.day}</span><h3>${escapeHtml(day.name)}</h3><p>${escapeHtml(day.subtitle)}</p></div><div class="workout-body"><div class="row between center"><span class="muted">${day.exercises.length} ejercicios · ${day.minutes} min</span><span class="pill">${day.environment==='gym'?'🏋 Gimnasio':'🌳 Aire libre'}</span></div><div class="space8"></div><div class="muted">${prevTxt}</div><div class="space12"></div><button class="btn full" id="startToday">Comenzar entrenamiento →</button><div class="space8"></div><button class="btn ghost full" id="changeToday">Cambiar entrenamiento</button></div></div>`;
  }

  function renderRoutine(){
    const arr=state.plan?.[state.environment]||[]; if(state.day>=arr.length) state.day=0; const day=arr[state.day];
    screen.innerHTML=`<div class="segment"><button id="gymSeg" class="${state.environment==='gym'?'active':''}">🏋 Gimnasio</button><button id="outSeg" class="${state.environment==='outdoor'?'active':''}">🌳 Aire libre</button></div><div class="space12"></div>
      <div class="daychips">${arr.map((d,i)=>`<button class="daychip ${i===state.day?'active':''}" data-day="${i}">Día ${i+1}<br><span style="font-weight:500">${escapeHtml(d.name)}</span></button>`).join('')}</div>
      ${day?`<div class="card accent"><div class="row between center"><div><span class="badge">DÍA ${day.day}</span><h2 style="margin:7px 0 4px;font-size:23px">${escapeHtml(day.name)}</h2><p class="muted" style="margin:0">${escapeHtml(day.subtitle)} · ${day.minutes} min</p></div><button class="icon-btn" id="editDay">✎</button></div></div>
      <div class="section-title"><h3>Ejercicios</h3><span>Editable</span></div><div class="exercise-list">${day.exercises.map((e,i)=>exerciseRow(e,i)).join('')}</div><div class="space12"></div><button class="btn secondary full" id="addExercise">＋ Añadir ejercicio</button><div class="space8"></div><button class="btn full" id="startRoutine">▶ Comenzar esta rutina</button>`:''}`;
    $('#gymSeg').onclick=()=>switchEnv('gym'); $('#outSeg').onclick=()=>switchEnv('outdoor');
    $$('.daychip').forEach(b=>b.onclick=()=>{state.day=Number(b.dataset.day);renderRoutine();});
    $$('.exercise-row').forEach(r=>r.onclick=e=>{ if(e.target.closest('.more')) return; showExercise(r.dataset.id); });
    $$('.more').forEach(b=>b.onclick=e=>{e.stopPropagation();editExercise(Number(b.dataset.i))});
    if($('#editDay')) $('#editDay').onclick=()=>editDay(day);
    if($('#addExercise')) $('#addExercise').onclick=()=>chooseExercise(id=>{day.exercises.push(cloneExercise(id));markPlanCustomized();renderRoutine();toast('Ejercicio añadido');});
    if($('#startRoutine')) $('#startRoutine').onclick=()=>startWorkout(day,state.day);
  }
  function switchEnv(env){ state.environment=env; state.day=0; renderRoutine(); }
  function exerciseRow(e,i){ const sug=suggestedLoad(e); return `<div class="exercise-row" data-id="${e.id}"><div class="exercise-index">${i+1}</div><div><h4>${escapeHtml(e.name)}</h4><p>${e.sets} × ${escapeHtml(e.reps)} · ${e.rest}s${sug!==''?` · Próx. ${sug} kg`:''}</p></div><button class="more" data-i="${i}">⋮</button></div>`; }
  function cloneExercise(id){ const b=ex[id]; return {id,name:b.name,muscles:b.muscles,sets:b.sets,reps:b.reps,rest:b.rest,done:false}; }
  function chooseExercise(onChoose,title='Biblioteca de ejercicios'){
    const rows=Object.entries(ex).map(([id,e])=>`<button class="library-row" data-id="${id}"><b>${escapeHtml(e.name)}</b><span>${escapeHtml(e.muscles)}</span></button>`).join('');
    modal(`<div class="modal tall"><div class="handle"></div><div class="modal-head"><div><span class="badge">BIBLIOTECA</span><h2>${title}</h2></div><button class="close">×</button></div><div class="field"><label>Buscar</label><input id="exerciseSearch" placeholder="Ej. press, glúteos, espalda"></div><div class="space12"></div><div id="exerciseLibrary" class="library-list">${rows}</div></div>`);
    const bind=()=>$$('.library-row').forEach(b=>b.onclick=()=>{const id=b.dataset.id;closeModal();onChoose(id);}); bind();
    $('#exerciseSearch').oninput=e=>{const q=e.target.value.toLowerCase().trim();$$('.library-row').forEach(b=>b.style.display=b.textContent.toLowerCase().includes(q)?'flex':'none');};
  }

  function showExercise(id,onClose=null){
    const e=ex[id]||ex.squat;
    modal(`<div class="modal tall"><div class="handle"></div><div class="modal-head"><div><span class="badge">TÉCNICA</span><h2>${escapeHtml(e.name)}</h2><p class="muted" style="margin:0">${escapeHtml(e.muscles)}</p></div><button class="close" id="closeTechnique">×</button></div>
      ${demoSvg(e.anim)}<div class="space12"></div><div class="grid2"><button class="btn secondary" id="playAnim">▶ Animación local</button><button class="btn ghost" id="videoBtn">▶ Video en YouTube</button></div>
      <div class="section-title"><h3>Puntos clave</h3></div><div class="card soft">${e.cues.map(c=>`<div class="cue"><i>✓</i><div>${escapeHtml(c)}</div></div>`).join('')}</div>
      <div class="section-title"><h3>Errores comunes</h3></div><div class="card soft">${e.bad.map(c=>`<div class="cue bad"><i>×</i><div>${escapeHtml(c)}</div></div>`).join('')}</div>
      <div class="space16"></div><button class="btn full" id="closeTechniqueBottom">Entendido</button></div>`,false);
    $('#videoBtn').onclick=()=>openExternal(e.video);
    $('#playAnim').onclick=()=>{$('.demo-stage').classList.toggle('playing');$('#playAnim').textContent=$('.demo-stage').classList.contains('playing')?'❚❚ Pausar animación':'▶ Animación local';};
    const close=()=>{if(onClose)onClose();else closeModal();}; $('#closeTechnique').onclick=close;$('#closeTechniqueBottom').onclick=close;
  }

  function demoSvg(kind){
    const cls=kind==='lunge'?'lunge-body':kind==='push'?'push-body':'squat-body';
    return `<div class="demo-stage playing"><svg class="stick" viewBox="0 0 170 190" aria-label="Animación técnica simplificada"><g class="${cls}"><circle cx="85" cy="34" r="14" fill="#d7e8ee"/><line class="body" x1="85" y1="50" x2="85" y2="100"/><line class="limb" x1="85" y1="65" x2="53" y2="87"/><line class="limb" x1="85" y1="65" x2="119" y2="83"/></g><g class="${kind==='lunge'?'lunge-body':'squat-legs'}"><line class="limb" x1="85" y1="100" x2="58" y2="139"/><line class="limb" x1="58" y1="139" x2="49" y2="174"/><line class="limb" x1="85" y1="100" x2="112" y2="139"/><line class="limb" x1="112" y1="139" x2="124" y2="174"/><circle class="joint" cx="58" cy="139" r="5"/><circle class="joint" cx="112" cy="139" r="5"/></g><line x1="24" y1="177" x2="145" y2="177" stroke="#244858" stroke-width="3" stroke-linecap="round"/></svg></div>`;
  }

  function editExercise(i){
    const day=currentDay(), e=day.exercises[i];
    modal(`<div class="modal"><div class="handle"></div><div class="modal-head"><div><span class="badge">EDITAR EJERCICIO</span><h2>${escapeHtml(e.name)}</h2></div><button class="close">×</button></div><div class="grid2"><div class="field"><label>Series</label><input id="edSets" type="number" min="1" max="10" value="${e.sets}"></div><div class="field"><label>Descanso (seg)</label><input id="edRest" type="number" min="0" max="300" value="${e.rest}"></div></div><div class="space12"></div><div class="field"><label>Repeticiones / tiempo</label><input id="edReps" value="${escapeHtml(e.reps)}"></div><div class="space16"></div><button class="btn full" id="saveExercise">Guardar cambios</button><div class="space8"></div><div class="grid2"><button class="btn secondary" id="replaceExercise">Reemplazar</button><button class="btn secondary" id="moveExercise">Mover</button></div><div class="space8"></div><button class="btn danger full" id="removeExercise">Eliminar ejercicio</button></div>`);
    $('#saveExercise').onclick=()=>{e.sets=Math.max(1,Number($('#edSets').value)||e.sets);e.rest=Math.max(0,Number($('#edRest').value)||0);e.reps=$('#edReps').value.trim()||e.reps;markPlanCustomized();closeModal();renderRoutine();toast('Ejercicio actualizado');};
    $('#replaceExercise').onclick=()=>chooseExercise(id=>{day.exercises[i]=cloneExercise(id);markPlanCustomized();renderRoutine();toast('Ejercicio reemplazado');},'Reemplazar ejercicio');
    $('#moveExercise').onclick=()=>{closeModal();moveExercise(i);};
    $('#removeExercise').onclick=()=>{if(day.exercises.length<=2)return toast('Mantén al menos 2 ejercicios'); if(confirm(`¿Eliminar ${e.name}?`)){day.exercises.splice(i,1);markPlanCustomized();closeModal();renderRoutine();}};
  }
  function moveExercise(i){
    const day=currentDay(); modal(`<div class="modal"><div class="handle"></div><div class="modal-head"><div><span class="badge">ORDEN</span><h2>Mover ${escapeHtml(day.exercises[i].name)}</h2></div><button class="close">×</button></div><div class="grid2"><button class="btn secondary" id="moveUp">↑ Subir</button><button class="btn secondary" id="moveDown">↓ Bajar</button></div></div>`);
    $('#moveUp').onclick=()=>{if(i>0){[day.exercises[i-1],day.exercises[i]]=[day.exercises[i],day.exercises[i-1]];markPlanCustomized();closeModal();renderRoutine();}};
    $('#moveDown').onclick=()=>{if(i<day.exercises.length-1){[day.exercises[i+1],day.exercises[i]]=[day.exercises[i],day.exercises[i+1]];markPlanCustomized();closeModal();renderRoutine();}};
  }
  function editDay(day){
    modal(`<div class="modal"><div class="handle"></div><div class="modal-head"><div><span class="badge">EDITAR DÍA</span><h2>${escapeHtml(day.name)}</h2></div><button class="close">×</button></div><div class="field"><label>Nombre</label><input id="dayName" value="${escapeHtml(day.name)}"></div><div class="space12"></div><div class="field"><label>Descripción</label><input id="daySub" value="${escapeHtml(day.subtitle)}"></div><div class="space16"></div><button class="btn full" id="saveDay">Guardar</button></div>`);
    $('#saveDay').onclick=()=>{day.name=$('#dayName').value.trim()||day.name;day.subtitle=$('#daySub').value.trim()||day.subtitle;markPlanCustomized();closeModal();renderRoutine();};
  }

  function startWorkout(day,dayIndex=null){
    if(!day)return; const arr=state.plan?.[day.environment]||[]; const idx=Number.isInteger(dayIndex)?dayIndex:Math.max(0,arr.indexOf(day));
    state.workout={day,dayIndex:idx,exercise:0,set:1,start:Date.now(),completed:0,results:[]}; keepAwake(true); renderWorkoutLive();
  }
  function currentSetDefaults(e){
    const w=state.workout, previous=lastExerciseSets(e.id), already=w.results.filter(x=>x.exerciseId===e.id); const lastThis=already[already.length-1];
    const sug=suggestedLoad(e); const bounds=repBounds(e.reps); const old=previous[Math.min(w.set-1,Math.max(0,previous.length-1))];
    return {weight:lastThis?.weight ?? (sug!==''?sug:(old?.weight||'')), reps:old?.reps||bounds.low, rir:old?.rir??2};
  }
  function renderWorkoutLive(){
    const w=state.workout,d=w.day,e=d.exercises[w.exercise], base=ex[e.id]||{}, def=currentSetDefaults(e), prev=lastExerciseSets(e.id), sug=suggestedLoad(e);
    const prevText=prev.length?`${prev[0].weight?prev[0].weight+' kg × ':''}${prev[0].reps} · RIR ${prev[0].rir??'—'}`:'Sin registro anterior';
    modal(`<div class="modal tall workout-live"><div class="handle"></div><div class="modal-head"><div><span class="badge">ENTRENANDO</span><h2>Día ${d.day} · ${escapeHtml(d.name)}</h2></div><button class="close" id="quitWorkout">×</button></div><div class="progress"><i style="width:${Math.round(((w.exercise+(w.set-1)/Math.max(1,e.sets))/d.exercises.length)*100)}%"></i></div><div class="space16"></div>
      <span class="muted">Ejercicio ${w.exercise+1} de ${d.exercises.length} · Serie ${w.set} de ${e.sets}</span><h2 class="live-exercise">${escapeHtml(e.name)}</h2><p class="muted">${escapeHtml(e.muscles||'')}</p>
      <div class="previous-set"><span>Última vez</span><b>${prevText}</b>${sug!==''?`<em>Sugerido hoy: ${sug} kg</em>`:''}</div>
      <div class="set-entry"><div class="field"><label>Peso (kg)</label><input id="setWeight" type="number" step="0.5" min="0" placeholder="0 = corporal" value="${def.weight}"></div><div class="field"><label>Reps / seg</label><input id="setReps" type="number" step="1" min="1" value="${def.reps}"></div><div class="field"><label>RIR (reps en reserva)</label><select id="setRir">${[0,1,2,3,4,5].map(x=>`<option value="${x}">${x}</option>`).join('')}</select></div></div>
      <div class="row between center"><span class="pill">Objetivo ${escapeHtml(e.reps)}</span><span class="pill">Descanso ${e.rest}s</span></div>
      <div class="section-title"><h3>Series</h3><span>${w.results.filter(x=>x.exerciseId===e.id).length}/${e.sets} registradas</span></div><div class="set-dots">${Array.from({length:e.sets},(_,i)=>`<div class="set-dot ${i+1<w.set?'done':i+1===w.set?'current':''}">${i+1}</div>`).join('')}</div>
      <button class="btn secondary full" id="techLive">Ver técnica</button><div class="space8"></div><button class="btn full" id="completeSet">✓ Guardar serie ${w.set}</button><div class="space8"></div><button class="btn ghost full" id="skipExercise">Saltar ejercicio</button></div>`,false);
    $('#setRir').value=String(def.rir); $('#techLive').onclick=()=>showExercise(e.id,renderWorkoutLive); $('#completeSet').onclick=completeSet; $('#skipExercise').onclick=nextExercise; $('#quitWorkout').onclick=confirmQuitWorkout;
  }
  function completeSet(){
    const w=state.workout,e=w.day.exercises[w.exercise]; const reps=Number($('#setReps')?.value), weight=Math.max(0,Number($('#setWeight')?.value)||0), rir=Math.max(0,Math.min(5,Number($('#setRir')?.value)||0));
    if(!Number.isFinite(reps)||reps<=0)return toast('Ingresa las repeticiones o segundos');
    w.results.push({exerciseId:e.id,exerciseName:e.name,set:w.set,weight,reps,rir,timestamp:Date.now()}); vibrate(60);
    if(w.set<e.sets){const rest=e.rest;w.set++;if(rest>0)showRest(rest,renderWorkoutLive);else renderWorkoutLive();} else {w.completed++;nextExercise();}
  }
  function nextExercise(){ const w=state.workout;if(w.exercise<w.day.exercises.length-1){w.exercise++;w.set=1;renderWorkoutLive();}else finishWorkout(); }
  function showRest(sec,onDone){
    let end=Date.now()+sec*1000,total=sec; modal(`<div class="modal"><div class="handle"></div><div style="text-align:center;padding:12px 0 10px"><span class="badge">DESCANSO</span><h2 style="margin:10px 0 0">Recupera y respira</h2><div class="timer-ring" id="restRing" style="--p:100"><div class="timer-content"><small>SIGUIENTE SERIE</small><b id="restNum">${sec}</b><span>segundos</span></div></div><div class="grid2"><button class="btn secondary" id="addRest">＋30 s</button><button class="btn full" id="skipRest">Saltar</button></div></div></div>`,false);
    const tick=setInterval(()=>{const left=Math.max(0,Math.ceil((end-Date.now())/1000));if($('#restNum'))$('#restNum').textContent=left;if($('#restRing'))$('#restRing').style.setProperty('--p',(left/total)*100);if(left<=0){clearInterval(tick);vibrate(100);onDone();}},250);
    $('#addRest').onclick=()=>{end+=30000;total+=30;}; $('#skipRest').onclick=()=>{clearInterval(tick);onDone();};
  }
  function finishWorkout(){
    const w=state.workout,mins=Math.max(1,Math.round((Date.now()-w.start)/60000)),volume=Math.round(w.results.reduce((a,x)=>a+(Number(x.weight)||0)*(Number(x.reps)||0),0));
    state.logs.unshift({type:'workout',date:today(),timestamp:Date.now(),name:w.day.name,minutes:mins,environment:w.day.environment,dayIndex:w.dayIndex,completed:w.completed,sets:w.results,volume});save(KEYS.logs,state.logs);state.workout=null;keepAwake(false);
    const prs=sessionPRs(w.results);
    modal(`<div class="modal"><div class="handle"></div><div style="text-align:center;padding:18px 4px"><div style="font-size:54px">✓</div><h2 style="font-size:28px;margin:8px 0">Entrenamiento completado</h2><p class="muted">${mins} min · ${w.results.length} series registradas${volume?` · ${volume.toLocaleString('es-CL')} kg de volumen`:''}.</p>${prs.length?`<div class="card" style="text-align:left;margin-top:14px"><span class="badge lime">PROGRESO</span>${prs.map(x=>`<p style="margin:8px 0 0"><b>${escapeHtml(x.name)}</b>: ${x.text}</p>`).join('')}</div>`:''}<div class="space16"></div><button class="btn full" id="doneWorkout">Volver al inicio</button></div></div>`,false);
    $('#doneWorkout').onclick=()=>{closeModal();state.tab='home';render();syncNav();};
  }
  function sessionPRs(results){
    const out=[]; for(const id of [...new Set(results.map(x=>x.exerciseId))]){const now=results.filter(x=>x.exerciseId===id&&x.weight>0);if(!now.length)continue;const best=Math.max(...now.map(x=>x.weight*(1+x.reps/30)));const older=workoutLogs().slice(1).flatMap(l=>(l.sets||[]).filter(x=>x.exerciseId===id&&x.weight>0)).map(x=>x.weight*(1+x.reps/30));const old=older.length?Math.max(...older):0;if(old&&best>old*1.01)out.push({name:now[0].exerciseName,text:`nuevo récord estimado +${Math.round((best/old-1)*100)}%`});} return out.slice(0,3);
  }
  function confirmQuitWorkout(){if(confirm('¿Abandonar el entrenamiento? Las series de esta sesión no se guardarán.')){state.workout=null;keepAwake(false);closeModal();}}

  function renderProgress(){
    const weightLogs=state.logs.filter(l=>l.type==='weight').slice().reverse(), workouts=workoutLogs(), now=new Date();
    const thisMonth=workouts.filter(l=>{const d=new Date(l.timestamp);return d.getMonth()===now.getMonth()&&d.getFullYear()===now.getFullYear();}).length;
    const since=Date.now()-28*86400000,last28=workouts.filter(l=>l.timestamp>=since).length,target=Math.max(1,(state.profile.days||4)*4),adherence=Math.min(100,Math.round(last28/target*100));
    const stats=strengthStats();
    screen.innerHTML=`<div class="grid3"><div class="stat"><b>${latestWeight().toFixed(1)}</b><small>kg actual</small></div><div class="stat"><b>${thisMonth}</b><small>este mes</small></div><div class="stat"><b>${adherence}%</b><small>constancia 28d</small></div></div>
      <div class="section-title"><h3>Fuerza y rendimiento</h3><span>e1RM estimado</span></div>
      <div class="card strength-list">${stats.length?stats.slice(0,5).map(x=>`<div class="strength-row"><div><b>${escapeHtml(x.name)}</b><span>${x.bestWeight} kg × ${x.bestReps} reps</span></div><div><strong>${Math.round(x.bestE1rm)} kg</strong>${x.change!==null?`<small class="${x.change>=0?'up':'down'}">${x.change>=0?'↑':'↓'} ${Math.abs(x.change)}%</small>`:'<small>nuevo</small>'}</div></div>`).join(''):'<p class="muted">Registra cargas durante tus entrenamientos para ver progresión por ejercicio.</p>'}</div>
      <div class="section-title"><h3>Peso corporal</h3><span>Registro local</span></div><div class="chart">${weightChart(weightLogs)}</div><div class="space12"></div><div class="row"><div class="field" style="flex:1"><label>Registrar peso (kg)</label><input id="newWeight" type="number" step="0.1" min="35" max="250" value="${latestWeight().toFixed(1)}"></div><button class="btn" id="saveWeight" style="align-self:end">Guardar</button></div>
      <div class="section-title"><h3>Historial reciente</h3><span>${state.logs.length} registros</span></div><div class="card">${state.logs.length?state.logs.slice(0,12).map(historyRow).join(''):'<p class="muted">Todavía no hay sesiones registradas.</p>'}</div>`;
    $('#saveWeight').onclick=()=>{const v=Number($('#newWeight').value);if(v<35||v>250)return toast('Revisa el peso ingresado');state.logs.unshift({type:'weight',date:today(),timestamp:Date.now(),value:v});state.profile.weight=v;save(KEYS.logs,state.logs);save(KEYS.profile,state.profile);renderProgress();toast('Peso registrado');};
  }
  function latestWeight(){const l=state.logs.find(x=>x.type==='weight');return Number(l?.value||state.profile?.weight||70);}
  function historyRow(l){
    if(l.type==='workout')return `<div class="history-item"><div><b>🏋 ${escapeHtml(l.name)}</b><br><span>${fmtDate(l.date)} · ${(l.sets||[]).length} series</span></div><span>${l.minutes} min</span></div>`;
    if(l.type==='weight')return `<div class="history-item"><div><b>⚖ Registro de peso</b><br><span>${fmtDate(l.date)}</span></div><span>${Number(l.value).toFixed(1)} kg</span></div>`;
    if(l.type==='kegel')return `<div class="history-item"><div><b>◉ Suelo pélvico</b><br><span>${fmtDate(l.date)}</span></div><span>Sesión</span></div>`;
    return `<div class="history-item"><div><b>Registro</b><br><span>${fmtDate(l.date)}</span></div><span>—</span></div>`;
  }
  function strengthStats(){
    const by={}; const chronological=workoutLogs().slice().reverse();
    chronological.forEach(l=>{
      const session={}; (l.sets||[]).forEach(x=>{if(!(x.weight>0&&x.reps>0))return;const e1=x.weight*(1+x.reps/30);const k=x.exerciseId;const cur=session[k];if(!cur||e1>cur.e1)session[k]={e1,weight:x.weight,reps:x.reps,name:x.exerciseName};});
      Object.entries(session).forEach(([k,x])=>{const o=by[k]||(by[k]={name:x.name,first:x.e1,best:x.e1,bestWeight:x.weight,bestReps:x.reps});if(x.e1>o.best){o.best=x.e1;o.bestWeight=x.weight;o.bestReps=x.reps;}});
    });
    return Object.values(by).map(o=>({...o,bestE1rm:o.best,change:o.first?Math.round((o.best/o.first-1)*100):null})).sort((a,b)=>b.bestE1rm-a.bestE1rm);
  }
  function weightChart(logs){
    const data=logs.slice(-8);if(data.length<2)return `<div style="height:100%;display:grid;place-items:center;text-align:center;color:#7894a2;font-size:12px">Registra tu peso al menos dos veces<br>para ver la tendencia.</div>`;
    const vals=data.map(x=>Number(x.value)),min=Math.min(...vals)-.5,max=Math.max(...vals)+.5,w=300,h=145,p=18;const pts=vals.map((v,i)=>[p+i*(w-2*p)/(vals.length-1),h-p-(v-min)/(max-min)*(h-2*p)]);
    return `<svg viewBox="0 0 ${w} ${h}"><line class="gridline" x1="${p}" y1="${h-p}" x2="${w-p}" y2="${h-p}"/><line class="gridline" x1="${p}" y1="${p}" x2="${w-p}" y2="${p}"/><polyline class="line" points="${pts.map(a=>a.join(',')).join(' ')}"/>${pts.map((a,i)=>`<circle class="dot" cx="${a[0]}" cy="${a[1]}" r="4"/><text x="${a[0]-8}" y="${Math.max(9,a[1]-9)}">${vals[i].toFixed(1)}</text>`).join('')}</svg>`;
  }

  function renderKegel(){
    const k=state.kegel;
    screen.innerHTML=`<div class="card accent"><div class="row between center"><div><span class="badge violet">${escapeHtml(k.level.toUpperCase())}</span><h2 style="margin:8px 0 4px">Sesión guiada</h2><p class="muted" style="margin:0">${k.sets} series · ${k.reps} repeticiones</p></div><div style="font-size:42px;color:var(--violet)">◉</div></div><div class="space16"></div><div class="phase-grid"><div class="phase active"><b>Contrae</b>${k.contract}s</div><div class="phase"><b>Mantén</b>${k.hold}s</div><div class="phase"><b>Relaja</b>${k.relax}s</div></div><div class="space16"></div><button class="btn full" id="startKegel">Comenzar sesión</button></div><div class="section-title"><h3>Configurar</h3><span>Editable</span></div><div class="card"><div class="grid2"><div class="field"><label>Nivel</label><select id="kLevel"><option>Principiante</option><option>Intermedio</option><option>Avanzado</option></select></div><div class="field"><label>Repeticiones</label><input id="kReps" type="number" min="4" max="20" value="${k.reps}"></div><div class="field"><label>Contrae (s)</label><input id="kContract" type="number" min="2" max="10" value="${k.contract}"></div><div class="field"><label>Mantén (s)</label><input id="kHold" type="number" min="0" max="10" value="${k.hold}"></div><div class="field"><label>Relaja (s)</label><input id="kRelax" type="number" min="3" max="15" value="${k.relax}"></div><div class="field"><label>Series</label><input id="kSets" type="number" min="1" max="5" value="${k.sets}"></div></div><div class="space12"></div><button class="btn secondary full" id="saveKegel">Guardar configuración</button></div><div class="section-title"><h3>Técnica y seguridad</h3></div><div class="card"><div class="cue"><i>1</i><div>Contrae como si quisieras evitar el paso de gases, sin apretar glúteos ni abdomen en exceso.</div></div><div class="cue"><i>2</i><div>Respira normalmente. La fase de relajación importa tanto como la contracción.</div></div><div class="cue"><i>3</i><div>No uses cortar el chorro de orina como ejercicio habitual; puede servir solo para reconocer la musculatura.</div></div></div><div class="space12"></div><div class="notice"><strong>Importante:</strong> este módulo es de entrenamiento general del suelo pélvico, no un tratamiento médico ni garantiza mejorar la erección. Si aparece dolor pélvico, síntomas urinarios o empeoran molestias, detén la rutina y consulta a un profesional de salud.</div>`;
    $('#kLevel').value=k.level; $('#startKegel').onclick=startKegel; $('#saveKegel').onclick=saveKegelSettings;
  }
  function saveKegelSettings(){
    const k=state.kegel; k.level=$('#kLevel').value;k.reps=Math.max(4,Math.min(20,Number($('#kReps').value)||10));k.contract=Math.max(2,Math.min(10,Number($('#kContract').value)||5));k.hold=Math.max(0,Math.min(10,Number($('#kHold').value)||0));k.relax=Math.max(3,Math.min(15,Number($('#kRelax').value)||6));k.sets=Math.max(1,Math.min(5,Number($('#kSets').value)||3));save(KEYS.kegel,k);renderKegel();toast('Sesión Kegel actualizada');
  }
  function startKegel(){
    const k=state.kegel; keepAwake(true); const kt={phase:0,set:1,rep:1,left:k.contract,total:k.contract,running:true}; state.kegelTimer=kt; renderKegelTimer();
  }
  function renderKegelTimer(){
    const k=state.kegel,t=state.kegelTimer,phases=[['CONTRAE',k.contract],['MANTÉN',k.hold],['RELAJA',k.relax]].filter(x=>x[1]>0); const phase=phases[t.phase]; t.total=phase[1]; if(t.left>t.total||t.left<=0)t.left=t.total;
    modal(`<div class="modal tall"><div class="handle"></div><div class="modal-head"><div><span class="badge violet">SESIÓN ACTIVA</span><h2>Kegel guiado</h2><p class="muted" style="margin:0">Serie ${t.set}/${k.sets} · Repetición ${t.rep}/${k.reps}</p></div><button class="close" id="stopKegel">×</button></div><div class="timer-ring" id="kRing" style="--p:100"><div class="timer-content"><small id="kPhase">${phase[0]}</small><b id="kNum">${t.left}</b><span>segundos</span></div></div><div class="phase-grid">${phases.map((x,i)=>`<div class="phase ${i===t.phase?'active':''}"><b>${x[0][0]+x[0].slice(1).toLowerCase()}</b>${x[1]}s</div>`).join('')}</div><div class="space16"></div><div class="card"><p id="kTip" style="margin:0;text-align:center;color:#c6d6dd;line-height:1.5">${phase[0]==='RELAJA'?'Suelta completamente la musculatura y respira.':'Respira. Evita apretar glúteos, piernas o abdomen de forma excesiva.'}</p></div><div class="space16"></div><button class="btn secondary full" id="pauseKegel">❚❚ Pausar</button></div>`,false);
    $('#stopKegel').onclick=()=>{clearKegelTimer();keepAwake(false);closeModal();}; $('#pauseKegel').onclick=()=>{t.running=!t.running;$('#pauseKegel').textContent=t.running?'❚❚ Pausar':'▶ Continuar';};
    clearInterval(startKegel._interval); startKegel._interval=setInterval(()=>{if(!t.running)return;t.left--; if(t.left<=0){vibrate(80); advanceKegel(phases); return;} if($('#kNum'))$('#kNum').textContent=t.left;if($('#kRing'))$('#kRing').style.setProperty('--p',(t.left/t.total)*100);},1000);
  }
  function advanceKegel(phases){
    const t=state.kegelTimer,k=state.kegel; t.phase++; if(t.phase>=phases.length){t.phase=0;t.rep++;if(t.rep>k.reps){t.rep=1;t.set++;if(t.set>k.sets){finishKegel();return;}}}t.left=phases[t.phase][1];renderKegelTimer();
  }
  function finishKegel(){
    clearKegelTimer(); keepAwake(false); const k=state.kegel;k.completed=(k.completed||0)+1;k.last=today();save(KEYS.kegel,k);state.logs.unshift({type:'kegel',date:today(),timestamp:Date.now(),name:'Kegel guiado'});save(KEYS.logs,state.logs);modal(`<div class="modal"><div class="handle"></div><div style="text-align:center;padding:18px 4px"><div style="font-size:52px;color:var(--teal)">◉</div><h2>Sesión completada</h2><p class="muted">El trabajo incluye contracción y relajación. Evita agregar más volumen solo por sentir que “más es mejor”.</p><div class="space16"></div><button class="btn full closeAction">Finalizar</button></div></div>`);vibrate(120);
  }
  function clearKegelTimer(){clearInterval(startKegel._interval);state.kegelTimer=null;}

  function renderProfile(){
    const p=state.profile,edition=KEGEL_ENABLED?'NexoFit Plus':'NexoFit';
    screen.innerHTML=`<div class="card accent"><span class="badge">${edition.toUpperCase()} · 0.2</span><h2 style="margin:8px 0 4px">Tu plan se adapta y sigue siendo tuyo</h2><p class="muted" style="margin:0">Carga, repeticiones y progreso quedan guardados localmente. Sin cuenta ni servicios de Google.</p></div>
      <div class="section-title"><h3>Datos y objetivo</h3></div><div class="card"><div class="grid2"><div class="field"><label>Nombre</label><input id="pName" value="${escapeHtml(p.name||'')}"></div><div class="field"><label>Edad</label><input id="pAge" type="number" min="16" max="90" value="${p.age}"></div><div class="field"><label>Peso (kg)</label><input id="pWeight" type="number" step="0.1" value="${p.weight}"></div><div class="field"><label>Altura (cm)</label><input id="pHeight" type="number" value="${p.height}"></div><div class="field"><label>Nivel</label><select id="pLevel"><option>Principiante</option><option>Intermedio</option><option>Avanzado</option></select></div><div class="field"><label>Días / semana</label><input id="pDays" type="number" min="2" max="6" value="${p.days}"></div><div class="field"><label>Duración objetivo (min)</label><input id="pMinutes" type="number" min="25" max="120" value="${p.sessionMinutes}"></div><div class="field"><label>Lugar principal</label><select id="pEnv"><option value="gym">Gimnasio</option><option value="outdoor">Aire libre</option></select></div></div><div class="space16"></div><div class="field"><label>Meta principal</label><select id="pGoal">${Object.entries(goals).map(([k,g])=>`<option value="${k}">${g.label}</option>`).join('')}</select></div><div class="space16"></div><button class="btn full" id="saveProfile">Guardar cambios</button></div>
      <div class="section-title"><h3>Datos</h3></div><div class="card"><button class="btn secondary full" id="shareProgress">Compartir resumen de progreso</button><div class="space8"></div><button class="btn danger full" id="resetApp">Borrar datos y empezar de nuevo</button></div><div class="space12"></div><div class="notice"><strong>Privacidad:</strong> ${edition} guarda perfil, rutinas e historial en este teléfono. No usa Firebase, Google Sign-In ni Google Play Services.</div>`;
    $('#pLevel').value=p.level;$('#pEnv').value=p.environment;$('#pGoal').value=p.goal;$('#saveProfile').onclick=saveProfile;$('#resetApp').onclick=resetApp;$('#shareProgress').onclick=shareProgress;
  }
  function saveProfile(){
    const p=state.profile, old={...p};p.name=$('#pName').value.trim()||'Usuario';p.age=Number($('#pAge').value)||p.age;p.weight=Number($('#pWeight').value)||p.weight;p.height=Number($('#pHeight').value)||p.height;p.level=$('#pLevel').value;p.days=Math.max(2,Math.min(6,Number($('#pDays').value)||4));p.sessionMinutes=Math.max(25,Math.min(120,Number($('#pMinutes').value)||55));p.environment=$('#pEnv').value;p.goal=$('#pGoal').value;state.environment=p.environment;save(KEYS.profile,p);
    const structural=['level','days','sessionMinutes','environment','goal'].some(k=>old[k]!==p[k]);
    if(structural && state.plan?.customized){const rebuild=confirm('Tu rutina tiene cambios manuales.\n\nAceptar: crear un plan nuevo con tus datos.\nCancelar: conservar la rutina personalizada y solo actualizar tu perfil.');if(rebuild)regeneratePlan(false);}else if(structural)regeneratePlan(false);
    state.tab='home';render();syncNav();toast('Perfil actualizado');
  }
  function shareProgress(){
    const best=strengthStats()[0];const txt=`NexoFit 0.2 — Progreso\nPeso actual: ${latestWeight().toFixed(1)} kg\nSesiones: ${workoutLogs().length}\nRacha: ${streak()} días\nObjetivo: ${goals[state.profile.goal].label}${best?`\nMejor e1RM: ${best.name} ${Math.round(best.bestE1rm)} kg`:''}`;try{if(window.NexoNative)NexoNative.shareText(txt);else navigator.share?.({text:txt});}catch(e){}
  }
  function resetApp(){if(confirm('Esto eliminará perfil, rutinas y progreso guardado en este teléfono. ¿Continuar?')){Object.values(KEYS).forEach(k=>localStorage.removeItem(k));state.profile=null;state.plan=null;state.logs=[];state.kegel=KEGEL_ENABLED?{level:'Intermedio',contract:5,hold:3,relax:6,reps:10,sets:3,completed:0,last:null}:null;showOnboarding(true);}}

  function showOnboarding(force=false){
    const p=state.profile||defaultProfile(),edition=KEGEL_ENABLED?'NexoFit Plus':'NexoFit';
    modal(`<div class="modal tall"><div class="handle"></div><div class="modal-head"><div><span class="badge">BIENVENIDO A ${edition.toUpperCase()}</span><h2>Armemos tu plan</h2><p class="muted" style="margin:0">0.2 registra cargas, reps y RIR para acompañar tu progresión.</p></div>${force?'':'<button class="close">×</button>'}</div><div class="field"><label>¿Cómo te llamas?</label><input id="oName" value="${escapeHtml(p.name||'')}"></div><div class="space12"></div><div class="grid2"><div class="field"><label>Edad</label><input id="oAge" type="number" value="${p.age}"></div><div class="field"><label>Peso (kg)</label><input id="oWeight" type="number" step="0.1" value="${p.weight}"></div><div class="field"><label>Altura (cm)</label><input id="oHeight" type="number" value="${p.height}"></div><div class="field"><label>Días / semana</label><input id="oDays" type="number" min="2" max="6" value="${p.days}"></div></div><div class="section-title"><h3>Tu objetivo</h3></div><div class="goal-grid">${Object.entries(goals).map(([k,g])=>`<button class="goal ${k===p.goal?'selected':''}" data-goal="${k}"><span>${g.icon}</span><b>${g.label}</b><small>${g.note}</small></button>`).join('')}</div><div class="section-title"><h3>Entrenamiento</h3></div><div class="grid2"><div class="field"><label>Nivel</label><select id="oLevel"><option>Principiante</option><option>Intermedio</option><option>Avanzado</option></select></div><div class="field"><label>Lugar principal</label><select id="oEnv"><option value="gym">Gimnasio</option><option value="outdoor">Aire libre</option></select></div><div class="field"><label>Duración (min)</label><input id="oMinutes" type="number" min="25" max="120" value="${p.sessionMinutes||55}"></div></div><div class="space16"></div><button class="btn full" id="finishOnboarding">Crear mi plan →</button><div class="space12"></div><div class="notice">La duración disponible modifica la cantidad de ejercicios. Puedes editar, reemplazar, eliminar y reordenar ejercicios después.</div></div>`,false);
    $('#oLevel').value=p.level;$('#oEnv').value=p.environment;let chosen=p.goal;$$('.goal').forEach(b=>b.onclick=()=>{$$('.goal').forEach(x=>x.classList.remove('selected'));b.classList.add('selected');chosen=b.dataset.goal;});
    $('#finishOnboarding').onclick=()=>{state.profile={name:$('#oName').value.trim()||'Usuario',age:Number($('#oAge').value)||31,weight:Number($('#oWeight').value)||70,height:Number($('#oHeight').value)||170,days:Math.max(2,Math.min(6,Number($('#oDays').value)||4)),goal:chosen,level:$('#oLevel').value,environment:$('#oEnv').value,sessionMinutes:Math.max(25,Math.min(120,Number($('#oMinutes').value)||55))};state.environment=state.profile.environment;save(KEYS.profile,state.profile);regeneratePlan(false);closeModal();render();syncNav();toast('Tu plan está listo');};
  }

  function modal(html,bindClose=true){ modalRoot.innerHTML=`<div class="modal-backdrop">${html}</div>`; if(bindClose) bindModalClose(); else { const c=$('.modal .close'); if(c && !c.id) c.onclick=closeModal; } }
  function bindModalClose(){ const b=$('.modal-backdrop'); if(!b)return; $$('.close,.closeAction',b).forEach(x=>x.onclick=closeModal); b.addEventListener('click',e=>{if(e.target===b)closeModal();}); }
  function closeModal(){ modalRoot.innerHTML=''; }
  window.NexoFitHandleBack=()=>{
    if(modalRoot.innerHTML){
      if(state.workout) confirmQuitWorkout();
      else { if(state.kegelTimer){clearKegelTimer();keepAwake(false);} closeModal(); }
      return true;
    }
    if(state.tab!=='home'){state.tab='home';render();syncNav();return true;}
    return false;
  };

  init();
})();
