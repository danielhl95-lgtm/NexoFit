# NexoFit — MVP Android para Huawei

Aplicación fitness offline, sin Firebase, Google Sign-In, Play Services ni dependencias de ejecución de Google.

## Funciones incluidas

- Onboarding por edad, peso, altura, nivel, objetivo, días y lugar de entrenamiento.
- Generación de planes para gimnasio y aire libre.
- Rutinas editables: series, repeticiones y descanso.
- Modo entrenamiento con avance de series y temporizador de descanso.
- Ficha técnica de cada ejercicio.
- Animación local simplificada para demostrar el patrón de movimiento.
- Botón opcional para buscar un video técnico en YouTube mediante la app/navegador externo.
- Registro local de peso y sesiones, con gráfico básico de tendencia.
- Módulo de suelo pélvico/Kegel con temporizador configurable de contracción, mantención y relajación.
- Datos persistidos localmente en el WebView (DOM Storage / localStorage).

## Arquitectura

- `MainActivity.java`: shell Android nativa mínima usando `android.webkit.WebView`.
- `assets/index.html`, `styles.css`, `app.js`: interfaz y lógica de la app, empaquetadas dentro del APK.
- Sin AndroidX, Firebase, Google Mobile Services ni SDKs analíticos.
- El permiso `INTERNET` no está declarado. Los enlaces de YouTube se abren en otra app mediante `ACTION_VIEW`.

## Compatibilidad objetivo

- minSdk 26
- targetSdk 35
- compileSdk 35
- Java 17

## Compilar en Android Studio

1. Abrir la carpeta `NexoFit` como proyecto.
2. Permitir que Android Studio sincronice Gradle.
3. `Build > Build APK(s)`.
4. APK de debug: `app/build/outputs/apk/debug/app-debug.apk`.

## Compilar con GitHub Actions

El workflow `.github/workflows/build-apk.yml` instala Gradle 8.9 y Java 17, compila el APK y lo publica como artifact del workflow.

## Nota de salud

El módulo Kegel es educación/entrenamiento general del suelo pélvico. No diagnostica ni trata disfunción eréctil u otras condiciones. La app incluye una advertencia para detener el ejercicio ante dolor o síntomas y consultar a un profesional.
