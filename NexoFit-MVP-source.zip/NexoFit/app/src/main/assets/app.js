(() => {
  'use strict';

  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const screen = $('#screen');
  const modalRoot = $('#modalRoot');
  const toastEl = $('#toast');

  const KEYS = { profile:'nexofit.profile.v1', plan:'nexofit.plan.v1', logs:'nexofit.logs.v1', kegel:'nexofit.kegel.v1' };
  const state = {
    tab:'home', environment:'gym', day:0, profile:null, plan:null,
    logs:[], kegel:null, workout:null, kegelTimer:null
  };

  const goals = {
    muscle:{label:'Ganar músculo', icon:'💪', note:'Más masa y fuerza'},
    recomposition:{label:'Recomposición', icon:'⚡', note:'Músculo + control de grasa'},
    fat:{label:'Bajar grasa', icon:'🔥', note:'Más gasto y condición'},
    strength:{label:'Fuerza', icon:'🏋', note:'Progresar cargas'},
    fitness:{label:'Rendimiento', icon:'🏃', note:'Resistencia y capacidad física'}
  };

  const ex = {
    squat:{name:'Sentadilla',muscles:'Cuádriceps · glúteos · core',sets:4,reps:'8–12',rest:90,anim:'squat',video:'https://www.youtube.com/results?search_query=sentadilla+tecnica+correcta',cues:['Pecho abierto y abdomen firme.','Rodillas siguiendo la dirección de los pies.','Desciende con control hasta un rango cómodo.','Empuja el suelo al subir.'],bad:['Colapsar las rodillas hacia dentro.','Redondear la espalda por buscar más profundidad.','Rebotar sin control en la parte baja.']},
    rdl:{name:'Peso muerto rumano',muscles:'Isquiotibiales · glúteos · espalda',sets:4,reps:'8–10',rest:100,anim:'hinge',video:'https://www.youtube.com/results?search_query=peso+muerto+rumano+tecnica',cues:['Cadera viaja hacia atrás.','Barra o mancuernas cerca de las piernas.','Columna neutra y cuello relajado.','Sube contrayendo glúteos, sin hiperextender.'],bad:['Convertirlo en una sentadilla.','Alejar la carga del cuerpo.','Bajar más allá de tu movilidad.']},
    legpress:{name:'Prensa de piernas',muscles:'Cuádriceps · glúteos',sets:4,reps:'10–15',rest:90,anim:'squat',video:'https://www.youtube.com/results?search_query=prensa+de+piernas+tecnica',cues:['Apoya toda la planta del pie.','Controla el descenso.','Mantén pelvis estable contra el respaldo.'],bad:['Bloquear las rodillas agresivamente.','Despegar la cadera del respaldo.']},
    lunge:{name:'Zancadas',muscles:'Glúteos · cuádriceps · core',sets:3,reps:'10–12 c/pierna',rest:70,anim:'lunge',video:'https://www.youtube.com/results?search_query=zancadas+tecnica+correcta',cues:['Paso suficientemente largo para mantener equilibrio.','Tronco estable.','Empuja con el pie delantero.'],bad:['Golpear la rodilla contra el suelo.','Perder alineación de rodilla y pie.']},
    legext:{name:'Extensión de cuádriceps',muscles:'Cuádriceps',sets:3,reps:'12–15',rest:60,anim:'squat',video:'https://www.youtube.com/results?search_query=extension+de+cuadriceps+maquina+tecnica',cues:['Alinea la rodilla con el eje de la máquina.','Sube sin impulso y baja lento.'],bad:['Usar una carga que obligue a rebotar.']},
    legcurl:{name:'Curl femoral',muscles:'Isquiotibiales',sets:3,reps:'10–15',rest:60,anim:'hinge',video:'https://www.youtube.com/results?search_query=curl+femoral+maquina+tecnica',cues:['Mantén la pelvis estable.','Aprieta atrás y controla la vuelta.'],bad:['Arquear la espalda para mover la carga.']},
    calves:{name:'Elevación de gemelos',muscles:'Gemelos · sóleo',sets:4,reps:'12–20',rest:45,anim:'calf',video:'https://www.youtube.com/results?search_query=elevacion+de+gemelos+tecnica',cues:['Recorre un rango cómodo completo.','Pausa arriba un instante.'],bad:['Rebotar rápidamente.']},
    bench:{name:'Press de banca',muscles:'Pectoral · tríceps · deltoide anterior',sets:4,reps:'6–10',rest:110,anim:'push',video:'https://www.youtube.com/results?search_query=press+banca+tecnica+correcta',cues:['Escápulas estables contra el banco.','Pies firmes en el suelo.','Baja con control.'],bad:['Abrir excesivamente los codos.','Rebotar la barra en el pecho.']},
    incline:{name:'Press inclinado con mancuernas',muscles:'Pectoral superior · hombros · tríceps',sets:3,reps:'8–12',rest:80,anim:'push',video:'https://www.youtube.com/results?search_query=press+inclinado+mancuernas+tecnica',cues:['Controla el recorrido.','Mantén hombros lejos de las orejas.'],bad:['Chocar las mancuernas arriba.']},
    row:{name:'Remo sentado',muscles:'Dorsal · romboides · bíceps',sets:4,reps:'8–12',rest:85,anim:'row',video:'https://www.youtube.com/results?search_query=remo+sentado+polea+tecnica',cues:['Inicia llevando hombros atrás y abajo.','Codos viajan hacia atrás.','Evita balancear el torso.'],bad:['Tirar solo con los brazos.','Redondear la espalda.']},
    pulldown:{name:'Jalón al pecho',muscles:'Dorsal · bíceps',sets:4,reps:'8–12',rest:80,anim:'row',video:'https://www.youtube.com/results?search_query=jalon+al+pecho+tecnica',cues:['Pecho alto, hombros abajo.','Lleva la barra hacia la parte alta del pecho.'],bad:['Llevar la barra detrás de la cabeza.','Balancearte para ganar impulso.']},
    shoulder:{name:'Press de hombros',muscles:'Deltoides · tríceps',sets:3,reps:'8–12',rest:80,anim:'push',video:'https://www.youtube.com/results?search_query=press+militar+mancuernas+tecnica',cues:['Abdomen firme.','Sube la carga sin arquear la espalda.'],bad:['Extender demasiado la zona lumbar.']},
    lateral:{name:'Elevaciones laterales',muscles:'Deltoide medio',sets:3,reps:'12–18',rest:55,anim:'raise',video:'https://www.youtube.com/results?search_query=elevaciones+laterales+tecnica',cues:['Codos ligeramente flexionados.','Sube con control hasta una altura cómoda.'],bad:['Impulsar el torso.']},
    curl:{name:'Curl de bíceps',muscles:'Bíceps · braquial',sets:3,reps:'10–15',rest:55,anim:'curl',video:'https://www.youtube.com/results?search_query=curl+biceps+tecnica',cues:['Codos cerca del cuerpo.','Baja controlando.'],bad:['Balancear el tronco.']},
    triceps:{name:'Extensión de tríceps en polea',muscles:'Tríceps',sets:3,reps:'10–15',rest:55,anim:'push',video:'https://www.youtube.com/results?search_query=triceps+polea+tecnica',cues:['Codos quietos.','Extiende y aprieta sin encoger hombros.'],bad:['Mover todo el brazo para generar impulso.']},
    hip:{name:'Hip thrust',muscles:'Glúteos · isquiotibiales',sets:4,reps:'8–12',rest:90,anim:'hinge',video:'https://www.youtube.com/results?search_query=hip+thrust+tecnica',cues:['Mentón ligeramente recogido.','Sube hasta alinear tronco y muslos.','Pausa arriba contrayendo glúteos.'],bad:['Hiperextender la espalda.']},
    plank:{name:'Plancha',muscles:'Core · glúteos · hombros',sets:3,reps:'30–60 s',rest:45,anim:'push',video:'https://www.youtube.com/results?search_query=plancha+abdominal+tecnica',cues:['Cuerpo en línea.','Aprieta abdomen y glúteos.','Respira sin perder postura.'],bad:['Dejar caer la cadera.','Elevar demasiado la cadera.']},
    pushup:{name:'Flexiones',muscles:'Pectoral · tríceps · core',sets:4,reps:'8–20',rest:60,anim:'push',video:'https://www.youtube.com/results?search_query=flexiones+tecnica+correcta',cues:['Cuerpo rígido.','Manos bajo o ligeramente fuera de hombros.','Baja con control.'],bad:['Sacar la cabeza hacia delante.','Perder tensión abdominal.']},
    airSquat:{name:'Sentadilla con peso corporal',muscles:'Piernas · glúteos · core',sets:4,reps:'15–25',rest:45,anim:'squat',video:'https://www.youtube.com/results?search_query=sentadilla+peso+corporal+tecnica',cues:['Mantén el pie completo apoyado.','Controla la bajada y sube con intención.'],bad:['Juntar las rodillas hacia dentro.']},
    split:{name:'Sentadilla búlgara',muscles:'Glúteos · cuádriceps',sets:3,reps:'8–15 c/pierna',rest:65,anim:'lunge',video:'https://www.youtube.com/results?search_query=sentadilla+bulgara+tecnica',cues:['Busca un apoyo estable.','Baja verticalmente con control.'],bad:['Poner el pie delantero demasiado cerca.']},
    mountain:{name:'Mountain climbers',muscles:'Core · hombros · cardio',sets:4,reps:'30–45 s',rest:35,anim:'push',video:'https://www.youtube.com/results?search_query=mountain+climbers+tecnica',cues:['Manos firmes bajo hombros.','Mueve las piernas sin perder la cadera.'],bad:['Rebotar la pelvis excesivamente.']},
    burpee:{name:'Burpees',muscles:'Full body · cardio',sets:4,reps:'8–15',rest:60,anim:'squat',video:'https://www.youtube.com/results?search_query=burpees+tecnica',cues:['Prioriza técnica antes que velocidad.','Aterriza suave.'],bad:['Colapsar la espalda al bajar al suelo.']},
    stepup:{name:'Step-ups',muscles:'Glúteos · cuádriceps',sets:3,reps:'10–15 c/pierna',rest:55,anim:'lunge',video:'https://www.youtube.com/results?search_query=step+ups+tecnica',cues:['Apoya el pie completo en una superficie estable.','Sube usando la pierna de arriba.'],bad:['Impulsarte demasiado con la pierna de abajo.']},
    walk:{name:'Caminata rápida / trote suave',muscles:'Cardio · piernas',sets:1,reps:'20–35 min',rest:0,anim:'lunge',video:'https://www.youtube.com/results?search_query=tecnica+trote+principiantes',cues:['Ritmo en el que puedas mantener buena postura.','Aumenta tiempo gradualmente.'],bad:['Subir volumen muy rápido.']}
  };

  const gymTemplates = [
    {name:'Tren inferior',subtitle:'Fuerza y estabilidad',ids:['squat','rdl','legpress','lunge','legext','legcurl','calves']},
    {name:'Tren superior',subtitle:'Empuje + tracción',ids:['bench','row','pulldown','incline','shoulder','lateral','curl','triceps']},
    {name:'Full body A',subtitle:'Base completa',ids:['squat','bench','row','rdl','shoulder','plank']},
    {name:'Full body B',subtitle:'Volumen equilibrado',ids:['hip','pulldown','incline','lunge','lateral','curl','triceps']},
    {name:'Piernas + core',subtitle:'Glúteos, piernas y control',ids:['hip','squat','legcurl','legext','calves','plank']},
    {name:'Torso + brazos',subtitle:'Espalda, pecho y brazos',ids:['bench','pulldown','row','shoulder','lateral','curl','triceps']}
  ];
  const outdoorTemplates = [
    {name:'Full body parque',subtitle:'Sin equipamiento',ids:['airSquat','pushup','lunge','mountain','plank','burpee']},
    {name:'Piernas al aire libre',subtitle:'Fuerza unilateral',ids:['airSquat','split','stepup','lunge','calves','plank']},
    {name:'Acondicionamiento',subtitle:'Cardio + fuerza',ids:['walk','airSquat','pushup','mountain','burpee','plank']},
    {name:'Full body control',subtitle:'Técnica y volumen',ids:['split','pushup','airSquat','stepup','plank','mountain']}
  ];

  const load = (k,fallback) => { try { const v=localStorage.getItem(k); return v?JSON.parse(v):fallback; } catch(e){ return fallback; } };
  const save = (k,v) => localStorage.setItem(k,JSON.stringify(v));
  const today = () => new Date().toISOString().slice(0,10);
  const fmtDate = iso => new Date(iso+'T12:00:00').toLocaleDateString('es-CL',{day:'2-digit',month:'short'});
  const vibrate = ms => { try { if(window.NexoNative) NexoNative.vibrate(ms); else if(navigator.vibrate) navigator.vibrate(ms); } catch(e){} };
  const openExternal = url => { try { if(window.NexoNative) NexoNative.openExternal(url); else window.open(url,'_blank'); } catch(e){ window.location.href=url; } };
  const toast = msg => { toastEl.textContent=msg; toastEl.classList.add('show'); clearTimeout(toast._t); toast._t=setTimeout(()=>toastEl.classList.remove('show'),1800); };
  const escapeHtml = s => String(s).replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m]));

  function init(){
    state.profile = load(KEYS.profile,null);
    state.logs = load(KEYS.logs,[]);
    state.kegel = load(KEYS.kegel,{level:'Intermedio',contract:5,hold:3,relax:6,reps:10,sets:3,completed:0,last:null});
    state.plan = load(KEYS.plan,null);
    if(!state.profile){ state.profile = defaultProfile(); showOnboarding(true); }
    else { if(!state.plan) regeneratePlan(false); render(); }
    bindNav();
    $('#settingsBtn').addEventListener('click',()=>{ state.tab='profile'; render(); syncNav(); });
  }

  function defaultProfile(){ return {name:'Daniel',age:31,weight:70,height:164,goal:'muscle',level:'Intermedio',days:4,environment:'gym',sessionMinutes:55}; }

  function bindNav(){
    $$('.nav-item').forEach(b=>b.addEventListener('click',()=>{
      state.tab=b.dataset.tab; render(); syncNav();
    }));
  }
  function syncNav(){ $$('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.tab===state.tab)); }

  function render(){
    const names={home:['NEXOFIT','Inicio'],routine:['PLAN EDITABLE','Rutina'],progress:['TU EVOLUCIÓN','Progreso'],kegel:['SUELO PÉLVICO','Kegel'],profile:['CONFIGURACIÓN','Más']};
    $('#pageEyebrow').textContent=names[state.tab][0]; $('#pageTitle').textContent=names[state.tab][1];
    if(state.tab==='home') renderHome();
    if(state.tab==='routine') renderRoutine();
    if(state.tab==='progress') renderProgress();
    if(state.tab==='kegel') renderKegel();
    if(state.tab==='profile') renderProfile();
  }

  function generatePlan(profile){
    const n=Math.max(2,Math.min(6,Number(profile.days)||4));
    const gym=[]; const outdoor=[];
    const gymOrder=n<=2?[2,3]:n===3?[2,0,1]:n===4?[0,1,4,5]:[0,1,4,5,2,3];
    const outOrder=[0,1,2,3,0,2];
    for(let i=0;i<n;i++){
      const g=gymTemplates[gymOrder[i%gymOrder.length]], o=outdoorTemplates[outOrder[i%outOrder.length]];
      gym.push(makeDay(g,i,'gym',profile)); outdoor.push(makeDay(o,i,'outdoor',profile));
    }
    return {created:Date.now(),gym,outdoor};
  }
  function makeDay(t,i,env,profile){
    const intensity=profile.goal==='strength'?1:profile.goal==='fat'?.85:1;
    const arr=t.ids.map(id=>{
      const base=ex[id]; let sets=base.sets, rest=base.rest, reps=base.reps;
      if(profile.goal==='fat' && rest>45) rest=Math.max(45,Math.round(rest*.72));
      if(profile.goal==='strength' && ['squat','bench','rdl','row','pulldown'].includes(id)){ sets=Math.max(4,sets); rest=Math.max(120,rest); reps='5–8'; }
      if(profile.level==='Principiante') sets=Math.max(2,sets-1);
      return {id,name:base.name,muscles:base.muscles,sets,reps,rest,done:false};
    });
    return {name:t.name,subtitle:t.subtitle,day:i+1,environment:env,minutes:Math.round(arr.length*(env==='gym'?7.2:5.2)*intensity),exercises:arr};
  }
  function regeneratePlan(show=true){ state.plan=generatePlan(state.profile); save(KEYS.plan,state.plan); state.day=0; if(show) toast('Plan actualizado'); }

  function streak(){
    if(!state.logs.length) return 0;
    const unique=[...new Set(state.logs.filter(l=>l.type==='workout').map(l=>l.date))].sort().reverse();
    let s=0,d=new Date();
    for(let i=0;i<15;i++){ const k=d.toISOString().slice(0,10); if(unique.includes(k)) s++; else if(i>0) break; d.setDate(d.getDate()-1); }
    return s;
  }
  function currentDay(){ const arr=state.plan?.[state.environment]||[]; return arr[Math.min(state.day,Math.max(0,arr.length-1))]; }

  function renderHome(){
    const p=state.profile, day=(state.plan?.[p.environment]||[])[0] || currentDay();
    const sessions=state.logs.filter(l=>l.type==='workout').length;
    const kg=latestWeight();
    screen.innerHTML=`
      <section class="hero">
        <span class="pill good">${goals[p.goal].icon} ${goals[p.goal].label}</span>
        <h2>Entrena con un plan que se adapta a ti.</h2>
        <p>${p.days} días por semana · ${p.level} · ${p.environment==='gym'?'Gimnasio':'Aire libre'} · ${p.sessionMinutes} min aprox.</p>
      </section>
      <div class="space12"></div>
      <div class="grid3">
        <div class="stat"><b>${kg.toFixed(1)} kg</b><small>Peso</small></div>
        <div class="stat"><b>${streak()} días</b><small>Racha</small></div>
        <div class="stat"><b>${sessions}</b><small>Sesiones</small></div>
      </div>
      <div class="section-title"><h3>Entrenamiento de hoy</h3><span>${day?day.minutes:'—'} min</span></div>
      ${day?workoutHero(day):'<div class="card">Crea tu plan desde Más.</div>'}
      <div class="section-title"><h3>Suelo pélvico</h3><span>Nivel ${escapeHtml(state.kegel.level)}</span></div>
      <div class="card kegel-mini">
        <div class="row between center"><div><span class="badge violet">SESIÓN GUIADA</span><h3 style="margin:8px 0 4px">Kegel / control pélvico</h3><p class="muted" style="margin:0">${state.kegel.sets} series · ${state.kegel.reps} repeticiones · contrae ${state.kegel.contract}s</p></div><div style="font-size:34px">◉</div></div>
        <div class="space12"></div><button class="btn full" id="homeKegel">Comenzar sesión</button>
      </div>
      <div class="section-title"><h3>Consejo del día</h3></div>
      <div class="card"><span class="badge lime">PROGRESIÓN</span><p style="margin:9px 0 0;color:#c8d6dc;line-height:1.5;font-size:13px">Cuando completes el rango alto de repeticiones con buena técnica, aumenta la carga de forma pequeña la próxima sesión. El progreso sostenible vale más que apurarse.</p></div>`;
    const start=$('#startToday'); if(start) start.onclick=()=>startWorkout(day);
    $('#homeKegel').onclick=()=>{state.tab='kegel';render();syncNav();setTimeout(startKegel,80)};
  }
  function workoutHero(day){ return `<div class="card workout-card"><div class="workout-cover"><span class="badge">DÍA ${day.day}</span><h3>${escapeHtml(day.name)}</h3><p>${escapeHtml(day.subtitle)}</p></div><div class="workout-body"><div class="row between center"><span class="muted">${day.exercises.length} ejercicios · ${day.minutes} min</span><span class="pill">${day.environment==='gym'?'🏋 Gimnasio':'🌳 Aire libre'}</span></div><div class="space12"></div><button class="btn full" id="startToday">Comenzar entrenamiento →</button></div></div>`; }

  function renderRoutine(){
    state.environment = state.profile.environment || state.environment;
    const arr=state.plan?.[state.environment]||[]; if(state.day>=arr.length) state.day=0; const day=arr[state.day];
    screen.innerHTML=`
      <div class="segment"><button id="gymSeg" class="${state.environment==='gym'?'active':''}">🏋 Gimnasio</button><button id="outSeg" class="${state.environment==='outdoor'?'active':''}">🌳 Aire libre</button></div>
      <div class="space12"></div>
      <div class="daychips">${arr.map((d,i)=>`<button class="daychip ${i===state.day?'active':''}" data-day="${i}">Día ${i+1}<br><span style="font-weight:500">${escapeHtml(d.name)}</span></button>`).join('')}</div>
      ${day?`<div class="card accent"><div class="row between center"><div><span class="badge">DÍA ${day.day}</span><h2 style="margin:7px 0 4px;font-size:23px">${escapeHtml(day.name)}</h2><p class="muted" style="margin:0">${escapeHtml(day.subtitle)} · ${day.minutes} min</p></div><button class="icon-btn" id="editDay">✎</button></div></div>
      <div class="section-title"><h3>Ejercicios</h3><span>Toca para ver técnica</span></div>
      <div class="exercise-list">${day.exercises.map((e,i)=>exerciseRow(e,i)).join('')}</div><div class="space12"></div><button class="btn full" id="startRoutine">▶ Comenzar esta rutina</button>`:''}`;
    $('#gymSeg').onclick=()=>switchEnv('gym'); $('#outSeg').onclick=()=>switchEnv('outdoor');
    $$('.daychip').forEach(b=>b.onclick=()=>{state.day=Number(b.dataset.day);renderRoutine();});
    $$('.exercise-row').forEach(r=>r.onclick=e=>{ if(e.target.closest('.more')) return; showExercise(r.dataset.id); });
    $$('.more').forEach(b=>b.onclick=e=>{e.stopPropagation();editExercise(b.dataset.i)});
    if($('#editDay')) $('#editDay').onclick=()=>editDay(day);
    if($('#startRoutine')) $('#startRoutine').onclick=()=>startWorkout(day);
  }
  function switchEnv(env){ state.environment=env; state.profile.environment=env; save(KEYS.profile,state.profile); state.day=0; renderRoutine(); }
  function exerciseRow(e,i){ return `<div class="exercise-row" data-id="${e.id}"><div class="exercise-index">${i+1}</div><div><h4>${escapeHtml(e.name)}</h4><p>${e.sets} × ${escapeHtml(e.reps)} · ${e.rest}s descanso</p></div><button class="more" data-i="${i}">⋮</button></div>`; }

  function showExercise(id){
    const e=ex[id]||ex.squat;
    modal(`<div class="modal tall"><div class="handle"></div><div class="modal-head"><div><span class="badge">TÉCNICA</span><h2>${escapeHtml(e.name)}</h2><p class="muted" style="margin:0">${escapeHtml(e.muscles)}</p></div><button class="close">×</button></div>
      ${demoSvg(e.anim)}
      <div class="space12"></div><div class="grid2"><button class="btn secondary" id="playAnim">▶ Animación local</button><button class="btn ghost" id="videoBtn">▶ Video en YouTube</button></div>
      <div class="section-title"><h3>Puntos clave</h3></div><div class="card soft">${e.cues.map(c=>`<div class="cue"><i>✓</i><div>${escapeHtml(c)}</div></div>`).join('')}</div>
      <div class="section-title"><h3>Errores comunes</h3></div><div class="card soft">${e.bad.map(c=>`<div class="cue bad"><i>×</i><div>${escapeHtml(c)}</div></div>`).join('')}</div>
      <div class="space16"></div><button class="btn full closeAction">Entendido</button></div>`);
    $('#videoBtn').onclick=()=>openExternal(e.video);
    $('#playAnim').onclick=()=>{$('.demo-stage').classList.toggle('playing');$('#playAnim').textContent=$('.demo-stage').classList.contains('playing')?'❚❚ Pausar animación':'▶ Animación local';};
  }
  function demoSvg(kind){
    const cls=kind==='lunge'?'lunge-body':kind==='push'?'push-body':'squat-body';
    return `<div class="demo-stage playing"><svg class="stick" viewBox="0 0 170 190" aria-label="Animación técnica simplificada"><g class="${cls}"><circle cx="85" cy="34" r="14" fill="#d7e8ee"/><line class="body" x1="85" y1="50" x2="85" y2="100"/><line class="limb" x1="85" y1="65" x2="53" y2="87"/><line class="limb" x1="85" y1="65" x2="119" y2="83"/></g><g class="${kind==='lunge'?'lunge-body':'squat-legs'}"><line class="limb" x1="85" y1="100" x2="58" y2="139"/><line class="limb" x1="58" y1="139" x2="49" y2="174"/><line class="limb" x1="85" y1="100" x2="112" y2="139"/><line class="limb" x1="112" y1="139" x2="124" y2="174"/><circle class="joint" cx="58" cy="139" r="5"/><circle class="joint" cx="112" cy="139" r="5"/></g><line x1="24" y1="177" x2="145" y2="177" stroke="#244858" stroke-width="3" stroke-linecap="round"/></svg></div>`;
  }

  function editExercise(i){
    const day=currentDay(), e=day.exercises[i];
    modal(`<div class="modal"><div class="handle"></div><div class="modal-head"><div><span class="badge">EDITAR EJERCICIO</span><h2>${escapeHtml(e.name)}</h2></div><button class="close">×</button></div><div class="grid2"><div class="field"><label>Series</label><input id="edSets" type="number" min="1" max="10" value="${e.sets}"></div><div class="field"><label>Descanso (seg)</label><input id="edRest" type="number" min="0" max="300" value="${e.rest}"></div></div><div class="space12"></div><div class="field"><label>Repeticiones / tiempo</label><input id="edReps" value="${escapeHtml(e.reps)}"></div><div class="space16"></div><button class="btn full" id="saveExercise">Guardar cambios</button></div>`);
    $('#saveExercise').onclick=()=>{ e.sets=Math.max(1,Number($('#edSets').value)||e.sets);e.rest=Math.max(0,Number($('#edRest').value)||0);e.reps=$('#edReps').value.trim()||e.reps;save(KEYS.plan,state.plan);closeModal();renderRoutine();toast('Ejercicio actualizado'); };
  }
  function editDay(day){
    modal(`<div class="modal"><div class="handle"></div><div class="modal-head"><div><span class="badge">EDITAR DÍA</span><h2>${escapeHtml(day.name)}</h2></div><button class="close">×</button></div><div class="field"><label>Nombre</label><input id="dayName" value="${escapeHtml(day.name)}"></div><div class="space12"></div><div class="field"><label>Descripción</label><input id="daySub" value="${escapeHtml(day.subtitle)}"></div><div class="space16"></div><button class="btn full" id="saveDay">Guardar</button></div>`);
    $('#saveDay').onclick=()=>{day.name=$('#dayName').value.trim()||day.name;day.subtitle=$('#daySub').value.trim()||day.subtitle;save(KEYS.plan,state.plan);closeModal();renderRoutine();};
  }

  function startWorkout(day){
    state.workout={day,exercise:0,set:1,start:Date.now(),completed:0}; renderWorkoutLive();
  }
  function renderWorkoutLive(){
    const w=state.workout,d=w.day,e=d.exercises[w.exercise], base=ex[e.id]||{};
    modal(`<div class="modal tall workout-live"><div class="handle"></div><div class="modal-head"><div><span class="badge">ENTRENANDO</span><h2>Día ${d.day} · ${escapeHtml(d.name)}</h2></div><button class="close" id="quitWorkout">×</button></div><div class="progress"><i style="width:${Math.round((w.exercise/d.exercises.length)*100)}%"></i></div><div class="space24"></div><span class="muted">Ejercicio ${w.exercise+1} de ${d.exercises.length}</span><h2 class="live-exercise">${escapeHtml(e.name)}</h2><p class="muted">${escapeHtml(e.muscles||'')}</p><div class="grid2"><div class="card"><span class="muted">Objetivo</span><div class="big-number" style="font-size:28px">${escapeHtml(e.reps)}</div></div><div class="card"><span class="muted">Descanso</span><div class="big-number" style="font-size:28px">${e.rest}s</div></div></div><div class="section-title"><h3>Series</h3><span>${e.sets} totales</span></div><div class="set-dots">${Array.from({length:e.sets},(_,i)=>`<div class="set-dot ${i+1<w.set?'done':i+1===w.set?'current':''}">${i+1}</div>`).join('')}</div>${demoSvg(base.anim||'squat')}<div class="space12"></div><button class="btn secondary full" id="techLive">Ver técnica</button><div class="space8"></div><button class="btn full" id="completeSet">✓ Completar serie ${w.set}</button><div class="space8"></div><button class="btn ghost full" id="skipExercise">Saltar ejercicio</button></div>`,false);
    $('#techLive').onclick=()=>showExercise(e.id); $('#completeSet').onclick=()=>completeSet(); $('#skipExercise').onclick=()=>nextExercise(); $('#quitWorkout').onclick=()=>confirmQuitWorkout();
  }
  function completeSet(){
    const w=state.workout,e=w.day.exercises[w.exercise]; vibrate(60);
    if(w.set<e.sets){ const rest=e.rest; w.set++; if(rest>0) showRest(rest,()=>renderWorkoutLive()); else renderWorkoutLive(); }
    else { w.completed++; nextExercise(); }
  }
  function nextExercise(){
    const w=state.workout; if(w.exercise<w.day.exercises.length-1){w.exercise++;w.set=1;renderWorkoutLive();} else finishWorkout();
  }
  function showRest(sec,onDone){
    let left=sec; modal(`<div class="modal"><div class="handle"></div><div style="text-align:center;padding:12px 0 10px"><span class="badge">DESCANSO</span><h2 style="margin:10px 0 0">Recupera y respira</h2><div class="timer-ring" id="restRing" style="--p:100"><div class="timer-content"><small>SIGUIENTE SERIE</small><b id="restNum">${left}</b><span>segundos</span></div></div><button class="btn full" id="skipRest">Omitir descanso</button></div></div>`,false);
    const tick=setInterval(()=>{left--;if($('#restNum')) $('#restNum').textContent=left;if($('#restRing')) $('#restRing').style.setProperty('--p',(left/sec)*100);if(left<=0){clearInterval(tick);vibrate(100);onDone();}},1000); $('#skipRest').onclick=()=>{clearInterval(tick);onDone();};
  }
  function finishWorkout(){
    const w=state.workout, mins=Math.max(1,Math.round((Date.now()-w.start)/60000));
    state.logs.unshift({type:'workout',date:today(),timestamp:Date.now(),name:w.day.name,minutes:mins,environment:w.day.environment,completed:w.completed}); save(KEYS.logs,state.logs); state.workout=null;
    modal(`<div class="modal"><div class="handle"></div><div style="text-align:center;padding:18px 4px"><div style="font-size:54px">✓</div><h2 style="font-size:28px;margin:8px 0">Entrenamiento completado</h2><p class="muted">${mins} min registrados. Buen trabajo: el historial ya quedó guardado en tu teléfono.</p><div class="space16"></div><button class="btn full closeAction" id="doneWorkout">Volver al inicio</button></div></div>`);
    $('#doneWorkout').onclick=()=>{closeModal();state.tab='home';render();syncNav();};
  }
  function confirmQuitWorkout(){ if(confirm('¿Salir del entrenamiento? El progreso de esta sesión no se guardará.')){state.workout=null;closeModal();} }

  function renderProgress(){
    const weightLogs=state.logs.filter(l=>l.type==='weight').slice().reverse(); const workouts=state.logs.filter(l=>l.type==='workout'); const month=new Date().getMonth(); const thisMonth=workouts.filter(l=>new Date(l.timestamp).getMonth()===month).length;
    screen.innerHTML=`<div class="grid3"><div class="stat"><b>${latestWeight().toFixed(1)}</b><small>kg actual</small></div><div class="stat"><b>${workouts.length}</b><small>sesiones</small></div><div class="stat"><b>${thisMonth}</b><small>este mes</small></div></div><div class="section-title"><h3>Peso</h3><span>Registro local</span></div><div class="chart">${weightChart(weightLogs)}</div><div class="space12"></div><div class="row"><div class="field" style="flex:1"><label>Registrar peso (kg)</label><input id="newWeight" type="number" step="0.1" min="35" max="250" value="${latestWeight().toFixed(1)}"></div><button class="btn" id="saveWeight" style="align-self:end">Guardar</button></div><div class="section-title"><h3>Historial reciente</h3><span>${state.logs.length} registros</span></div><div class="card">${state.logs.length?state.logs.slice(0,10).map(historyRow).join(''):'<p class="muted">Todavía no hay sesiones registradas.</p>'}</div>`;
    $('#saveWeight').onclick=()=>{const v=Number($('#newWeight').value);if(v<35||v>250)return toast('Revisa el peso ingresado');state.logs.unshift({type:'weight',date:today(),timestamp:Date.now(),value:v});state.profile.weight=v;save(KEYS.logs,state.logs);save(KEYS.profile,state.profile);renderProgress();toast('Peso registrado');};
  }
  function latestWeight(){ const l=state.logs.find(x=>x.type==='weight'); return Number(l?.value||state.profile?.weight||70); }
  function historyRow(l){ return `<div class="history-item"><div><b>${l.type==='workout'?'🏋 '+escapeHtml(l.name):'⚖ Registro de peso'}</b><br><span>${fmtDate(l.date)}</span></div><span>${l.type==='workout'?l.minutes+' min':Number(l.value).toFixed(1)+' kg'}</span></div>`; }
  function weightChart(logs){
    const data=logs.slice(-8); if(data.length<2) return `<div style="height:100%;display:grid;place-items:center;text-align:center;color:#7894a2;font-size:12px">Registra tu peso al menos dos veces<br>para ver la tendencia.</div>`;
    const vals=data.map(x=>Number(x.value)), min=Math.min(...vals)-.5,max=Math.max(...vals)+.5,w=300,h=145,p=18; const pts=vals.map((v,i)=>[p+i*(w-2*p)/(vals.length-1),h-p-(v-min)/(max-min)*(h-2*p)]);
    return `<svg viewBox="0 0 ${w} ${h}"><line class="gridline" x1="${p}" y1="${h-p}" x2="${w-p}" y2="${h-p}"/><line class="gridline" x1="${p}" y1="${p}" x2="${w-p}" y2="${p}"/><polyline class="line" points="${pts.map(a=>a.join(',')).join(' ')}"/>${pts.map((a,i)=>`<circle class="dot" cx="${a[0]}" cy="${a[1]}" r="4"/><text x="${a[0]-8}" y="${Math.max(9,a[1]-9)}">${vals[i].toFixed(1)}</text>`).join('')}</svg>`;
  }

  function renderKegel(){
    const k=state.kegel;
    screen.innerHTML=`<div class="card accent"><div class="row between center"><div><span class="badge violet">${escapeHtml(k.level.toUpperCase())}</span><h2 style="margin:8px 0 4px">Sesión guiada</h2><p class="muted" style="margin:0">${k.sets} series · ${k.reps} repeticiones</p></div><div style="font-size:42px;color:var(--violet)">◉</div></div><div class="space16"></div><div class="phase-grid"><div class="phase active"><b>Contrae</b>${k.contract}s</div><div class="phase"><b>Mantén</b>${k.hold}s</div><div class="phase"><b>Relaja</b>${k.relax}s</div></div><div class="space16"></div><button class="btn full" id="startKegel">Comenzar sesión</button></div><div class="section-title"><h3>Configurar</h3><span>Editable</span></div><div class="card"><div class="grid2"><div class="field"><label>Nivel</label><select id="kLevel"><option>Principiante</option><option>Intermedio</option><option>Avanzado</option></select></div><div class="field"><label>Repeticiones</label><input id="kReps" type="number" min="4" max="20" value="${k.reps}"></div><div class="field"><label>Contrae (s)</label><input id="kContract" type="number" min="2" max="10" value="${k.contract}"></div><div class="field"><label>Mantén (s)</label><input id="kHold" type="number" min="0" max="10" value="${k.hold}"></div><div class="field"><label>Relaja (s)</label><input id="kRelax" type="number" min="3" max="15" value="${k.relax}"></div><div class="field"><label>Series</label><input id="kSets" type="number" min="1" max="5" value="${k.sets}"></div></div><div class="space12"></div><button class="btn secondary full" id="saveKegel">Guardar configuración</button></div><div class="section-title"><h3>Técnica y seguridad</h3></div><div class="card"><div class="cue"><i>1</i><div>Contrae como si quisieras evitar el paso de gases, sin apretar glúteos ni abdomen en exceso.</div></div><div class="cue"><i>2</i><div>Respira normalmente. La fase de relajación importa tanto como la contracción.</div></div><div class="cue"><i>3</i><div>No uses cortar el chorro de orina como ejercicio habitual; puede servir solo para reconocer la musculatura.</div></div></div><div class="space12"></div><div class="notice"><strong>Importante:</strong> este módulo es de entrenamiento general del suelo pélvico, no un tratamiento médico ni garantiza mejorar la erección. Si aparece dolor pélvico, síntomas urinarios o empeoran molestias, detén la rutina y consulta a un profesional de salud.</div>`;
    $('#kLevel').value=k.level; $('#startKegel').onclick=startKegel; $('#saveKegel').onclick=saveKegelSettings;
  }
  function saveKegelSettings(){
    const k=state.kegel; k.level=$('#kLevel').value;k.reps=Math.max(4,Math.min(20,Number($('#kReps').value)||10));k.contract=Math.max(2,Math.min(10,Number($('#kContract').value)||5));k.hold=Math.max(0,Math.min(10,Number($('#kHold').value)||0));k.relax=Math.max(3,Math.min(15,Number($('#kRelax').value)||6));k.sets=Math.max(1,Math.min(5,Number($('#kSets').value)||3));save(KEYS.kegel,k);renderKegel();toast('Sesión Kegel actualizada');
  }
  function startKegel(){
    const k=state.kegel; const kt={phase:0,set:1,rep:1,left:k.contract,total:k.contract,running:true}; state.kegelTimer=kt; renderKegelTimer();
  }
  function renderKegelTimer(){
    const k=state.kegel,t=state.kegelTimer,phases=[['CONTRAE',k.contract],['MANTÉN',k.hold],['RELAJA',k.relax]].filter(x=>x[1]>0); const phase=phases[t.phase]; t.total=phase[1]; if(t.left>t.total||t.left<=0)t.left=t.total;
    modal(`<div class="modal tall"><div class="handle"></div><div class="modal-head"><div><span class="badge violet">SESIÓN ACTIVA</span><h2>Kegel guiado</h2><p class="muted" style="margin:0">Serie ${t.set}/${k.sets} · Repetición ${t.rep}/${k.reps}</p></div><button class="close" id="stopKegel">×</button></div><div class="timer-ring" id="kRing" style="--p:100"><div class="timer-content"><small id="kPhase">${phase[0]}</small><b id="kNum">${t.left}</b><span>segundos</span></div></div><div class="phase-grid">${phases.map((x,i)=>`<div class="phase ${i===t.phase?'active':''}"><b>${x[0][0]+x[0].slice(1).toLowerCase()}</b>${x[1]}s</div>`).join('')}</div><div class="space16"></div><div class="card"><p id="kTip" style="margin:0;text-align:center;color:#c6d6dd;line-height:1.5">${phase[0]==='RELAJA'?'Suelta completamente la musculatura y respira.':'Respira. Evita apretar glúteos, piernas o abdomen de forma excesiva.'}</p></div><div class="space16"></div><button class="btn secondary full" id="pauseKegel">❚❚ Pausar</button></div>`,false);
    $('#stopKegel').onclick=()=>{clearKegelTimer();closeModal();}; $('#pauseKegel').onclick=()=>{t.running=!t.running;$('#pauseKegel').textContent=t.running?'❚❚ Pausar':'▶ Continuar';};
    clearInterval(startKegel._interval); startKegel._interval=setInterval(()=>{if(!t.running)return;t.left--; if(t.left<=0){vibrate(80); advanceKegel(phases); return;} if($('#kNum'))$('#kNum').textContent=t.left;if($('#kRing'))$('#kRing').style.setProperty('--p',(t.left/t.total)*100);},1000);
  }
  function advanceKegel(phases){
    const t=state.kegelTimer,k=state.kegel; t.phase++; if(t.phase>=phases.length){t.phase=0;t.rep++;if(t.rep>k.reps){t.rep=1;t.set++;if(t.set>k.sets){finishKegel();return;}}}t.left=phases[t.phase][1];renderKegelTimer();
  }
  function finishKegel(){
    clearKegelTimer(); const k=state.kegel;k.completed=(k.completed||0)+1;k.last=today();save(KEYS.kegel,k);state.logs.unshift({type:'kegel',date:today(),timestamp:Date.now(),name:'Kegel guiado'});save(KEYS.logs,state.logs);modal(`<div class="modal"><div class="handle"></div><div style="text-align:center;padding:18px 4px"><div style="font-size:52px;color:var(--teal)">◉</div><h2>Sesión completada</h2><p class="muted">El trabajo incluye contracción y relajación. Evita agregar más volumen solo por sentir que “más es mejor”.</p><div class="space16"></div><button class="btn full closeAction">Finalizar</button></div></div>`);vibrate(120);
  }
  function clearKegelTimer(){clearInterval(startKegel._interval);state.kegelTimer=null;}

  function renderProfile(){
    const p=state.profile;
    screen.innerHTML=`<div class="card accent"><span class="badge">PERFIL</span><h2 style="margin:8px 0 4px">Tu plan es completamente editable</h2><p class="muted" style="margin:0">Los datos se guardan localmente en este teléfono. No necesitas cuenta, Google ni conexión.</p></div><div class="section-title"><h3>Datos y objetivo</h3></div><div class="card"><div class="grid2"><div class="field"><label>Nombre</label><input id="pName" value="${escapeHtml(p.name||'')}"></div><div class="field"><label>Edad</label><input id="pAge" type="number" min="16" max="90" value="${p.age}"></div><div class="field"><label>Peso (kg)</label><input id="pWeight" type="number" step="0.1" value="${p.weight}"></div><div class="field"><label>Altura (cm)</label><input id="pHeight" type="number" value="${p.height}"></div><div class="field"><label>Nivel</label><select id="pLevel"><option>Principiante</option><option>Intermedio</option><option>Avanzado</option></select></div><div class="field"><label>Días / semana</label><input id="pDays" type="number" min="2" max="6" value="${p.days}"></div><div class="field"><label>Duración objetivo (min)</label><input id="pMinutes" type="number" min="25" max="120" value="${p.sessionMinutes}"></div><div class="field"><label>Lugar principal</label><select id="pEnv"><option value="gym">Gimnasio</option><option value="outdoor">Aire libre</option></select></div></div><div class="space16"></div><div class="field"><label>Meta principal</label><select id="pGoal">${Object.entries(goals).map(([k,g])=>`<option value="${k}">${g.label}</option>`).join('')}</select></div><div class="space16"></div><button class="btn full" id="saveProfile">Guardar y regenerar plan</button></div><div class="section-title"><h3>Datos</h3></div><div class="card"><button class="btn secondary full" id="shareProgress">Compartir resumen de progreso</button><div class="space8"></div><button class="btn danger full" id="resetApp">Borrar datos y empezar de nuevo</button></div><div class="space12"></div><div class="notice"><strong>Privacidad:</strong> esta versión guarda perfil, rutinas y progreso con almacenamiento local de la app. No usa Firebase, Google Sign-In ni Google Play Services.</div>`;
    $('#pLevel').value=p.level;$('#pEnv').value=p.environment;$('#pGoal').value=p.goal;
    $('#saveProfile').onclick=saveProfile;$('#resetApp').onclick=resetApp;$('#shareProgress').onclick=shareProgress;
  }
  function saveProfile(){
    const p=state.profile;p.name=$('#pName').value.trim()||'Usuario';p.age=Number($('#pAge').value)||p.age;p.weight=Number($('#pWeight').value)||p.weight;p.height=Number($('#pHeight').value)||p.height;p.level=$('#pLevel').value;p.days=Math.max(2,Math.min(6,Number($('#pDays').value)||4));p.sessionMinutes=Math.max(25,Math.min(120,Number($('#pMinutes').value)||55));p.environment=$('#pEnv').value;p.goal=$('#pGoal').value;state.environment=p.environment;save(KEYS.profile,p);regeneratePlan(false);state.tab='home';render();syncNav();toast('Perfil y plan actualizados');
  }
  function shareProgress(){
    const txt=`NexoFit — Progreso\nPeso actual: ${latestWeight().toFixed(1)} kg\nSesiones: ${state.logs.filter(l=>l.type==='workout').length}\nRacha: ${streak()} días\nObjetivo: ${goals[state.profile.goal].label}`;try{if(window.NexoNative)NexoNative.shareText(txt);else navigator.share?.({text:txt});}catch(e){}
  }
  function resetApp(){ if(confirm('Esto eliminará perfil, rutinas y progreso guardado en este teléfono. ¿Continuar?')){Object.values(KEYS).forEach(k=>localStorage.removeItem(k));state.profile=null;state.plan=null;state.logs=[];state.kegel=null;showOnboarding(true);} }

  function showOnboarding(force=false){
    const p=state.profile||defaultProfile();
    modal(`<div class="modal tall"><div class="handle"></div><div class="modal-head"><div><span class="badge">BIENVENIDO A NEXOFIT</span><h2>Armemos tu plan</h2><p class="muted" style="margin:0">Editable, offline y pensado para gimnasio o aire libre.</p></div>${force?'':'<button class="close">×</button>'}</div><div class="field"><label>¿Cómo te llamas?</label><input id="oName" value="${escapeHtml(p.name||'')}"></div><div class="space12"></div><div class="grid2"><div class="field"><label>Edad</label><input id="oAge" type="number" value="${p.age}"></div><div class="field"><label>Peso (kg)</label><input id="oWeight" type="number" step="0.1" value="${p.weight}"></div><div class="field"><label>Altura (cm)</label><input id="oHeight" type="number" value="${p.height}"></div><div class="field"><label>Días / semana</label><input id="oDays" type="number" min="2" max="6" value="${p.days}"></div></div><div class="section-title"><h3>Tu objetivo</h3></div><div class="goal-grid">${Object.entries(goals).map(([k,g])=>`<button class="goal ${k===p.goal?'selected':''}" data-goal="${k}"><span>${g.icon}</span><b>${g.label}</b><small>${g.note}</small></button>`).join('')}</div><div class="section-title"><h3>Entrenamiento</h3></div><div class="grid2"><div class="field"><label>Nivel</label><select id="oLevel"><option>Principiante</option><option>Intermedio</option><option>Avanzado</option></select></div><div class="field"><label>Lugar principal</label><select id="oEnv"><option value="gym">Gimnasio</option><option value="outdoor">Aire libre</option></select></div></div><div class="space16"></div><button class="btn full" id="finishOnboarding">Crear mi plan →</button><div class="space12"></div><div class="notice">Puedes cambiar todo esto después. La app no reemplaza la evaluación de un entrenador o profesional de salud si tienes lesiones o condiciones médicas.</div></div>`,false);
    $('#oLevel').value=p.level;$('#oEnv').value=p.environment;let chosen=p.goal;$$('.goal').forEach(b=>b.onclick=()=>{$$('.goal').forEach(x=>x.classList.remove('selected'));b.classList.add('selected');chosen=b.dataset.goal;});
    $('#finishOnboarding').onclick=()=>{state.profile={name:$('#oName').value.trim()||'Usuario',age:Number($('#oAge').value)||31,weight:Number($('#oWeight').value)||70,height:Number($('#oHeight').value)||170,days:Math.max(2,Math.min(6,Number($('#oDays').value)||4)),goal:chosen,level:$('#oLevel').value,environment:$('#oEnv').value,sessionMinutes:55};state.environment=state.profile.environment;save(KEYS.profile,state.profile);regeneratePlan(false);closeModal();render();syncNav();toast('Tu plan está listo');};
  }

  function modal(html,bindClose=true){ modalRoot.innerHTML=`<div class="modal-backdrop">${html}</div>`; if(bindClose) bindModalClose(); else { const c=$('.modal .close'); if(c && !c.id) c.onclick=closeModal; } }
  function bindModalClose(){ const b=$('.modal-backdrop'); if(!b)return; $$('.close,.closeAction',b).forEach(x=>x.onclick=closeModal); b.addEventListener('click',e=>{if(e.target===b)closeModal();}); }
  function closeModal(){ modalRoot.innerHTML=''; }

  init();
})();
